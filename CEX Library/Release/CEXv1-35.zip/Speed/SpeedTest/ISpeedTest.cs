﻿
namespace Speed.SpeedTest
{
    public interface ISpeedTest
    {
        /// <summary>
        /// Run the test
        /// </summary>
        void Test();
    }
}
