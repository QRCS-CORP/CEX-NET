﻿namespace VTDev.Projects.CEX
{
    partial class FormTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpTests = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnLogBrowse = new System.Windows.Forms.Button();
            this.chkLogResults = new System.Windows.Forms.CheckBox();
            this.txtLogFile = new System.Windows.Forms.TextBox();
            this.rdLogConsole = new System.Windows.Forms.RadioButton();
            this.rdLogFile = new System.Windows.Forms.RadioButton();
            this.TwofishVector = new System.Windows.Forms.CheckBox();
            this.Sha2Vector = new System.Windows.Forms.CheckBox();
            this.SerpentVector = new System.Windows.Forms.CheckBox();
            this.SerpentKey = new System.Windows.Forms.CheckBox();
            this.Sha3Vector = new System.Windows.Forms.CheckBox();
            this.SalsaVector = new System.Windows.Forms.CheckBox();
            this.HmacVector = new System.Windows.Forms.CheckBox();
            this.HKDFVector = new System.Windows.Forms.CheckBox();
            this.ChaChaVector = new System.Windows.Forms.CheckBox();
            this.AesAvs = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ModeVectors = new System.Windows.Forms.CheckBox();
            this.RijndaelIO = new System.Windows.Forms.CheckBox();
            this.AesMonteCarlo = new System.Windows.Forms.CheckBox();
            this.RijndaelVector = new System.Windows.Forms.CheckBox();
            this.ModePSCEquality = new System.Windows.Forms.CheckBox();
            this.btnAlgoTest = new System.Windows.Forms.Button();
            this.lvAlgorithmTest = new System.Windows.Forms.ListView();
            this.col1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.grpSpeed = new System.Windows.Forms.GroupBox();
            this.TSM = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.chkParallel = new System.Windows.Forms.CheckBox();
            this.rdDecrypt = new System.Windows.Forms.RadioButton();
            this.rdEncrypt = new System.Windows.Forms.RadioButton();
            this.cbMode = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cbRounds = new System.Windows.Forms.ComboBox();
            this.cbKeySize = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.THX = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rdByteIo = new System.Windows.Forms.RadioButton();
            this.rdFileIo = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.TFX = new System.Windows.Forms.RadioButton();
            this.RSM = new System.Windows.Forms.RadioButton();
            this.Salsa20 = new System.Windows.Forms.RadioButton();
            this.lblCompileWarning = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SPX = new System.Windows.Forms.RadioButton();
            this.SHX = new System.Windows.Forms.RadioButton();
            this.RSX = new System.Windows.Forms.RadioButton();
            this.RHX = new System.Windows.Forms.RadioButton();
            this.RDX = new System.Windows.Forms.RadioButton();
            this.DCS = new System.Windows.Forms.RadioButton();
            this.ChaCha20 = new System.Windows.Forms.RadioButton();
            this.btnSpeedTest = new System.Windows.Forms.Button();
            this.txtSizeMB = new System.Windows.Forms.TextBox();
            this.lblSize = new System.Windows.Forms.Label();
            this.lblTestStatus = new System.Windows.Forms.Label();
            this.pbTestStatus = new System.Windows.Forms.ProgressBar();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.lblEngineTime = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.Fusion = new System.Windows.Forms.RadioButton();
            this.grpTests.SuspendLayout();
            this.panel3.SuspendLayout();
            this.grpSpeed.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpTests
            // 
            this.grpTests.Controls.Add(this.panel3);
            this.grpTests.Controls.Add(this.TwofishVector);
            this.grpTests.Controls.Add(this.Sha2Vector);
            this.grpTests.Controls.Add(this.SerpentVector);
            this.grpTests.Controls.Add(this.SerpentKey);
            this.grpTests.Controls.Add(this.Sha3Vector);
            this.grpTests.Controls.Add(this.SalsaVector);
            this.grpTests.Controls.Add(this.HmacVector);
            this.grpTests.Controls.Add(this.HKDFVector);
            this.grpTests.Controls.Add(this.ChaChaVector);
            this.grpTests.Controls.Add(this.AesAvs);
            this.grpTests.Controls.Add(this.label2);
            this.grpTests.Controls.Add(this.label1);
            this.grpTests.Controls.Add(this.ModeVectors);
            this.grpTests.Controls.Add(this.RijndaelIO);
            this.grpTests.Controls.Add(this.AesMonteCarlo);
            this.grpTests.Controls.Add(this.RijndaelVector);
            this.grpTests.Controls.Add(this.ModePSCEquality);
            this.grpTests.Controls.Add(this.btnAlgoTest);
            this.grpTests.Controls.Add(this.lvAlgorithmTest);
            this.grpTests.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpTests.Location = new System.Drawing.Point(12, 12);
            this.grpTests.Name = "grpTests";
            this.grpTests.Size = new System.Drawing.Size(700, 430);
            this.grpTests.TabIndex = 25;
            this.grpTests.TabStop = false;
            this.grpTests.Text = "Algorithm Testing";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnLogBrowse);
            this.panel3.Controls.Add(this.chkLogResults);
            this.panel3.Controls.Add(this.txtLogFile);
            this.panel3.Controls.Add(this.rdLogConsole);
            this.panel3.Controls.Add(this.rdLogFile);
            this.panel3.Location = new System.Drawing.Point(8, 348);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(307, 65);
            this.panel3.TabIndex = 126;
            // 
            // btnLogBrowse
            // 
            this.btnLogBrowse.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogBrowse.Location = new System.Drawing.Point(270, 27);
            this.btnLogBrowse.Name = "btnLogBrowse";
            this.btnLogBrowse.Size = new System.Drawing.Size(30, 30);
            this.btnLogBrowse.TabIndex = 128;
            this.btnLogBrowse.Text = "...";
            this.btnLogBrowse.UseVisualStyleBackColor = true;
            this.btnLogBrowse.Click += new System.EventHandler(this.OnLogBrowse);
            // 
            // chkLogResults
            // 
            this.chkLogResults.AutoSize = true;
            this.chkLogResults.Checked = true;
            this.chkLogResults.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkLogResults.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkLogResults.Location = new System.Drawing.Point(155, 8);
            this.chkLogResults.Name = "chkLogResults";
            this.chkLogResults.Size = new System.Drawing.Size(85, 17);
            this.chkLogResults.TabIndex = 127;
            this.chkLogResults.Text = "Log Results";
            this.chkLogResults.UseVisualStyleBackColor = true;
            // 
            // txtLogFile
            // 
            this.txtLogFile.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLogFile.Location = new System.Drawing.Point(6, 33);
            this.txtLogFile.Name = "txtLogFile";
            this.txtLogFile.ReadOnly = true;
            this.txtLogFile.Size = new System.Drawing.Size(257, 22);
            this.txtLogFile.TabIndex = 129;
            this.txtLogFile.Text = "[Select an Output Folder]";
            // 
            // rdLogConsole
            // 
            this.rdLogConsole.AutoSize = true;
            this.rdLogConsole.Checked = true;
            this.rdLogConsole.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdLogConsole.Location = new System.Drawing.Point(6, 8);
            this.rdLogConsole.Name = "rdLogConsole";
            this.rdLogConsole.Size = new System.Drawing.Size(67, 17);
            this.rdLogConsole.TabIndex = 125;
            this.rdLogConsole.TabStop = true;
            this.rdLogConsole.Text = "Console";
            this.rdLogConsole.UseVisualStyleBackColor = true;
            this.rdLogConsole.Visible = false;
            this.rdLogConsole.CheckedChanged += new System.EventHandler(this.OnLogTypeCheck);
            // 
            // rdLogFile
            // 
            this.rdLogFile.AutoSize = true;
            this.rdLogFile.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdLogFile.Location = new System.Drawing.Point(79, 8);
            this.rdLogFile.Name = "rdLogFile";
            this.rdLogFile.Size = new System.Drawing.Size(65, 17);
            this.rdLogFile.TabIndex = 126;
            this.rdLogFile.Text = "Log File";
            this.rdLogFile.UseVisualStyleBackColor = true;
            this.rdLogFile.Visible = false;
            this.rdLogFile.CheckedChanged += new System.EventHandler(this.OnLogTypeCheck);
            // 
            // TwofishVector
            // 
            this.TwofishVector.AutoSize = true;
            this.TwofishVector.Checked = true;
            this.TwofishVector.CheckState = System.Windows.Forms.CheckState.Checked;
            this.TwofishVector.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TwofishVector.Location = new System.Drawing.Point(511, 304);
            this.TwofishVector.Name = "TwofishVector";
            this.TwofishVector.Size = new System.Drawing.Size(128, 17);
            this.TwofishVector.TabIndex = 125;
            this.TwofishVector.Text = "Twofish KAT Vectors";
            this.TwofishVector.UseVisualStyleBackColor = true;
            // 
            // Sha2Vector
            // 
            this.Sha2Vector.AutoSize = true;
            this.Sha2Vector.Checked = true;
            this.Sha2Vector.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Sha2Vector.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sha2Vector.Location = new System.Drawing.Point(511, 266);
            this.Sha2Vector.Name = "Sha2Vector";
            this.Sha2Vector.Size = new System.Drawing.Size(117, 17);
            this.Sha2Vector.TabIndex = 115;
            this.Sha2Vector.Text = "Sha-2 KAT Vectors";
            this.Sha2Vector.UseVisualStyleBackColor = true;
            // 
            // SerpentVector
            // 
            this.SerpentVector.AutoSize = true;
            this.SerpentVector.Checked = true;
            this.SerpentVector.CheckState = System.Windows.Forms.CheckState.Checked;
            this.SerpentVector.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SerpentVector.Location = new System.Drawing.Point(511, 247);
            this.SerpentVector.Name = "SerpentVector";
            this.SerpentVector.Size = new System.Drawing.Size(130, 17);
            this.SerpentVector.TabIndex = 107;
            this.SerpentVector.Text = "Serpent Vector Tests";
            this.SerpentVector.UseVisualStyleBackColor = true;
            // 
            // SerpentKey
            // 
            this.SerpentKey.AutoSize = true;
            this.SerpentKey.Checked = true;
            this.SerpentKey.CheckState = System.Windows.Forms.CheckState.Checked;
            this.SerpentKey.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SerpentKey.Location = new System.Drawing.Point(511, 228);
            this.SerpentKey.Name = "SerpentKey";
            this.SerpentKey.Size = new System.Drawing.Size(174, 17);
            this.SerpentKey.TabIndex = 105;
            this.SerpentKey.Text = "RSX/Serpent Key Comparison";
            this.SerpentKey.UseVisualStyleBackColor = true;
            // 
            // Sha3Vector
            // 
            this.Sha3Vector.AutoSize = true;
            this.Sha3Vector.Checked = true;
            this.Sha3Vector.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Sha3Vector.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sha3Vector.Location = new System.Drawing.Point(511, 285);
            this.Sha3Vector.Name = "Sha3Vector";
            this.Sha3Vector.Size = new System.Drawing.Size(117, 17);
            this.Sha3Vector.TabIndex = 104;
            this.Sha3Vector.Text = "Sha-3 KAT Vectors";
            this.Sha3Vector.UseVisualStyleBackColor = true;
            // 
            // SalsaVector
            // 
            this.SalsaVector.AutoSize = true;
            this.SalsaVector.Checked = true;
            this.SalsaVector.CheckState = System.Windows.Forms.CheckState.Checked;
            this.SalsaVector.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalsaVector.Location = new System.Drawing.Point(511, 209);
            this.SalsaVector.Name = "SalsaVector";
            this.SalsaVector.Size = new System.Drawing.Size(114, 17);
            this.SalsaVector.TabIndex = 103;
            this.SalsaVector.Text = "Salsa KAT Vectors";
            this.SalsaVector.UseVisualStyleBackColor = true;
            // 
            // HmacVector
            // 
            this.HmacVector.AutoSize = true;
            this.HmacVector.Checked = true;
            this.HmacVector.CheckState = System.Windows.Forms.CheckState.Checked;
            this.HmacVector.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HmacVector.Location = new System.Drawing.Point(511, 114);
            this.HmacVector.Name = "HmacVector";
            this.HmacVector.Size = new System.Drawing.Size(176, 17);
            this.HmacVector.TabIndex = 101;
            this.HmacVector.Text = "HMAC KAT Vectors (RFC 4321)";
            this.HmacVector.UseVisualStyleBackColor = true;
            // 
            // HKDFVector
            // 
            this.HKDFVector.AutoSize = true;
            this.HKDFVector.Checked = true;
            this.HKDFVector.CheckState = System.Windows.Forms.CheckState.Checked;
            this.HKDFVector.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HKDFVector.Location = new System.Drawing.Point(511, 95);
            this.HKDFVector.Name = "HKDFVector";
            this.HKDFVector.Size = new System.Drawing.Size(172, 17);
            this.HKDFVector.TabIndex = 100;
            this.HKDFVector.Text = "HKDF KAT Vectors (RFC 5869)";
            this.HKDFVector.UseVisualStyleBackColor = true;
            // 
            // ChaChaVector
            // 
            this.ChaChaVector.AutoSize = true;
            this.ChaChaVector.Checked = true;
            this.ChaChaVector.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ChaChaVector.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChaChaVector.Location = new System.Drawing.Point(511, 76);
            this.ChaChaVector.Name = "ChaChaVector";
            this.ChaChaVector.Size = new System.Drawing.Size(128, 17);
            this.ChaChaVector.TabIndex = 99;
            this.ChaChaVector.Text = "ChaCha KAT Vectors";
            this.ChaChaVector.UseVisualStyleBackColor = true;
            // 
            // AesAvs
            // 
            this.AesAvs.AutoSize = true;
            this.AesAvs.Checked = true;
            this.AesAvs.CheckState = System.Windows.Forms.CheckState.Checked;
            this.AesAvs.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AesAvs.Location = new System.Drawing.Point(511, 38);
            this.AesAvs.Name = "AesAvs";
            this.AesAvs.Size = new System.Drawing.Size(137, 17);
            this.AesAvs.TabIndex = 98;
            this.AesAvs.Text = "AESAVS Vectors (NIST)";
            this.AesAvs.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(8, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 96;
            this.label2.Text = "Results:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(508, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 95;
            this.label1.Text = "Test Vectors:";
            // 
            // ModeVectors
            // 
            this.ModeVectors.AutoSize = true;
            this.ModeVectors.Checked = true;
            this.ModeVectors.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ModeVectors.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ModeVectors.Location = new System.Drawing.Point(511, 133);
            this.ModeVectors.Name = "ModeVectors";
            this.ModeVectors.Size = new System.Drawing.Size(157, 17);
            this.ModeVectors.TabIndex = 85;
            this.ModeVectors.Text = "Mode KATs (NIST 800-38A)";
            this.ModeVectors.UseVisualStyleBackColor = true;
            // 
            // RijndaelIO
            // 
            this.RijndaelIO.AutoSize = true;
            this.RijndaelIO.Checked = true;
            this.RijndaelIO.CheckState = System.Windows.Forms.CheckState.Checked;
            this.RijndaelIO.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RijndaelIO.Location = new System.Drawing.Point(511, 171);
            this.RijndaelIO.Name = "RijndaelIO";
            this.RijndaelIO.Size = new System.Drawing.Size(115, 17);
            this.RijndaelIO.TabIndex = 93;
            this.RijndaelIO.Text = "Rijndael I/O Tests";
            this.RijndaelIO.UseVisualStyleBackColor = true;
            // 
            // AesMonteCarlo
            // 
            this.AesMonteCarlo.AutoSize = true;
            this.AesMonteCarlo.Checked = true;
            this.AesMonteCarlo.CheckState = System.Windows.Forms.CheckState.Checked;
            this.AesMonteCarlo.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AesMonteCarlo.Location = new System.Drawing.Point(511, 57);
            this.AesMonteCarlo.Name = "AesMonteCarlo";
            this.AesMonteCarlo.Size = new System.Drawing.Size(163, 17);
            this.AesMonteCarlo.TabIndex = 92;
            this.AesMonteCarlo.Text = "AES Monte Carlo (Fips 197)";
            this.AesMonteCarlo.UseVisualStyleBackColor = true;
            // 
            // RijndaelVector
            // 
            this.RijndaelVector.AutoSize = true;
            this.RijndaelVector.Checked = true;
            this.RijndaelVector.CheckState = System.Windows.Forms.CheckState.Checked;
            this.RijndaelVector.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RijndaelVector.Location = new System.Drawing.Point(511, 190);
            this.RijndaelVector.Name = "RijndaelVector";
            this.RijndaelVector.Size = new System.Drawing.Size(132, 17);
            this.RijndaelVector.TabIndex = 89;
            this.RijndaelVector.Text = "Rijndael Vector Tests";
            this.RijndaelVector.UseVisualStyleBackColor = true;
            // 
            // ModePSCEquality
            // 
            this.ModePSCEquality.AutoSize = true;
            this.ModePSCEquality.Checked = true;
            this.ModePSCEquality.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ModePSCEquality.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ModePSCEquality.Location = new System.Drawing.Point(511, 152);
            this.ModePSCEquality.Name = "ModePSCEquality";
            this.ModePSCEquality.Size = new System.Drawing.Size(128, 17);
            this.ModePSCEquality.TabIndex = 86;
            this.ModePSCEquality.Text = "PSC/SIC Equivalency";
            this.ModePSCEquality.UseVisualStyleBackColor = true;
            // 
            // btnAlgoTest
            // 
            this.btnAlgoTest.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlgoTest.Location = new System.Drawing.Point(611, 373);
            this.btnAlgoTest.Name = "btnAlgoTest";
            this.btnAlgoTest.Size = new System.Drawing.Size(72, 35);
            this.btnAlgoTest.TabIndex = 27;
            this.btnAlgoTest.Text = "Test";
            this.btnAlgoTest.UseVisualStyleBackColor = true;
            this.btnAlgoTest.Click += new System.EventHandler(this.OnAlgoTestClick);
            // 
            // lvAlgorithmTest
            // 
            this.lvAlgorithmTest.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.col1,
            this.col2,
            this.col3});
            this.lvAlgorithmTest.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvAlgorithmTest.FullRowSelect = true;
            this.lvAlgorithmTest.GridLines = true;
            this.lvAlgorithmTest.Location = new System.Drawing.Point(11, 38);
            this.lvAlgorithmTest.Name = "lvAlgorithmTest";
            this.lvAlgorithmTest.Size = new System.Drawing.Size(486, 284);
            this.lvAlgorithmTest.TabIndex = 1;
            this.lvAlgorithmTest.UseCompatibleStateImageBehavior = false;
            this.lvAlgorithmTest.View = System.Windows.Forms.View.Details;
            // 
            // col1
            // 
            this.col1.Text = "Test Name";
            this.col1.Width = 87;
            // 
            // col2
            // 
            this.col2.Text = "Description";
            this.col2.Width = 345;
            // 
            // col3
            // 
            this.col3.Text = "State";
            this.col3.Width = 50;
            // 
            // grpSpeed
            // 
            this.grpSpeed.Controls.Add(this.Fusion);
            this.grpSpeed.Controls.Add(this.TSM);
            this.grpSpeed.Controls.Add(this.panel2);
            this.grpSpeed.Controls.Add(this.cbMode);
            this.grpSpeed.Controls.Add(this.label7);
            this.grpSpeed.Controls.Add(this.cbRounds);
            this.grpSpeed.Controls.Add(this.cbKeySize);
            this.grpSpeed.Controls.Add(this.label6);
            this.grpSpeed.Controls.Add(this.label5);
            this.grpSpeed.Controls.Add(this.THX);
            this.grpSpeed.Controls.Add(this.panel1);
            this.grpSpeed.Controls.Add(this.TFX);
            this.grpSpeed.Controls.Add(this.RSM);
            this.grpSpeed.Controls.Add(this.Salsa20);
            this.grpSpeed.Controls.Add(this.lblCompileWarning);
            this.grpSpeed.Controls.Add(this.label3);
            this.grpSpeed.Controls.Add(this.SPX);
            this.grpSpeed.Controls.Add(this.SHX);
            this.grpSpeed.Controls.Add(this.RSX);
            this.grpSpeed.Controls.Add(this.RHX);
            this.grpSpeed.Controls.Add(this.RDX);
            this.grpSpeed.Controls.Add(this.DCS);
            this.grpSpeed.Controls.Add(this.ChaCha20);
            this.grpSpeed.Controls.Add(this.btnSpeedTest);
            this.grpSpeed.Controls.Add(this.txtSizeMB);
            this.grpSpeed.Controls.Add(this.lblSize);
            this.grpSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpSpeed.Location = new System.Drawing.Point(718, 12);
            this.grpSpeed.Name = "grpSpeed";
            this.grpSpeed.Size = new System.Drawing.Size(330, 430);
            this.grpSpeed.TabIndex = 27;
            this.grpSpeed.TabStop = false;
            this.grpSpeed.Text = "Cipher Speed Test";
            // 
            // TSM
            // 
            this.TSM.AutoSize = true;
            this.TSM.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TSM.Location = new System.Drawing.Point(14, 235);
            this.TSM.Name = "TSM";
            this.TSM.Size = new System.Drawing.Size(175, 17);
            this.TSM.TabIndex = 110;
            this.TSM.Text = "TSM (Twofish/Serpent Merge)";
            this.TSM.UseVisualStyleBackColor = true;
            this.TSM.CheckedChanged += new System.EventHandler(this.OnEngineChanged);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.chkParallel);
            this.panel2.Controls.Add(this.rdDecrypt);
            this.panel2.Controls.Add(this.rdEncrypt);
            this.panel2.Location = new System.Drawing.Point(6, 360);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(229, 28);
            this.panel2.TabIndex = 109;
            // 
            // chkParallel
            // 
            this.chkParallel.AutoSize = true;
            this.chkParallel.Checked = true;
            this.chkParallel.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkParallel.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkParallel.Location = new System.Drawing.Point(143, 9);
            this.chkParallel.Name = "chkParallel";
            this.chkParallel.Size = new System.Drawing.Size(77, 17);
            this.chkParallel.TabIndex = 104;
            this.chkParallel.Text = "Parallelize";
            this.chkParallel.UseVisualStyleBackColor = true;
            this.chkParallel.CheckedChanged += new System.EventHandler(this.OnParallelChanged);
            // 
            // rdDecrypt
            // 
            this.rdDecrypt.AutoSize = true;
            this.rdDecrypt.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdDecrypt.Location = new System.Drawing.Point(69, 8);
            this.rdDecrypt.Name = "rdDecrypt";
            this.rdDecrypt.Size = new System.Drawing.Size(64, 17);
            this.rdDecrypt.TabIndex = 103;
            this.rdDecrypt.Text = "Decrypt";
            this.rdDecrypt.UseVisualStyleBackColor = true;
            this.rdDecrypt.CheckedChanged += new System.EventHandler(this.OnEncryptChanged);
            // 
            // rdEncrypt
            // 
            this.rdEncrypt.AutoSize = true;
            this.rdEncrypt.Checked = true;
            this.rdEncrypt.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdEncrypt.Location = new System.Drawing.Point(3, 8);
            this.rdEncrypt.Name = "rdEncrypt";
            this.rdEncrypt.Size = new System.Drawing.Size(63, 17);
            this.rdEncrypt.TabIndex = 102;
            this.rdEncrypt.TabStop = true;
            this.rdEncrypt.Text = "Encrypt";
            this.rdEncrypt.UseVisualStyleBackColor = true;
            this.rdEncrypt.CheckedChanged += new System.EventHandler(this.OnEncryptChanged);
            // 
            // cbMode
            // 
            this.cbMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbMode.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbMode.FormattingEnabled = true;
            this.cbMode.Items.AddRange(new object[] {
            "CBC",
            "CTR"});
            this.cbMode.Location = new System.Drawing.Point(137, 334);
            this.cbMode.Name = "cbMode";
            this.cbMode.Size = new System.Drawing.Size(56, 21);
            this.cbMode.TabIndex = 107;
            this.cbMode.SelectedIndexChanged += new System.EventHandler(this.OnModeChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(99, 338);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 13);
            this.label7.TabIndex = 108;
            this.label7.Text = "Mode:";
            // 
            // cbRounds
            // 
            this.cbRounds.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbRounds.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbRounds.FormattingEnabled = true;
            this.cbRounds.Items.AddRange(new object[] {
            "8",
            "10",
            "12",
            "14",
            "16",
            "18",
            "20",
            "22",
            "24",
            "26",
            "28",
            "30"});
            this.cbRounds.Location = new System.Drawing.Point(247, 333);
            this.cbRounds.Name = "cbRounds";
            this.cbRounds.Size = new System.Drawing.Size(41, 21);
            this.cbRounds.TabIndex = 105;
            this.cbRounds.SelectedIndexChanged += new System.EventHandler(this.OnRoundsCountChanged);
            // 
            // cbKeySize
            // 
            this.cbKeySize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbKeySize.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbKeySize.FormattingEnabled = true;
            this.cbKeySize.Items.AddRange(new object[] {
            "128",
            "256",
            "384",
            "448"});
            this.cbKeySize.Location = new System.Drawing.Point(37, 333);
            this.cbKeySize.Name = "cbKeySize";
            this.cbKeySize.Size = new System.Drawing.Size(56, 21);
            this.cbKeySize.TabIndex = 102;
            this.cbKeySize.SelectedIndexChanged += new System.EventHandler(this.OnKeySizeChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(199, 338);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 13);
            this.label6.TabIndex = 106;
            this.label6.Text = "Rounds:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 337);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 13);
            this.label5.TabIndex = 104;
            this.label5.Text = "Key:";
            // 
            // THX
            // 
            this.THX.AutoSize = true;
            this.THX.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.THX.Location = new System.Drawing.Point(14, 217);
            this.THX.Name = "THX";
            this.THX.Size = new System.Drawing.Size(124, 17);
            this.THX.TabIndex = 103;
            this.THX.Text = "THX (Twofish HKDF)";
            this.THX.UseVisualStyleBackColor = true;
            this.THX.CheckedChanged += new System.EventHandler(this.OnEngineChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rdByteIo);
            this.panel1.Controls.Add(this.rdFileIo);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Location = new System.Drawing.Point(6, 273);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(299, 55);
            this.panel1.TabIndex = 101;
            // 
            // rdByteIo
            // 
            this.rdByteIo.AutoSize = true;
            this.rdByteIo.Checked = true;
            this.rdByteIo.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdByteIo.Location = new System.Drawing.Point(8, 36);
            this.rdByteIo.Name = "rdByteIo";
            this.rdByteIo.Size = new System.Drawing.Size(126, 17);
            this.rdByteIo.TabIndex = 102;
            this.rdByteIo.TabStop = true;
            this.rdByteIo.Text = "Encrypt a Byte Array";
            this.rdByteIo.UseVisualStyleBackColor = true;
            this.rdByteIo.CheckedChanged += new System.EventHandler(this.OnTestTypeCheckChanged);
            // 
            // rdFileIo
            // 
            this.rdFileIo.AutoSize = true;
            this.rdFileIo.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdFileIo.Location = new System.Drawing.Point(8, 17);
            this.rdFileIo.Name = "rdFileIo";
            this.rdFileIo.Size = new System.Drawing.Size(123, 17);
            this.rdFileIo.TabIndex = 101;
            this.rdFileIo.Text = "Encrypt a Temp File";
            this.rdFileIo.UseVisualStyleBackColor = true;
            this.rdFileIo.CheckedChanged += new System.EventHandler(this.OnTestTypeCheckChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(5, 1);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 13);
            this.label4.TabIndex = 97;
            this.label4.Text = "Test Type:";
            // 
            // TFX
            // 
            this.TFX.AutoSize = true;
            this.TFX.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TFX.Location = new System.Drawing.Point(14, 199);
            this.TFX.Name = "TFX";
            this.TFX.Size = new System.Drawing.Size(142, 17);
            this.TFX.TabIndex = 100;
            this.TFX.Text = "TFX (Twofish Extended)";
            this.TFX.UseVisualStyleBackColor = true;
            this.TFX.CheckedChanged += new System.EventHandler(this.OnEngineChanged);
            // 
            // RSM
            // 
            this.RSM.AutoSize = true;
            this.RSM.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RSM.Location = new System.Drawing.Point(14, 109);
            this.RSM.Name = "RSM";
            this.RSM.Size = new System.Drawing.Size(179, 17);
            this.RSM.TabIndex = 99;
            this.RSM.Text = "RSM (Rijndael/Serpent Merge)";
            this.RSM.UseVisualStyleBackColor = true;
            this.RSM.CheckedChanged += new System.EventHandler(this.OnEngineChanged);
            // 
            // Salsa20
            // 
            this.Salsa20.AutoSize = true;
            this.Salsa20.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Salsa20.Location = new System.Drawing.Point(14, 145);
            this.Salsa20.Name = "Salsa20";
            this.Salsa20.Size = new System.Drawing.Size(63, 17);
            this.Salsa20.TabIndex = 98;
            this.Salsa20.Text = "Salsa20";
            this.Salsa20.UseVisualStyleBackColor = true;
            this.Salsa20.CheckedChanged += new System.EventHandler(this.OnEngineChanged);
            // 
            // lblCompileWarning
            // 
            this.lblCompileWarning.AutoSize = true;
            this.lblCompileWarning.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompileWarning.Location = new System.Drawing.Point(129, 20);
            this.lblCompileWarning.Name = "lblCompileWarning";
            this.lblCompileWarning.Size = new System.Drawing.Size(184, 13);
            this.lblCompileWarning.TabIndex = 97;
            this.lblCompileWarning.Text = "(Compile in Release mode to test!)";
            this.lblCompileWarning.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(11, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 13);
            this.label3.TabIndex = 96;
            this.label3.Text = "Engines:";
            // 
            // SPX
            // 
            this.SPX.AutoSize = true;
            this.SPX.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SPX.Location = new System.Drawing.Point(14, 181);
            this.SPX.Name = "SPX";
            this.SPX.Size = new System.Drawing.Size(143, 17);
            this.SPX.TabIndex = 50;
            this.SPX.Text = "SPX (Serpent Extended)";
            this.SPX.UseVisualStyleBackColor = true;
            this.SPX.CheckedChanged += new System.EventHandler(this.OnEngineChanged);
            // 
            // SHX
            // 
            this.SHX.AutoSize = true;
            this.SHX.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SHX.Location = new System.Drawing.Point(14, 163);
            this.SHX.Name = "SHX";
            this.SHX.Size = new System.Drawing.Size(125, 17);
            this.SHX.TabIndex = 49;
            this.SHX.Text = "SHX (Serpent HKDF)";
            this.SHX.UseVisualStyleBackColor = true;
            this.SHX.CheckedChanged += new System.EventHandler(this.OnEngineChanged);
            // 
            // RSX
            // 
            this.RSX.AutoSize = true;
            this.RSX.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RSX.Location = new System.Drawing.Point(14, 127);
            this.RSX.Name = "RSX";
            this.RSX.Size = new System.Drawing.Size(159, 17);
            this.RSX.TabIndex = 48;
            this.RSX.Text = "RSX (Rijndael/Serpent Key)";
            this.RSX.UseVisualStyleBackColor = true;
            this.RSX.CheckedChanged += new System.EventHandler(this.OnEngineChanged);
            // 
            // RHX
            // 
            this.RHX.AutoSize = true;
            this.RHX.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RHX.Location = new System.Drawing.Point(14, 91);
            this.RHX.Name = "RHX";
            this.RHX.Size = new System.Drawing.Size(128, 17);
            this.RHX.TabIndex = 47;
            this.RHX.Text = "RHX (Rijndael HKDF)";
            this.RHX.UseVisualStyleBackColor = true;
            this.RHX.CheckedChanged += new System.EventHandler(this.OnEngineChanged);
            // 
            // RDX
            // 
            this.RDX.AutoSize = true;
            this.RDX.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RDX.Location = new System.Drawing.Point(14, 73);
            this.RDX.Name = "RDX";
            this.RDX.Size = new System.Drawing.Size(148, 17);
            this.RDX.TabIndex = 46;
            this.RDX.Text = "RDX (Rijndael Extended)";
            this.RDX.UseVisualStyleBackColor = true;
            this.RDX.CheckedChanged += new System.EventHandler(this.OnEngineChanged);
            // 
            // DCS
            // 
            this.DCS.AutoSize = true;
            this.DCS.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DCS.Location = new System.Drawing.Point(14, 55);
            this.DCS.Name = "DCS";
            this.DCS.Size = new System.Drawing.Size(109, 17);
            this.DCS.TabIndex = 45;
            this.DCS.Text = "Dual CTR Stream";
            this.DCS.UseVisualStyleBackColor = true;
            this.DCS.CheckedChanged += new System.EventHandler(this.OnEngineChanged);
            // 
            // ChaCha20
            // 
            this.ChaCha20.AutoSize = true;
            this.ChaCha20.Checked = true;
            this.ChaCha20.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChaCha20.Location = new System.Drawing.Point(14, 37);
            this.ChaCha20.Name = "ChaCha20";
            this.ChaCha20.Size = new System.Drawing.Size(77, 17);
            this.ChaCha20.TabIndex = 44;
            this.ChaCha20.TabStop = true;
            this.ChaCha20.Text = "ChaCha20";
            this.ChaCha20.UseVisualStyleBackColor = true;
            this.ChaCha20.CheckedChanged += new System.EventHandler(this.OnEngineChanged);
            // 
            // btnSpeedTest
            // 
            this.btnSpeedTest.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSpeedTest.Location = new System.Drawing.Point(241, 375);
            this.btnSpeedTest.Name = "btnSpeedTest";
            this.btnSpeedTest.Size = new System.Drawing.Size(72, 35);
            this.btnSpeedTest.TabIndex = 43;
            this.btnSpeedTest.Text = "Test";
            this.btnSpeedTest.UseVisualStyleBackColor = true;
            this.btnSpeedTest.Click += new System.EventHandler(this.OnSpeedTestClick);
            // 
            // txtSizeMB
            // 
            this.txtSizeMB.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSizeMB.Location = new System.Drawing.Point(64, 390);
            this.txtSizeMB.MaxLength = 4;
            this.txtSizeMB.Name = "txtSizeMB";
            this.txtSizeMB.Size = new System.Drawing.Size(32, 22);
            this.txtSizeMB.TabIndex = 38;
            this.txtSizeMB.Text = "10";
            this.txtSizeMB.TextChanged += new System.EventHandler(this.OnTextChanged);
            this.txtSizeMB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.OnTextBoxKeyPress);
            // 
            // lblSize
            // 
            this.lblSize.AutoSize = true;
            this.lblSize.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSize.Location = new System.Drawing.Point(12, 394);
            this.lblSize.Name = "lblSize";
            this.lblSize.Size = new System.Drawing.Size(50, 13);
            this.lblSize.TabIndex = 40;
            this.lblSize.Text = "Size MB:";
            // 
            // lblTestStatus
            // 
            this.lblTestStatus.AutoSize = true;
            this.lblTestStatus.Location = new System.Drawing.Point(126, 459);
            this.lblTestStatus.Name = "lblTestStatus";
            this.lblTestStatus.Size = new System.Drawing.Size(32, 13);
            this.lblTestStatus.TabIndex = 30;
            this.lblTestStatus.Text = "Idle..";
            // 
            // pbTestStatus
            // 
            this.pbTestStatus.Location = new System.Drawing.Point(13, 457);
            this.pbTestStatus.Name = "pbTestStatus";
            this.pbTestStatus.Size = new System.Drawing.Size(108, 16);
            this.pbTestStatus.TabIndex = 29;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 454);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1061, 22);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 28;
            // 
            // lblEngineTime
            // 
            this.lblEngineTime.AutoSize = true;
            this.lblEngineTime.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEngineTime.Location = new System.Drawing.Point(804, 459);
            this.lblEngineTime.Name = "lblEngineTime";
            this.lblEngineTime.Size = new System.Drawing.Size(22, 13);
            this.lblEngineTime.TabIndex = 36;
            this.lblEngineTime.Text = "0.0";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(724, 459);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(85, 13);
            this.label13.TabIndex = 37;
            this.label13.Text = "Time (m:s.ms): ";
            // 
            // Fusion
            // 
            this.Fusion.AutoSize = true;
            this.Fusion.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Fusion.Location = new System.Drawing.Point(14, 253);
            this.Fusion.Name = "Fusion";
            this.Fusion.Size = new System.Drawing.Size(191, 17);
            this.Fusion.TabIndex = 111;
            this.Fusion.Text = "Fusion (Twofish/Rijndael Merge)";
            this.Fusion.UseVisualStyleBackColor = true;
            this.Fusion.CheckedChanged += new System.EventHandler(this.OnEngineChanged);
            // 
            // FormTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1061, 476);
            this.Controls.Add(this.lblEngineTime);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.lblTestStatus);
            this.Controls.Add(this.pbTestStatus);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.grpSpeed);
            this.Controls.Add(this.grpTests);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormTest";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RDX Tests";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.OnFormClose);
            this.Load += new System.EventHandler(this.OnFormLoad);
            this.grpTests.ResumeLayout(false);
            this.grpTests.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.grpSpeed.ResumeLayout(false);
            this.grpSpeed.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpTests;
        private System.Windows.Forms.Button btnAlgoTest;
        private System.Windows.Forms.ListView lvAlgorithmTest;
        private System.Windows.Forms.ColumnHeader col1;
        private System.Windows.Forms.ColumnHeader col2;
        private System.Windows.Forms.ColumnHeader col3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grpSpeed;
        private System.Windows.Forms.Button btnSpeedTest;
        private System.Windows.Forms.TextBox txtSizeMB;
        private System.Windows.Forms.Label lblSize;
        private System.Windows.Forms.Label lblTestStatus;
        private System.Windows.Forms.ProgressBar pbTestStatus;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.CheckBox ModeVectors;
        private System.Windows.Forms.CheckBox RijndaelIO;
        private System.Windows.Forms.CheckBox AesMonteCarlo;
        private System.Windows.Forms.CheckBox RijndaelVector;
        private System.Windows.Forms.CheckBox ModePSCEquality;
        private System.Windows.Forms.CheckBox AesAvs;
        private System.Windows.Forms.CheckBox ChaChaVector;
        private System.Windows.Forms.CheckBox Sha3Vector;
        private System.Windows.Forms.CheckBox SalsaVector;
        private System.Windows.Forms.CheckBox HmacVector;
        private System.Windows.Forms.CheckBox HKDFVector;
        private System.Windows.Forms.CheckBox SerpentKey;
        private System.Windows.Forms.CheckBox SerpentVector;
        private System.Windows.Forms.CheckBox Sha2Vector;
        private System.Windows.Forms.RadioButton DCS;
        private System.Windows.Forms.RadioButton ChaCha20;
        private System.Windows.Forms.RadioButton SHX;
        private System.Windows.Forms.RadioButton RSX;
        private System.Windows.Forms.RadioButton RHX;
        private System.Windows.Forms.RadioButton RDX;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton SPX;
        private System.Windows.Forms.Label lblCompileWarning;
        private System.Windows.Forms.RadioButton Salsa20;
        private System.Windows.Forms.RadioButton RSM;
        private System.Windows.Forms.RadioButton TFX;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton rdByteIo;
        private System.Windows.Forms.RadioButton rdFileIo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox TwofishVector;
        private System.Windows.Forms.ComboBox cbKeySize;
        private System.Windows.Forms.ComboBox cbRounds;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton THX;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton rdDecrypt;
        private System.Windows.Forms.RadioButton rdEncrypt;
        private System.Windows.Forms.ComboBox cbMode;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblEngineTime;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.CheckBox chkParallel;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnLogBrowse;
        private System.Windows.Forms.CheckBox chkLogResults;
        private System.Windows.Forms.TextBox txtLogFile;
        private System.Windows.Forms.RadioButton rdLogConsole;
        private System.Windows.Forms.RadioButton rdLogFile;
        private System.Windows.Forms.RadioButton TSM;
        private System.Windows.Forms.RadioButton Fusion;
    }
}