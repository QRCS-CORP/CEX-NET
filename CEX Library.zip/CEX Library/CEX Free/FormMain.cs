﻿using System;
using System.ComponentModel;
using System.IO;
using System.Windows.Forms;
using VTDev.Libraries.CEXEngine.Crypto;
using VTDev.Libraries.CEXEngine.Crypto.Ciphers;
using VTDev.Libraries.CEXEngine.Crypto.Generators;
using VTDev.Libraries.CEXEngine.Crypto.Helpers;
using VTDev.Libraries.CEXEngine.Crypto.Modes;
using VTDev.Libraries.CEXEngine.Processing;
using VTDev.Libraries.CEXEngine.Utilities;

#region About
/// Permission is hereby granted, free of charge, to any person obtaining
/// a copy of this software and associated documentation files (the
/// "Software"), to deal in the Software without restriction, including
/// without limitation the rights to use, copy, modify, merge, publish,
/// distribute, sublicense, and/or sell copies of the Software, and to
/// permit persons to whom the Software is furnished to do so, subject to
/// the following conditions:
/// 
/// The above copyright notice and this permission notice shall be
/// included in all copies or substantial portions of the Software.
/// 
/// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
/// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
/// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
/// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
/// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
/// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
/// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
///
/// 
/// Portions of this code based on the Mono Project:
/// http://www.mono-project.com/
/// Portions of this code also based on Bouncy Castle Java release 1.51:
/// http://bouncycastle.org/latest_releases.html
/// 
/// 
/// ChaCha stream cipher designed by Daniel J. Bernstein.
/// White paper: http://cr.yp.to/chacha/chacha-20080128.pdf
/// Design: http://cr.yp.to/snuffle/design.pdf
/// 
/// Rijndael block cipher written by Joan Daemen and Vincent Rijmen.
/// Rijndael Specification: http://csrc.nist.gov/archive/aes/rijndael/Rijndael-ammended.pdf
/// AES specification Fips 197: http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf
///
/// Salsa20 stream cipher designed by Daniel J. Bernstein.
/// eStream: http://www.ecrypt.eu.org/stream/salsa20pf.html
/// Salsa20 security: http://cr.yp.to/snuffle/security.pdf
/// 
/// Serpent block cipher designed by Ross Anderson, Eli Biham and Lars Knudsen.
/// Serpent white paper: http://www.cl.cam.ac.uk/~rja14/Papers/serpent.pdf
/// 
/// SHA3 designed by Guido Bertoni, Joan Daemen, Michaël Peeters, and Gilles Van Assche.
/// http://keccak.noekeon.org/Keccak-submission-3.pdf
/// 
/// 
/// ***Cipher-EX***
/// Version 1.1.0.2, November 23, 2014
/// 
/// ChaCha+
/// An implementation of the ChaCha stream cipher,
/// using an extended key size, and higher variable rounds assignment.
/// Valid Key sizes are 128, 256, 384 and 448 (16, 32, 48 and 56 bytes).
/// Valid IV size is 8 bytes.
/// Valid rounds are 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28 and 30.
/// 
/// Rijndael Extended (RDX)
/// An extended implementation of the Rijndael encryption algorithm:
/// Valid Key sizes are 128, 192, 256, and 512 bit.
/// Valid block sizes are 16 and 32 byte wide.
/// 
/// Rijndael Serpent Extended (RSX)
/// An hybrid implementation of the Rijndael encryption algorithm,
/// using a Serpent key scheduler routine:
/// Valid Key sizes are 256, and 512 bit.
/// Valid block sizes are 16 and 32 byte wide.
/// 
/// Rijndael HKDF Extended (RHX)
/// An implementation based on the Rijndael block cipher,
/// using an HKDF generator with a SHA512 HMAC for expanded key generation.
/// Minimum key size is 192 bytes.
/// Valid Key sizes are 64 + multiples of 128 bytes (IKm + Salt).
/// Valid block sizes are 16 and 32 byte wide.
/// The number of Diffusion Rounds are configuarable.
/// Valid Rounds are 10 to 38, default is 22.
/// 
/// Rijndael + Serpent Merged Cryptographic Primitives (RS-MCP or just RSM)
/// Highly Experimental!
/// Minimum key size is 192 bytes.
/// Valid Key sizes are 64 + multiples of 128 bytes (IKm + Salt).
/// Valid block sizes are 16 and 32 byte wide.
/// The number of Diffusion Rounds are configuarable.
/// Valid Rounds assignments are 10, 18, 26, 34 and 42.
/// 
/// Salsa20+
/// An implementation of the Salsa20 stream cipher,
/// using an extended key size, and higher variable rounds assignment.
/// Valid Key sizes are 128, 256 and 384 and 448 (16, 32 48 and 56 bytes).
/// Valid IV size is 8 bytes.
/// Valid rounds are 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28 and 30.
/// 
/// Serpent Extended (SPX)
/// An extended implementation of the Serpent block cipher,
/// extended to 512 bit keys and 64 rounds.
/// Valid Key sizes are 128, 192, 256 and 512 bits (16, 24, 32 and 64 bytes).
/// Block size is 16 bytes wide.
/// 
/// Serpent HKDF Extended (SHX)
/// An implementation based on the Serpent block cipher,
/// using HKDF with a SHA512 HMAC for expanded key generation.
/// Minimum key size is 192 bytes.
/// Valid Key sizes are 64 + multiples of 128 bytes (IKm + Salt).
/// Valid block size is 16 bytes wide.
/// The number of Diffusion Rounds are configuarable.
/// Valid Rounds assignments are 32, 48, 64, 80, 96 and 128, default is 64.
/// 
/// Dual CTR Stream (DCS)
/// A stream cipher implementation using a dual AES CTR Xor
/// Valid Key size is 768 bit (96 bytes).
/// 
/// 
/// Written by John Underhill, September-November, 2014
/// contact: steppenwolfe_2000@yahoo.com
#endregion

#region Basic Library Usage
/// **Block Cipher**
/// encrypt a block size array using CTR mode
/// using (CTR enc = new CTR(new RDX())
/// {
///     enc.Init(true, new KeyParams(Key, IV));
///     enc.Transform(inbytes, outbytes);
/// }
/// 
/// decrypt a block size array using CBC mode
/// using (CBC dec = new CBC(new TFX())
/// {
///     dec.Init(true, new KeyParams(Key, IV));
///     dec.DecryptBlock(inbytes, outbytes);
/// }
/// 
/// **Stream Cipher**
/// encrypt/decrypt an array
/// using (DCS dcs = new DCS())
/// {
///     dcs.Init(new KeyParams(key, iv));
///     dcs.Transform(inbytes, outbytes);
/// }
/// 
/// **Random Generator**
/// create an array of p-rand
/// using (CTRDRBG rand = new CTRDRBG(new RHX()))
/// {
///     int kSz = rand.KeySize;
///     byte[] key = KeyGenerator.GenerateKey(kSz);
///     rand.Init(key);
///     rand.Generate(2048, outbytes);
/// }
/// 
/// **Digests**
/// get a hash value
/// using (SHA512Digest sha = new SHA512Digest())
///     byte[] hash = sha.ComputeHash(inbytes);
///     
/// **HMAC**
/// get a hash from an sha3 hmac
/// using (HMAC hmac = new HMAC(new SHA3Digest(512), key))
///     return hmac.ComputeMac(data);
#endregion

namespace VTDev.Projects.CEX
{
    public partial class FormMain : Form
    {
        #region Constants
        private const string ALL_FILT = "All Files | *.*";
        private const string CENC_EXT = ".cen";
        private const string CKEY_EXT = ".ckey";
        private const string KEY_DEF = "Key";
        private const string FILE_DEFN = "[Select a File to Encrypt or Decrypt]";
        private const string FILE_DESC = "Select a File to Encrypt or Decrypt";
        private const string FOLD_DEFN = "[Save Key File As]";
        private const string FOLD_DESC = "Choose a Key Name and Path";
        private const string KPTH_DEFN = "[Save Key File As]";
        private const string KPTH_DESC = "Save Key File As";
        private const string KEY_DEFN = "[Select a Key File]";
        private const string KEY_DESC = "Select a Key File";
        private const string KEY_FILT = "Key File | *.ckey";
        private const string KEY_NAME = "Key";
        private const string SAVE_DEFN = "[Save File to Destination]";
        private const string SAVE_DESC = "Save File As";
        #endregion

        #region Fields
        private BackgroundWorker _transformWorker = new BackgroundWorker();
        #endregion

        #region Properties
        private Engines Engine { get; set; }
        private BlockSizes BlockSize { get; set; }
        private CipherModes CipherMode { get; set; }
        private PaddingModes PaddingMode { get; set; }
        private RoundCounts RoundCount { get; set; }
        private string InputPath { get; set; }
        private bool IsEncryption { get; set; }
        private bool IsParallel { get; set; }
        private bool IsSigned { get; set; }
        private string KeyFilePath { get; set; }
        private KeySizes KeySize { get; set; }
        private string LastInputPath { get; set; }
        private string LastOutputPath { get; set; }
        private string LastKeyPath { get; set; }
        private string OutputPath { get; set; }
        private IVSizes IVSize { get; set; }
        #endregion

        #region Constructor
        public FormMain()
        {
            InitializeComponent();

            lblTest.Text = SpeedTest(new Action(TestDelete), 1);
        }

        private void TestDelete()
        {
            using (VTDev.Libraries.CEXEngine.Security.SecureDelete sd = new VTDev.Libraries.CEXEngine.Security.SecureDelete())
                sd.Delete(@"C:\Tests\Saved\test.avi");
        }
        #endregion

        #region Crypto
        private byte[] CreateKey()
        {
            if (this.Engine == Engines.DCS)
                return KeyGenerator.Generate(96);
            else if (this.KeySize == KeySizes.K128)
                return KeyGenerator.Generate(16);
            else if (this.KeySize == KeySizes.K192)
                return KeyGenerator.Generate(24);
            else if (this.KeySize == KeySizes.K256)
                return KeyGenerator.Generate(32);
            else if (this.KeySize == KeySizes.K384)
                return KeyGenerator.Generate(48);
            else if (this.KeySize == KeySizes.K448)
                return KeyGenerator.Generate(56);
            else if (this.KeySize == KeySizes.K512)
                return KeyGenerator.Generate(64);
            else if (this.KeySize == KeySizes.K1024)
                return KeyGenerator.Generate(128, true);
            else if (this.KeySize == KeySizes.K1536)
                return KeyGenerator.Generate(192, true);
            else if (this.KeySize == KeySizes.K2560)
                return KeyGenerator.Generate(320, true);
            else if (this.KeySize == KeySizes.K3584)
                return KeyGenerator.Generate(448, true);
            else if (this.KeySize == KeySizes.K4608)
                return KeyGenerator.Generate(576, true);
            else
                return KeyGenerator.GenerateKey(32);
        }

        private byte[] CreateIV()
        {
            if (this.BlockSize == BlockSizes.B128)
                return KeyGenerator.Generate(16);
            if (this.BlockSize == BlockSizes.B256)
                return KeyGenerator.Generate(32);
            else
                return KeyGenerator.Generate(8);
        }

        private void Decrypt()
        {
            using (Transform dec = new Transform(this.KeyFilePath))
            {
                dec.IsParallel = this.IsParallel;
                dec.ProgressCounter -= OnProgressCounter;
                dec.ProgressCounter += new Transform.ProgressCounterDelegate(OnProgressCounter);

                try
                {
                    string extension = GetMessageExtension(this.InputPath, this.KeyFilePath);
                    this.OutputPath = Utilities.GetUniquePath(this.OutputPath + extension);

                    if (this.IsSigned && IsValidHash(this.InputPath))
                    {
                        if (!dec.Verify(this.InputPath, this.KeyFilePath))
                        {
                            MessageBox.Show("Message hash does not match! The file has been tampered with.");
                            return;
                        }
                    }

                    // decrypt the message
                    dec.Decrypt(this.InputPath, this.OutputPath);
                }
                catch (Exception ex)
                {
                    if (File.Exists(this.OutputPath))
                        File.Delete(this.OutputPath);

                    string message = ex.Message == null ? "" : ex.Message;
                    MessageBox.Show("An error occured, the file could not be decrypted! " + message);
                }
            }
        }

        private void Encrypt()
        {
            using (Transform enc = new Transform(this.KeyFilePath))
            {
                enc.IsParallel = this.IsParallel;
                enc.ProgressCounter -= OnProgressCounter;
                enc.ProgressCounter += new Transform.ProgressCounterDelegate(OnProgressCounter);
                // put an optional clause here if you want to disable
                // on large files, e.g. over 1GB, or add a progress step
                enc.IsSigned = this.IsSigned;

                try
                {
                    enc.Encrypt(this.InputPath, this.OutputPath);
                }
                catch (Exception ex)
                {
                    if (File.Exists(this.OutputPath))
                        File.Delete(this.OutputPath);

                    string message = ex.Message == null ? "" : ex.Message;
                    MessageBox.Show("An error occured, the file could not be encrypted! " + message);
                }
            }
        }

        private string GetMessageExtension(string MessagePath, string KeyPath)
        {
            if (IsValidMessage(MessagePath))
            {
                return MessageHeader.GetExtension(MessagePath, KeyHeader.GetExtRandom(KeyPath));
            }
            return "";
        }

        private bool IsValidHash(string MessagePath)
        {
            byte[] hash = MessageHeader.GetMessageHash(MessagePath);

            if (hash.Length < 1)
                return false;
            int ct = 0;

            for (int i = 0; i < hash.Length; i++)
                if (hash[i] == (byte)0)
                    ct++;

            return ct < hash.Length;
        }


        private bool IsValidMessage(string MessagePath)
        {
            return MessageHeader.HasHeader(MessagePath);
        }
        #endregion

        #region Helpers
        private void EnabledState(bool State)
        {
            grpKey.Enabled = State;
            grpOutput.Enabled = State;
        }

        private long FileGetSize(string FilePath)
        {
            try
            {
                return File.Exists(FilePath) ? new FileInfo(FilePath).Length : 0;
            }
            catch { }
            return -1;
        }

        private int GetBlockSize()
        {
            if (this.BlockSize == BlockSizes.B128)
                return 16;
            else
                return 32;
        }

        private string GetFileOpenPath(string Description, string Filter = ALL_FILT, string DefaultDirectory = "")
        {
            using (OpenFileDialog openDialog = new OpenFileDialog())
            {
                openDialog.AutoUpgradeEnabled = false;
                openDialog.CheckFileExists = true;
                openDialog.Filter = Filter;

                if (!string.IsNullOrEmpty(DefaultDirectory))
                    openDialog.InitialDirectory = DefaultDirectory;

                openDialog.RestoreDirectory = true;
                openDialog.Title = Description;

                if (openDialog.ShowDialog() == DialogResult.OK)
                    return openDialog.FileName;
            }

            return string.Empty;
        }

        private string GetFileSavePath(string Description, string Filter = ALL_FILT, string FileName = "", string DefaultDirectory = "")
        {
            using (SaveFileDialog saveDialog = new SaveFileDialog())
            {
                saveDialog.AddExtension = true;
                saveDialog.AutoUpgradeEnabled = false;
                saveDialog.CheckPathExists = true;
                saveDialog.Filter = Filter;
                saveDialog.FileName = FileName;

                if (!string.IsNullOrEmpty(DefaultDirectory))
                    saveDialog.InitialDirectory = DefaultDirectory;

                saveDialog.OverwritePrompt = true;
                saveDialog.Title = Description;
                saveDialog.RestoreDirectory = true;

                if (saveDialog.ShowDialog() == DialogResult.OK)
                    return saveDialog.FileName;
            }

            return string.Empty;
        }

        private bool IsMatchingKey(string MessagePath, string KeyPath)
        {
            if (File.Exists(MessagePath) && File.Exists(KeyPath))
            {
                Guid messageId = MessageHeader.GetMessageId(MessagePath);
                Guid keyId = KeyHeader.GetKeyId(KeyPath);
                return messageId.Equals(keyId);
            }

            return false;
        }

        private void Reset()
        {
            txtInputFile.Text = FILE_DEFN;
            txtKeyFile.Text = KEY_DEFN;
            txtOutputFile.Text = SAVE_DEFN;
            this.InputPath = string.Empty;
            this.KeyFilePath = string.Empty;
            this.OutputPath = string.Empty;
            this.IsParallel = Environment.ProcessorCount > 1;
            chkParallelize.Checked = this.IsParallel;
            lblStatus.Text = "Waiting..";
            pbStatus.Value = 0;
            btnEncrypt.Enabled = false;
            btnKeyFile.Enabled = false;
            btnOutputFile.Enabled = false;
        }

        private void SaveKey()
        {
            try
            {
                IVSizes ivSize = IVSizes.V64;
                // seperate iv and block sizes for buffered feedback modes
                if (this.Engine != Engines.ChaCha && this.Engine != Engines.Salsa)
                    ivSize = this.BlockSize == BlockSizes.B128 ? IVSizes.V128 : IVSizes.V256;
                // create and populate key header
                KeyHeaderStruct keyHeader = new KeyHeaderStruct(this.Engine, this.KeySize, ivSize, this.CipherMode, this.PaddingMode, this.BlockSize, this.RoundCount);
                MemoryStream keyStream = (MemoryStream)KeyHeader.SerializeHeader(keyHeader);

                using (BinaryWriter outputWriter = new BinaryWriter(new FileStream(this.KeyFilePath, FileMode.Create, FileAccess.Write, FileShare.None)))
                {
                    // write key header
                    outputWriter.Write(keyStream.ToArray());
                    // write the key
                    outputWriter.Write(CreateKey());
                    // write the iv
                    if (this.Engine != Engines.DCS && this.CipherMode != CipherModes.None)
                        outputWriter.Write(CreateIV());
                }

                if (!string.IsNullOrEmpty(this.KeyFilePath))
                    this.LastKeyPath = Path.GetDirectoryName(this.KeyFilePath);

                Reset();
                lblStatus.Text = "The Key has been saved!";
            }
            catch(Exception ex)
            {
                if (File.Exists(this.KeyFilePath))
                    File.Delete(this.KeyFilePath);

                string message = ex.Message == null ? "" : ex.Message;
                MessageBox.Show("An error occured, the key could not be created! " + message);
            }
        }
        #endregion

        #region Event Handlers
        private void OnAlgorithmChanged(object sender, EventArgs e)
        {
            ComboBox cb = sender as ComboBox;

            cbCipherMode.Enabled = true;
            cbCipherMode.Items.Clear();
            cbCipherMode.Items.Add("CBC");
            cbCipherMode.Items.Add("CTR");
            cbCipherMode.SelectedIndex = 0;
            cbKeySize.Enabled = true;
            cbKeySize.SelectedIndex = 2;
            cbPaddingMode.Enabled = true;
            cbPaddingMode.SelectedIndex = 0;
            cbRounds.Enabled = false;
            cbVectorSize.Enabled = true;
            cbVectorSize.Items.Clear();
            cbVectorSize.Items.Add("V128");
            cbVectorSize.Items.Add("V256");
            cbVectorSize.SelectedIndex = 0;


            if (cb.Text.Equals("ChaCha") || cb.Text.Equals("Salsa20"))
            {
                if (cb.Text.Equals("ChaCha"))
                    this.Engine = Engines.ChaCha;
                else
                    this.Engine = Engines.Salsa;

                cbCipherMode.Enabled = false;
                cbKeySize.Enabled = true;
                cbKeySize.Items.Clear();
                cbKeySize.Items.Add("K128");
                cbKeySize.Items.Add("K256");
                cbKeySize.Items.Add("K384");
                cbKeySize.Items.Add("K448");
                cbKeySize.SelectedIndex = 1;
                cbPaddingMode.Enabled = false;
                cbRounds.Enabled = true;
                cbRounds.Items.Clear();
                cbRounds.Items.Add("R8");
                cbRounds.Items.Add("R10");
                cbRounds.Items.Add("R12");
                cbRounds.Items.Add("R14");
                cbRounds.Items.Add("R16");
                cbRounds.Items.Add("R18");
                cbRounds.Items.Add("R20");
                cbRounds.Items.Add("R22");
                cbRounds.Items.Add("R24");
                cbRounds.Items.Add("R26");
                cbRounds.Items.Add("R28");
                cbRounds.Items.Add("R30");
                cbRounds.SelectedIndex = 6;
                cbVectorSize.Enabled = true;
                cbVectorSize.Items.Clear();
                cbVectorSize.Items.Add("V64");
                cbVectorSize.SelectedIndex = 0;
            }
            else if (cb.Text.Equals("DCS"))
            {
                this.Engine = Engines.DCS;
                cbCipherMode.Enabled = false;
                cbKeySize.Enabled = false;
                cbVectorSize.Enabled = false;
                cbPaddingMode.Enabled = false;
            }
            else if (cb.Text.Equals("RDX"))
            {
                this.Engine = Engines.RDX;
                cbKeySize.Items.Clear();
                cbKeySize.Items.Add("K128");
                cbKeySize.Items.Add("K256");
                cbKeySize.Items.Add("K512");
                cbKeySize.SelectedIndex = 1;
            }
            else if (cb.Text.Equals("RSX"))
            {
                this.Engine = Engines.RSX;
                cbCipherMode.Items.Clear();
                cbCipherMode.Items.Add("CBC");
                cbCipherMode.Items.Add("CTR");
                cbCipherMode.SelectedIndex = 0;
                cbKeySize.Items.Clear();
                cbKeySize.Items.Add("K256");
                cbKeySize.Items.Add("K512");
                cbKeySize.SelectedIndex = 0;
            }
            else if (cb.Text.Equals("RHX"))
            {
                this.Engine = Engines.RHX;
                cbKeySize.Items.Clear();
                cbKeySize.Items.Add("K1536");
                cbKeySize.Items.Add("K2560");
                cbKeySize.Items.Add("K3584");
                cbKeySize.Items.Add("K4608");
                cbKeySize.SelectedIndex = 0;
                cbRounds.Enabled = true;
                cbRounds.Items.Clear();
                cbRounds.Items.Add("R10");
                cbRounds.Items.Add("R14");
                cbRounds.Items.Add("R22");
                cbRounds.Items.Add("R38");
                cbRounds.SelectedIndex = 2;
            }
            else if (cb.Text.Equals("RSM"))
            {
                this.Engine = Engines.RSM;
                cbCipherMode.Items.Clear();
                cbCipherMode.Items.Add("CBC");
                cbCipherMode.Items.Add("CTR");
                cbCipherMode.SelectedIndex = 1;
                cbKeySize.Items.Clear();
                cbKeySize.Items.Add("K1536");
                cbKeySize.Items.Add("K2560");
                cbKeySize.Items.Add("K3584");
                cbKeySize.Items.Add("K4608");
                cbKeySize.SelectedIndex = 0;
                cbRounds.Enabled = true;
                cbRounds.Items.Clear();
                cbRounds.Items.Add("R10");
                cbRounds.Items.Add("R18");
                cbRounds.Items.Add("R26");
                cbRounds.Items.Add("R34");
                cbRounds.Items.Add("R42");
                cbRounds.SelectedIndex = 1;
            }
            else if (cb.Text.Equals("SPX"))
            {
                this.Engine = Engines.SPX;
                cbCipherMode.Items.Clear();
                cbCipherMode.Items.Add("CBC");
                cbCipherMode.Items.Add("CTR");
                cbCipherMode.SelectedIndex = 0;
                cbKeySize.Items.Clear();
                cbKeySize.Items.Add("K128");
                cbKeySize.Items.Add("K256");
                cbKeySize.Items.Add("K512");
                cbKeySize.SelectedIndex = 1;
                cbRounds.Enabled = true;
                cbRounds.Items.Clear();
                cbRounds.Items.Add("R32");
                cbRounds.Items.Add("R40");
                cbRounds.Items.Add("R48");
                cbRounds.Items.Add("R56");
                cbRounds.Items.Add("R64");
                cbRounds.SelectedIndex = 0;
                cbVectorSize.Items.Clear();
                cbVectorSize.Items.Add("V128");
                cbVectorSize.SelectedIndex = 0;
            }
            else if (cb.Text.Equals("SHX"))
            {
                this.Engine = Engines.SHX;
                cbCipherMode.Items.Clear();
                cbCipherMode.Items.Add("CBC");
                cbCipherMode.Items.Add("CTR");
                cbCipherMode.SelectedIndex = 0;
                cbKeySize.Items.Clear();
                cbKeySize.Items.Add("K1536");
                cbKeySize.Items.Add("K2560");
                cbKeySize.Items.Add("K3584");
                cbKeySize.Items.Add("K4608");
                cbKeySize.SelectedIndex = 0;
                cbRounds.Enabled = true;
                cbRounds.Items.Clear();
                cbRounds.Items.Add("R32");
                cbRounds.Items.Add("R40");
                cbRounds.Items.Add("R48");
                cbRounds.Items.Add("R56");
                cbRounds.Items.Add("R64");
                cbRounds.Items.Add("R80");
                cbRounds.Items.Add("R96");
                cbRounds.Items.Add("R128");
                cbRounds.SelectedIndex = 0;
                cbVectorSize.Items.Clear();
                cbVectorSize.Items.Add("V128");
                cbVectorSize.SelectedIndex = 0;
            }
            else if (cb.Text.Equals("TFX"))
            {
                this.Engine = Engines.TFX;
                cbKeySize.Items.Clear();
                cbKeySize.Items.Add("K128");
                cbKeySize.Items.Add("K192");
                cbKeySize.Items.Add("K256");
                cbKeySize.Items.Add("K512");
                cbKeySize.SelectedIndex = 1;
                cbRounds.Items.Clear();
                cbRounds.Items.Add("R16");
                cbRounds.Items.Add("R18");
                cbRounds.Items.Add("R20");
                cbRounds.Items.Add("R22");
                cbRounds.Items.Add("R24");
                cbRounds.Items.Add("R26");
                cbRounds.Items.Add("R28");
                cbRounds.Items.Add("R30");
                cbRounds.Items.Add("R32");
                cbRounds.SelectedIndex = 0;
                cbVectorSize.Items.Clear();
                cbVectorSize.Items.Add("V128");
                cbVectorSize.SelectedIndex = 0;
            }
            else if (cb.Text.Equals("THX"))
            {
                this.Engine = Engines.THX;
                cbCipherMode.Items.Clear();
                cbCipherMode.Items.Add("CBC");
                cbCipherMode.Items.Add("CTR");
                cbCipherMode.SelectedIndex = 0;
                cbKeySize.Items.Clear();
                cbKeySize.Items.Add("K1536");
                cbKeySize.Items.Add("K2560");
                cbKeySize.Items.Add("K3584");
                cbKeySize.Items.Add("K4608");
                cbKeySize.SelectedIndex = 0;
                cbRounds.Enabled = true;
                cbRounds.Items.Clear();
                cbRounds.Items.Add("R16");
                cbRounds.Items.Add("R18");
                cbRounds.Items.Add("R20");
                cbRounds.Items.Add("R22");
                cbRounds.Items.Add("R24");
                cbRounds.Items.Add("R26");
                cbRounds.Items.Add("R28");
                cbRounds.Items.Add("R30");
                cbRounds.Items.Add("R32");
                cbRounds.SelectedIndex = 0;
                cbVectorSize.Items.Clear();
                cbVectorSize.Items.Add("V128");
                cbVectorSize.SelectedIndex = 0;
            }
            else if (cb.Text.Equals("TSM"))
            {
                this.Engine = Engines.TSM;
                cbCipherMode.Items.Clear();
                cbCipherMode.Items.Add("CBC");
                cbCipherMode.Items.Add("CTR");
                cbCipherMode.SelectedIndex = 0;
                cbKeySize.Items.Clear();
                cbKeySize.Items.Add("K1536");
                cbKeySize.Items.Add("K2560");
                cbKeySize.Items.Add("K3584");
                cbKeySize.Items.Add("K4608");
                cbKeySize.SelectedIndex = 0;
                cbRounds.Enabled = true;
                cbRounds.Items.Clear();
                cbRounds.Items.Add("R16");
                cbRounds.Items.Add("R18");
                cbRounds.Items.Add("R20");
                cbRounds.Items.Add("R22");
                cbRounds.Items.Add("R24");
                cbRounds.Items.Add("R26");
                cbRounds.Items.Add("R28");
                cbRounds.Items.Add("R30");
                cbRounds.Items.Add("R32");
                cbRounds.SelectedIndex = 0;
                cbVectorSize.Items.Clear();
                cbVectorSize.Items.Add("V128");
                cbVectorSize.SelectedIndex = 0;
            }
        }

        private void OnCipherModeChanged(object sender, EventArgs e)
        {
            ComboBox cb = sender as ComboBox;

            if (cb.Text == "CBC")
                this.CipherMode = CipherModes.CBC;
            else if (cb.Text == "CTR")
                this.CipherMode = CipherModes.CTR;
            else
                this.CipherMode = CipherModes.ECB;
        }

        private void OnFormClose(object sender, FormClosingEventArgs e)
        {
            _transformWorker.Dispose();
            SaveSettings();
        }

        private void OnFormLoad(object sender, EventArgs e)
        {
            Reset();
            LoadSettings();

            _transformWorker.DoWork += OnTransformDoWork;
            _transformWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(TransformWorkerCompleted);
        }

        private void OnInputFileClick(object sender, EventArgs e)
        {
            Reset();

            string inputFile = GetFileOpenPath(FILE_DESC, ALL_FILT, this.LastInputPath);

            if (!string.IsNullOrEmpty(inputFile) && File.Exists(inputFile))
            {
                this.InputPath = inputFile;
                txtInputFile.Text = this.InputPath;
                btnOutputFile.Enabled = true;

                if (!string.IsNullOrEmpty(this.InputPath))
                    this.LastInputPath = Path.GetDirectoryName(this.InputPath);

                if (this.InputPath.Contains(CENC_EXT))
                {
                    btnEncrypt.Text = "Decrypt";
                    this.IsEncryption = false;
                }
                else
                {
                    btnEncrypt.Text = "Encrypt";
                    this.IsEncryption = true;
                }

                string folderPath = Path.GetDirectoryName(inputFile);

                if (Utilities.DirectoryIsWritable(folderPath))
                {
                    if (this.IsEncryption)
                    {
                        string extension = Path.GetExtension(inputFile);
                        string fileName = Path.GetFileNameWithoutExtension(inputFile);
                        this.OutputPath = Utilities.GetUniquePath(folderPath, fileName, CENC_EXT);
                    }
                    else
                    {
                        this.OutputPath = Path.Combine(Path.GetDirectoryName(inputFile), Path.GetFileNameWithoutExtension(inputFile));
                    }

                    txtOutputFile.Text = this.OutputPath;
                    btnKeyFile.Enabled = true;
                }
            }
            else
            {
                btnOutputFile.Enabled = false;
                btnKeyFile.Enabled = false;
            }
        }

        private void OnKeyCreateClick(object sender, EventArgs e)
        {
            Reset();

            string filePath = GetFileSavePath(KPTH_DESC, KEY_FILT, KEY_DEF, this.LastKeyPath);
            if (string.IsNullOrEmpty(filePath)) return;

            if (!Utilities.DirectoryIsWritable(Path.GetDirectoryName(filePath)))
            {
                MessageBox.Show("You do not have permission to create files in this directory! Choose a different path..");
                this.KeyFilePath = string.Empty;
            }
            else
            {
                this.KeyFilePath = Utilities.GetUniquePath(filePath);
                if (!string.IsNullOrEmpty(this.KeyFilePath))
                    this.LastKeyPath = Path.GetDirectoryName(this.KeyFilePath);

                SaveKey();
            }
        }

        private void OnKeySizeChanged(object sender, EventArgs e)
        {
            ComboBox cb = sender as ComboBox;

            if (cb.Text == "K128")
                this.KeySize = KeySizes.K128;
            else if (cb.Text == "K192")
                this.KeySize = KeySizes.K192;
            else if (cb.Text == "K256")
                this.KeySize = KeySizes.K256;
            else if (cb.Text == "K384")
                this.KeySize = KeySizes.K384;
            else if (cb.Text == "K448")
                this.KeySize = KeySizes.K448;
            else if (cb.Text == "K512")
                this.KeySize = KeySizes.K512;
            else if (cb.Text == "K1024")
                this.KeySize = KeySizes.K1024;
            else if (cb.Text == "K1536")
                this.KeySize = KeySizes.K1536;
            else if (cb.Text == "K2560")
                this.KeySize = KeySizes.K2560;
            else if (cb.Text == "K3584")
                this.KeySize = KeySizes.K3584;
            else if (cb.Text == "K4608")
                this.KeySize = KeySizes.K4608;
            else
                this.KeySize = KeySizes.K512;
        }

        private void OnMenuAboutClick(object sender, EventArgs e)
        {
            FormAbout ft = new FormAbout();
            ft.ShowDialog(this);
        }

        private void OnMenuTestClick(object sender, EventArgs e)
        {
            FormTest ft = new FormTest();
            ft.ShowDialog(this);
        }

        private void OnOutputFileClick(object sender, EventArgs e)
        {
            string filePath = GetFileSavePath(SAVE_DESC, ALL_FILT, "", this.LastOutputPath);
            if (string.IsNullOrEmpty(filePath)) return;

            if (!Utilities.DirectoryIsWritable(Path.GetDirectoryName(filePath)))
            {
                MessageBox.Show("You do not have permission to create files in this directory! Choose a different path..");
                txtOutputFile.Text = SAVE_DEFN;
                this.OutputPath = string.Empty;
                btnKeyFile.Enabled = false;
            }
            else
            {
                this.OutputPath = Utilities.GetUniquePath(filePath);
                if (!string.IsNullOrEmpty(this.OutputPath))
                    this.LastOutputPath = Path.GetDirectoryName(this.OutputPath);
                txtOutputFile.Text = this.OutputPath;
                btnKeyFile.Enabled = true;
            }
        }

        private void OnPaddingModeChanged(object sender, EventArgs e)
        {
            ComboBox cb = sender as ComboBox;

            if (cb.Text == "PKCS7")
                this.PaddingMode = PaddingModes.PKCS7;
            else if (cb.Text == "X923")
                this.PaddingMode = PaddingModes.X923;
            else
                this.PaddingMode = PaddingModes.Zeros;
        }

        private void OnPararallelChanged(object sender, EventArgs e)
        {
            CheckBox chk = sender as CheckBox;
            this.IsParallel = chk.Checked;
        }

        private void OnProgressCounter(int Count)
        {
            if (this.IsHandleCreated)
                pbStatus.Invoke(new MethodInvoker(delegate { pbStatus.Value = Count; }));
        }

        private void OnRoundsChanged(object sender, EventArgs e)
        {
            ComboBox cb = sender as ComboBox;

            if (cb.Text == "R8")
                this.RoundCount = RoundCounts.R8;
            else if (cb.Text == "R10")
                this.RoundCount = RoundCounts.R10;
            else if (cb.Text == "R12")
                this.RoundCount = RoundCounts.R12;
            else if (cb.Text == "R14")
                this.RoundCount = RoundCounts.R14;
            else if (cb.Text == "R16")
                this.RoundCount = RoundCounts.R16;
            else if (cb.Text == "R18")
                this.RoundCount = RoundCounts.R18;
            else if (cb.Text == "R20")
                this.RoundCount = RoundCounts.R20;
            else if (cb.Text == "R22")
                this.RoundCount = RoundCounts.R22;
            else if (cb.Text == "R24")
                this.RoundCount = RoundCounts.R24;
            else if (cb.Text == "R26")
                this.RoundCount = RoundCounts.R26;
            else if (cb.Text == "R28")
                this.RoundCount = RoundCounts.R28;
            else if (cb.Text == "R30")
                this.RoundCount = RoundCounts.R30;
            else if (cb.Text == "R32")
                this.RoundCount = RoundCounts.R32;
            else if (cb.Text == "R34")
                this.RoundCount = RoundCounts.R34;
            else if (cb.Text == "R38")
                this.RoundCount = RoundCounts.R38;
            else if (cb.Text == "R40")
                this.RoundCount = RoundCounts.R40;
            else if (cb.Text == "R42")
                this.RoundCount = RoundCounts.R42;
            else if (cb.Text == "R48")
                this.RoundCount = RoundCounts.R48;
            else if (cb.Text == "R56")
                this.RoundCount = RoundCounts.R56;
            else if (cb.Text == "R64")
                this.RoundCount = RoundCounts.R64;
            else if (cb.Text == "R80")
                this.RoundCount = RoundCounts.R80;
            else if (cb.Text == "R96")
                this.RoundCount = RoundCounts.R96;
            else if (cb.Text == "R128")
                this.RoundCount = RoundCounts.R128;
        }

        private void OnSelectKeyClick(object sender, EventArgs e)
        {
            string keyFile = GetFileOpenPath(KEY_DESC, KEY_FILT, this.LastKeyPath);

            if (string.IsNullOrEmpty(keyFile)) return;

            if (!this.IsEncryption)
            {
                if (IsMatchingKey(this.InputPath, keyFile))
                {
                    this.KeyFilePath = keyFile;
                    txtKeyFile.Text = keyFile;
                    btnEncrypt.Enabled = true;
                }
                else
                {
                    this.KeyFilePath = string.Empty;
                    txtKeyFile.Text = KEY_DEFN;
                    btnEncrypt.Enabled = false;
                    MessageBox.Show("Key does not match the message! Choose a different key..");
                }
            }
            else
            {
                this.KeyFilePath = keyFile;
                txtKeyFile.Text = this.KeyFilePath;
                btnEncrypt.Enabled = true;
            }

            if (!string.IsNullOrEmpty(this.KeyFilePath))
                this.LastKeyPath = Path.GetDirectoryName(this.KeyFilePath);
        }

        private void OnSignCheckedChanged(object sender, EventArgs e)
        {
            CheckBox chk = sender as CheckBox;
            if (chk == null) return;

            this.IsSigned = chk.Checked;
        }

        private void OnTransformClick(object sender, EventArgs e)
        {
            lblStatus.Text = "Transforming output..";
            EnabledState(false);
            _transformWorker.RunWorkerAsync();
        }

        private void OnTransformDoWork(object sender, DoWorkEventArgs e)
        {
            if (this.IsEncryption)
                Encrypt();
            else
                Decrypt();
        }

        private void TransformWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            EnabledState(true);
            Reset();

            if (this.IsEncryption)
                lblStatus.Text = "The File has been Encrypted..";
            else
                lblStatus.Text = "The File has been Decrypted..";
        }

        private void OnVectorSizeChanged(object sender, EventArgs e)
        {
            ComboBox cb = sender as ComboBox;

            if (cb.Text.Equals("V128"))
                this.BlockSize = BlockSizes.B128;
            else if (cb.Text.Equals("V256"))
                this.BlockSize = BlockSizes.B256;
            else
                this.BlockSize = BlockSizes.B512;
        }
        #endregion

        #region Settings
        private void LoadDefaults()
        {
            this.Engine = Engines.RDX;
            this.BlockSize = BlockSizes.B128;
            this.KeySize = KeySizes.K256;
            this.PaddingMode = PaddingModes.PKCS7;
            cbAlgorithm.SelectedIndex = 0;
            cbCipherMode.SelectedIndex = 0;
            cbKeySize.SelectedIndex = 1;
            cbVectorSize.SelectedIndex = 0;
            cbPaddingMode.SelectedIndex = 0;
            cbRounds.Enabled = false;
        }

        private void LoadSettings()
        {
            if (Properties.Settings.Default.SettingFirstRun == true)
            {
                Properties.Settings.Default.SettingFirstRun = false;
                LoadDefaults();

                return;
            }

            cbAlgorithm.SelectedIndex = Properties.Settings.Default.SettingAlgorithm;
            cbCipherMode.SelectedIndex = Properties.Settings.Default.SettingCipherMode;
            cbKeySize.SelectedIndex = Properties.Settings.Default.SettingKeySize;
            this.LastKeyPath = Properties.Settings.Default.SettingLastKeyPath;
            this.LastInputPath = Properties.Settings.Default.SettingLastInputPath;
            this.LastOutputPath = Properties.Settings.Default.SettingLastOutputPath;
            cbPaddingMode.SelectedIndex = Properties.Settings.Default.SettingPaddingMode;
            cbVectorSize.SelectedIndex = Properties.Settings.Default.SettingVectorSize;
            cbRounds.SelectedIndex = Properties.Settings.Default.SettingRounds;
            chkSign.Checked = Properties.Settings.Default.SettingSignFile;
            chkParallelize.Checked = Properties.Settings.Default.SettingParallel;
        }

        private void SaveSettings()
        {
            Properties.Settings.Default.SettingAlgorithm = cbAlgorithm.SelectedIndex;
            Properties.Settings.Default.SettingCipherMode = cbCipherMode.SelectedIndex;
            Properties.Settings.Default.SettingKeySize = cbKeySize.SelectedIndex;
            Properties.Settings.Default.SettingLastKeyPath = this.LastKeyPath;
            Properties.Settings.Default.SettingLastInputPath = this.LastInputPath;
            Properties.Settings.Default.SettingLastOutputPath = this.LastOutputPath;
            Properties.Settings.Default.SettingPaddingMode = cbPaddingMode.SelectedIndex;
            Properties.Settings.Default.SettingVectorSize = cbVectorSize.SelectedIndex;
            Properties.Settings.Default.SettingRounds = cbRounds.SelectedIndex;
            Properties.Settings.Default.SettingSignFile = chkSign.Checked;
            Properties.Settings.Default.SettingParallel = chkParallelize.Checked;

            Properties.Settings.Default.Save();
        }
        #endregion

        #region Saved
        /// <summary>
        /// Use this method to test speeds on.. anything and everything
        /// </summary>
        private string SpeedTest(Action Test, int Iterations = 1)
        {
            // output results to a label to test compiled times..
            string ft = @"m\:ss\.ff";
            System.Diagnostics.Stopwatch runTimer = new System.Diagnostics.Stopwatch();

            runTimer.Start();

            for (int i = 0; i < Iterations; i++)
                Test();

            runTimer.Stop();

            return TimeSpan.FromMilliseconds(runTimer.Elapsed.TotalMilliseconds).ToString(ft);
        }

        private void FormatAVSFile(string InputPath, string OutputPath)
        {
            using (FileStream reader = new FileStream(InputPath, FileMode.Open, FileAccess.Read, FileShare.None))
            {
                int blockSize = (int)reader.Length;
                byte[] inputBuffer = new byte[blockSize];
                reader.Read(inputBuffer, 0, blockSize);
                var str = System.Text.Encoding.Default.GetString(inputBuffer);
                str = str.Replace(" ", "");
                str = str.Replace(Environment.NewLine, "");

                using (FileStream writer = new FileStream(OutputPath, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    byte[] buffer = System.Text.Encoding.ASCII.GetBytes(str);
                    writer.Write(buffer, 0, buffer.Length);
                }
            }
        }

        private void FormatCounterpane(string InputPath, string OutputPath, int KeyLength, string Term, string Start, string Finish)
        {
            //ex. FormatCounterpane(@"C:\Tests\Saved\twofishkeymaster.txt", @"C:\Tests\twofishkey-192.txt", 48, "KEY=", "KEYSIZE=192", "KEYSIZE=256");
            string line = "";
            bool started = false;

            using (StreamReader reader = new StreamReader(InputPath))
            {
                using (StreamWriter writer = new StreamWriter(OutputPath))
                {
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (!started && line.Contains(Start))
                            started = true;
                        if (started && line.Contains(Finish)) 
                            break;
                        if (line.Contains(Term) && started)
                        {
                            line = line.Substring(line.IndexOf('=', 0) + 1, KeyLength);
                            writer.Write(line);
                        }
                    }
                }
            }
        }

        private void FormatNessieFile(string InputPath, string OutputPath, int KeyLength, string Term)
        {
            //ex. FormatCounterpane(@"C:\Tests\Saved\twofishkeymaster.txt", @"C:\Tests\twofishkey-128.txt", 32, "KEY=", "KEY=192");
            string line = "";

            using (StreamReader reader = new StreamReader(InputPath))
            {
                using (StreamWriter writer = new StreamWriter(OutputPath))
                {
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line.Contains(Term))
                        {
                            if (KeyLength == 64)
                            {
                                line = line.Substring(line.IndexOf('=', 0) + 1, KeyLength / 2);
                                string nline = reader.ReadLine();
                                nline = nline.Replace(" ", "");
                                nline = nline.Replace(Environment.NewLine, "");
                                line += nline;
                            }
                            else
                            {
                                line = line.Substring(line.IndexOf('=', 0) + 1, KeyLength);

                            }
                            writer.Write(line);
                        }
                    }
                }
            }
        }

        private void GetQueueTime()
        {
            byte[] input = new byte[16];
            byte[] output = new byte[16];
            KeyParams keyParam = new KeyParams(KeyGenerator.Generate(32), KeyGenerator.Generate(16));

            // get a time sample; queue size, constant time (not used)
            WaitQueue.SampleQueue squeue = new WaitQueue.SampleQueue(14400, 4);
            squeue.Init();

            using (CTR enc = new CTR(new RDX()))
            {
                enc.Init(true, keyParam);

                // sample 10 packets
                for (int i = 0; i < 900; i++)
                {
                    enc.Transform(input, output);
                    squeue.SQueue(output);
                }

                // example of a constant time value
                double ctime = Math.Ceiling(squeue.Samples.High * 2);
            }
        }

        private static bool IsEqual(byte[] a, byte[] b)
        {
            int i = a.Length;

            if (i != b.Length)
                return false;

            while (i != 0)
            {
                --i;
                if (a[i] != b[i])
                    return false;
            }

            return true;
        }

        private void ParallelCBCTest()
        {
            byte[] input = new byte[1024];
            byte[] cipher = new byte[1024];
            byte[] output = new byte[1024];
            KeyParams key = new KeyParams(KeyGenerator.Generate(32), KeyGenerator.Generate(16));

            using (CBC mode = new CBC(new RDX()))
            {
                mode.Init(true, key);

                for (int i = 0; i < 1024; i += 16)
                    mode.EncryptBlock(input, i, cipher, i);
            }

            using (CBC mode = new CBC(new RDX()))
            {
                mode.Init(false, key);
                mode.DecryptBlock(cipher, output);
            }

            if (Compare.AreEqual(input, output) == false)
                throw new Exception("ModeVectors: CBC encrypted arrays are not equal!");
        }

        private void QueueTest()
        {
            // constant time example using a waitqueue
            // 1 rdx block
            byte[] input = new byte[16];
            byte[] output = new byte[16];
            byte[] buffer;
            KeyParams keyParam = new KeyParams(KeyGenerator.Generate(32), KeyGenerator.Generate(16));

            for (int i = 0; i < 16; i++)
                input[i] = (byte)i;

            // 10 packet queue (1440 * 10 bytes), 4 millisecond constant time
            WaitQueue packetQueue = new WaitQueue(14400, 4);
            // initialize queue
            packetQueue.Init();

            using (CTR enc = new CTR(new RDX()))
            {
                enc.Init(true, keyParam);

                // process 1 packet
                for (int i = 0; i < 90; i++)
                {
                    enc.Transform(input, output);
                    if (packetQueue.Queue(output))
                    {
                        buffer = packetQueue.DeQueue();
                        // create packet and transmit //
                    }
                }
            }
        }

        private void TestCipher()
        {
            KeyParams keyParam = new KeyParams(KeyGenerator.GenerateKey(320), KeyGenerator.GenerateKey(16));
            int sz = 64;
            byte[] inData = new byte[sz];
            byte[] outData = new byte[sz];
            byte[] retData = new byte[sz];

            using (Fusion cipher = new Fusion())
            {
                cipher.Init(keyParam);
                cipher.Transform(inData, outData);
            }

            using (Fusion cipher = new Fusion())
            {
                cipher.Init(keyParam);
                cipher.Transform(outData, retData);
            }
        }

        private void TestRandom()
        {
            byte[] retData = new byte[1025];

            using (CTRDRBG rand = new CTRDRBG(new RHX()))
            {
                int kSz = rand.KeySize;
                byte[] key = KeyGenerator.GenerateKey(kSz);
                rand.Init(key);
                rand.Generate(2048, retData);
            }
        }
        #endregion
    }
}
