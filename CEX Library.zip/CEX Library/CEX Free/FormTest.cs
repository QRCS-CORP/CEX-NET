﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Windows.Forms;
using VTDev.Projects.CEX.Helpers;
using VTDev.Projects.CEX.Tests;

#region Speed Benchmarks
/// Speed tests on an AMD ASD-3600 Quad-Core, 4GB RAM, compiled Release/Any CPU.
/// Test is a transform of a byte array in a Monte Carlo method.
/// Sizes are in MBs (1000000 bytes). Time format sec.ms, key sizes in bits. Rate is MB per minute.
/// HX series will have similar times, as they use the same diffusion engines.
/// CTR mode and CBC decrypt are run in parallel mode. CBC encrypt is in linear (single processor) mode.
/// Highest rate was RDX with a 128 bit key: 6.052 GB per minute!
/// 
/// **Block Ciphers**
/// 
/// RDX (Rijndael): 256 Key, 14 Rounds
/// Mode    State   Size    Time    Rate
/// ----    -----   ----    ----    ----
/// CTR     ENC     100     1.18    5084
/// CTR     DEC     100     1.18    5043
/// CBC     ENC     100     3.03    1980
/// CBC     DEC     100     1.59    3773 
/// 
/// RSM (Rijndael/Serpent Merged): 1536 Key, 18 Rounds
/// Mode    State   Size    Time    Rate
/// ----    -----   ----    ----    ----
/// CTR     ENC     100     2.69    2230  
/// CTR     DEC     100     2.68    2238
/// CBC     ENC     100     8.15    736
/// CBC     DEC     100     3.17    1892
/// 
/// SPX (Serpent): 256 Key, 32 Rounds
/// Mode    State   Size    Time    Rate
/// ----    -----   ----    ----    ----
/// CTR     ENC     100     2.22    2702
/// CTR     DEC     100     2.21    2714
/// CBC     ENC     100     6.45    930
/// CBC     DEC     100     2.39    2510
/// 
/// TFX (Twofish): 256 Key, 16 Rounds
/// Mode    State   Size    Time    Rate
/// ----    -----   ----    ----    ----
/// CTR     ENC     100     1.33    4511
/// CTR     DEC     100     1.35    4444
/// CBC     ENC     100     3.55    1690
/// CBC     DEC     100     1.74    3448
/// 
/// 
/// **Stream Ciphers**
/// 
/// ChaCha: 256 Key, 20 Rounds
/// Size    Time    Rate
/// ----    ----    ----
/// 100     2.26    2027
/// 
/// DCS: 768 Key
/// Size    Time    Rate
/// ----    ----    ----
/// 100     2.12    2830
/// 
/// Fusion: 2560 Key
/// Size    Time    Rate
/// ----    ----    ----
/// 100     2.16    2777   
/// 
/// Salsa20: 256 Key, 20 Rounds
/// Size    Time    Rate
/// ----    ----    ----
/// 100     2.68    2238

#endregion

namespace VTDev.Projects.CEX
{
    public partial class FormTest : Form
    {
        #region Constants
        private const string LOG_DEF = "[Select an Output Folder]";
        private const string LOG_DES = "Select an Output Folder";
        private const int MB1 = 1000000;
        #endregion

        #region Properties
        private Engines Engine { get; set; }
        private bool IsEncryption { get; set; }
        public bool IsParallel { get; set; }
        private CipherModes Mode { get; set; }
        private string OutputDirectory { get; set; }
        private int TestCount { get; set; }
        private Tests.EngineSpeed.TestTypes IOTestType { get; set; }
        #endregion

        #region Fields
        private BackgroundWorker _analysisWorker = new BackgroundWorker();
        private BackgroundWorker _speedWorker = new BackgroundWorker();
        private Dictionary<string, string> _testResults = new Dictionary<string, string>();
        private static string _engTime = "";
        private static int _sizeMB = 1;
        private static int _roundsCount = 0;
        private static int _keySize = 0;
        #endregion

        #region Constructor
        public FormTest()
        {
            InitializeComponent();
        }
        #endregion

        #region Helpers
        private void AnalysisToLog()
        {
            if (_testResults.Count > 0)
                Logger.LogSession();

            // put the values to list
            foreach (var val in _testResults)
            {
                string[] sub = val.Value.Split(',');

                if (sub.Length > 1)
                    Logger.LogResult(val.Key, sub[0], sub[1]);
            }
        }

        private void EnabledState(bool State)
        {
            grpTests.Enabled = State;
            grpSpeed.Enabled = State;
        }

        private string GetFolderPath(string Description)
        {
            using (FolderBrowserDialog folderDialog = new FolderBrowserDialog())
            {
                folderDialog.Description = Description;
                folderDialog.ShowNewFolderButton = true;
                folderDialog.SelectedPath = this.OutputDirectory;

                if (folderDialog.ShowDialog() == DialogResult.OK)
                {
                    string path = folderDialog.SelectedPath;

                    if (Utilities.DirectoryHasPermission(path, System.Security.AccessControl.FileSystemRights.CreateFiles))
                        return path;
                }
            }

            return string.Empty;
        }

        private int GetTestCount()
        {
            int count = 0;

            foreach (object obj in ((Control)grpTests).Controls)
            {
                if (obj.GetType().Equals(typeof(CheckBox)))
                {
                    CheckBox chk = obj as CheckBox;

                    if (chk.Checked && chk.Enabled)
                        count++;
                }
            }

            return count;
        }

        private void SetTestParams()
        {
            this.TestCount = 0;

            foreach (object obj in ((Control)grpTests).Controls)
            {
                if (obj.GetType().Equals(typeof(CheckBox)))
                {
                    CheckBox chk = obj as CheckBox;

                    if (chk.Checked && chk.Enabled)
                        this.TestCount++;

                    // checkbox name is a member name
                    Test.Tests test = (Test.Tests)Enum.Parse(typeof(Test.Tests), chk.Name);
                    Test.ParametersKey[test] = chk.Checked && chk.Enabled;
                }
            }
        }
        #endregion

        #region Event Handlers
        private void OnAlgoTestClick(object sender, EventArgs e)
        {
            RunSpecTests();
        }

        private void OnEncryptChanged(object sender, EventArgs e)
        {
            RadioButton rd = sender as RadioButton;

            if (rd.Checked == false) return;
            this.IsEncryption = (rd.Name == "rdEncrypt");
        }

        private void OnEngineChanged(object sender, EventArgs e)
        {
            RadioButton rd = sender as RadioButton;

            if (rd.Checked == false) return;
            cbKeySize.Items.Clear();
            cbRounds.Items.Clear();
            cbKeySize.Enabled = true;
            cbRounds.Enabled = true;

            if (rd.Name == "ChaCha20")
            {
                this.Engine = Engines.ChaCha;
                cbKeySize.Items.Add("128");
                cbKeySize.Items.Add("256");
                cbKeySize.Items.Add("384");
                cbKeySize.Items.Add("448");
                cbKeySize.SelectedIndex = 1;
                cbRounds.Items.Add("8");
                cbRounds.Items.Add("10");
                cbRounds.Items.Add("12");
                cbRounds.Items.Add("14");
                cbRounds.Items.Add("16");
                cbRounds.Items.Add("18");
                cbRounds.Items.Add("20");
                cbRounds.Items.Add("22");
                cbRounds.Items.Add("24");
                cbRounds.Items.Add("26");
                cbRounds.Items.Add("28");
                cbRounds.Items.Add("30");
                cbRounds.SelectedIndex = 6;
            }
            else if (rd.Name == "DCS")
            {
                this.Engine = Engines.DCS;
                cbKeySize.Enabled = false;
                cbRounds.Enabled = false;
            }
            else if (rd.Name == "RDX" || rd.Name == "RSX")
            {
                this.Engine = Engines.RDX;
                cbKeySize.Items.Add("128");
                cbKeySize.Items.Add("256");
                cbKeySize.Items.Add("512");
                cbKeySize.SelectedIndex = 1;
                cbRounds.Enabled = false;
            }
            else if (rd.Name == "RHX")
            {
                this.Engine = Engines.RHX;
                cbKeySize.Items.Add("1536");
                cbKeySize.Items.Add("2560");
                cbKeySize.Items.Add("3584");
                cbKeySize.Items.Add("4608");
                cbKeySize.SelectedIndex = 0;
                cbRounds.Items.Clear();
                cbRounds.Items.Add("10");
                cbRounds.Items.Add("14");
                cbRounds.Items.Add("22");
                cbRounds.Items.Add("38");
                cbRounds.SelectedIndex = 2;
            }
            else if (rd.Name == "RSM")
            {
                this.Engine = Engines.RSM;
                cbKeySize.Items.Add("1536");
                cbKeySize.Items.Add("2560");
                cbKeySize.Items.Add("3584");
                cbKeySize.Items.Add("4608");
                cbKeySize.SelectedIndex = 0;
                cbRounds.Items.Clear();
                cbRounds.Items.Add("10");
                cbRounds.Items.Add("18");
                cbRounds.Items.Add("26");
                cbRounds.Items.Add("34");
                cbRounds.Items.Add("42");
                cbRounds.SelectedIndex = 1;
            }
            else if (rd.Name == "Salsa20")
            {
                this.Engine = Engines.Salsa;
                cbKeySize.Items.Add("128");
                cbKeySize.Items.Add("256");
                cbKeySize.Items.Add("384");
                cbKeySize.Items.Add("448");
                cbKeySize.SelectedIndex = 1;
                cbRounds.Items.Add("8");
                cbRounds.Items.Add("10");
                cbRounds.Items.Add("12");
                cbRounds.Items.Add("14");
                cbRounds.Items.Add("16");
                cbRounds.Items.Add("18");
                cbRounds.Items.Add("20");
                cbRounds.Items.Add("22");
                cbRounds.Items.Add("24");
                cbRounds.Items.Add("26");
                cbRounds.Items.Add("28");
                cbRounds.Items.Add("30");
                cbRounds.SelectedIndex = 6;
            }
            else if (rd.Name == "SHX")
            {
                this.Engine = Engines.SHX;
                cbKeySize.Items.Add("1536");
                cbKeySize.Items.Add("2560");
                cbKeySize.Items.Add("3584");
                cbKeySize.Items.Add("4608");
                cbKeySize.SelectedIndex = 0;
                cbRounds.Items.Add("32");
                cbRounds.Items.Add("40");
                cbRounds.Items.Add("48");
                cbRounds.Items.Add("56");
                cbRounds.Items.Add("64");
                cbRounds.Items.Add("80");
                cbRounds.Items.Add("96");
                cbRounds.Items.Add("128");
                cbRounds.SelectedIndex = 0;
            }
            else if (rd.Name == "SPX")
            {
                this.Engine = Engines.SPX;
                cbKeySize.Items.Add("128");
                cbKeySize.Items.Add("256");
                cbKeySize.Items.Add("512");
                cbKeySize.SelectedIndex = 1;
                cbRounds.Items.Add("32");
                cbRounds.Items.Add("40");
                cbRounds.Items.Add("48");
                cbRounds.Items.Add("56");
                cbRounds.Items.Add("64");
                cbRounds.SelectedIndex = 0;
            }
            else if (rd.Name == "THX")
            {
                this.Engine = Engines.THX;
                cbKeySize.Items.Add("1536");
                cbKeySize.Items.Add("2560");
                cbKeySize.Items.Add("3584");
                cbKeySize.Items.Add("4608");
                cbKeySize.SelectedIndex = 0;
                cbRounds.Items.Add("16");
                cbRounds.Items.Add("18");
                cbRounds.Items.Add("20");
                cbRounds.Items.Add("22");
                cbRounds.Items.Add("24");
                cbRounds.Items.Add("26");
                cbRounds.Items.Add("28");
                cbRounds.Items.Add("30");
                cbRounds.Items.Add("32");
                cbRounds.SelectedIndex = 0;
            }
            else if (rd.Name == "TFX")
            {
                this.Engine = Engines.TFX;
                cbKeySize.Items.Add("128");
                cbKeySize.Items.Add("192");
                cbKeySize.Items.Add("256");
                cbKeySize.Items.Add("512");
                cbKeySize.SelectedIndex = 1;
                cbRounds.Items.Add("16");
                cbRounds.Items.Add("18");
                cbRounds.Items.Add("20");
                cbRounds.Items.Add("22");
                cbRounds.Items.Add("24");
                cbRounds.Items.Add("26");
                cbRounds.Items.Add("28");
                cbRounds.Items.Add("30");
                cbRounds.Items.Add("32");
                cbRounds.SelectedIndex = 0;
            }
            else if (rd.Name == "TSM")
            {
                this.Engine = Engines.TSM;
                cbKeySize.Items.Add("1536");
                cbKeySize.Items.Add("2560");
                cbKeySize.Items.Add("3584");
                cbKeySize.Items.Add("4608");
                cbKeySize.SelectedIndex = 1;
                cbRounds.Items.Add("16");
                cbRounds.Items.Add("18");
                cbRounds.Items.Add("20");
                cbRounds.Items.Add("22");
                cbRounds.Items.Add("24");
                cbRounds.Items.Add("26");
                cbRounds.Items.Add("28");
                cbRounds.Items.Add("30");
                cbRounds.Items.Add("32");
                cbRounds.SelectedIndex = 0;
            }
            else if (rd.Name == "Fusion")
            {
                this.Engine = Engines.Fusion;
                cbKeySize.Items.Add("1536");
                cbKeySize.Items.Add("2560");
                cbKeySize.Items.Add("3584");
                cbKeySize.Items.Add("4608");
                cbKeySize.SelectedIndex = 1;
                cbRounds.Items.Add("16");
                cbRounds.Items.Add("18");
                cbRounds.Items.Add("20");
                cbRounds.Items.Add("22");
                cbRounds.Items.Add("24");
                cbRounds.Items.Add("26");
                cbRounds.Items.Add("28");
                cbRounds.Items.Add("30");
                cbRounds.Items.Add("32");
                cbRounds.SelectedIndex = 0;
            }
        }

        private void OnFormClose(object sender, FormClosedEventArgs e)
        {
            _analysisWorker.Dispose();
            _speedWorker.Dispose();
        }

        private void OnFormLoad(object sender, EventArgs e)
        {
            // compile it in release mode or test is pointless..
            if (System.Diagnostics.Debugger.IsAttached)
            {
               // btnSpeedTest.Enabled = false;
                lblCompileWarning.Visible = true;
                rdLogFile.Checked = true;
                rdLogConsole.Visible = true;
                rdLogFile.Visible = true;
            }

            txtLogFile.Text = Logger.LogPath;
            txtSizeMB.LostFocus += new EventHandler(OnTextBoxLostFocus);
            cbKeySize.SelectedIndex = 1; 
            cbRounds.SelectedIndex = 6;
            cbMode.SelectedIndex = 1;
            this.IsParallel = (Environment.ProcessorCount > 1);
            chkParallel.Checked = chkParallel.Enabled = this.IsParallel;
            this.IsEncryption = true;
            this.IOTestType = EngineSpeed.TestTypes.ByteIO;

            // init the background threads
            _analysisWorker.DoWork += OnAnalysisDoWork;
            _analysisWorker.RunWorkerCompleted += OnAnalysisWorkCompleted;
            _speedWorker.DoWork += OnSpeedDoWork;
            _speedWorker.RunWorkerCompleted += OnSpeedWorkCompleted;
        }

        private void OnKeySizeChanged(object sender, EventArgs e)
        {
            ComboBox cb = sender as ComboBox;

            int.TryParse(cb.Text, out _keySize);
            if (_keySize != 0)
                _keySize /= 8;
        }

        private void OnLogBrowse(object sender, EventArgs e)
        {
            string path = GetFolderPath(LOG_DES);

            if (!string.IsNullOrEmpty(path) && !path.Equals(LOG_DEF))
            {
                this.OutputDirectory = Path.Combine(path, Logger.LogName);
                Logger.LogPath = this.OutputDirectory;
                txtLogFile.Text = this.OutputDirectory;
            }
        }

        private void OnLogTypeCheck(object sender, EventArgs e)
        {
            RadioButton rd = sender as RadioButton;
            if (rd.Checked == false) return;

            if (rd.Name == "rdLogConsole")
                Logger.LogOutput = Logger.LogTypes.Console;
            else
                Logger.LogOutput = Logger.LogTypes.LogFile;
        }

        private void OnModeChanged(object sender, EventArgs e)
        {
            ComboBox cb = sender as ComboBox;

            if (cb.Text == "CTR")
                this.Mode = CipherModes.CTR;
            else
                this.Mode = CipherModes.CBC;
        }

        private void OnParallelChanged(object sender, EventArgs e)
        {
            CheckBox chk = sender as CheckBox;

            this.IsParallel = chk.Checked;
        }

        private void OnProgressChanged(int count, string message)
        {
            if (this.IsHandleCreated)
            {
                pbTestStatus.Invoke(new MethodInvoker(delegate { pbTestStatus.Value = (pbTestStatus.Value == pbTestStatus.Maximum) ? 0 : pbTestStatus.Value + 1; }));
                lblTestStatus.Invoke(new MethodInvoker(delegate { lblTestStatus.Text = message; }));
            }
        }

        private void OnRoundsCountChanged(object sender, EventArgs e)
        {
            ComboBox cb = sender as ComboBox;

            int.TryParse(cb.Text, out _roundsCount);
        }

        private void OnSpeedTestClick(object sender, EventArgs e)
        {
            // run
            RunSpeedTest();
        }

        private void OnTestTypeCheckChanged(object sender, EventArgs e)
        {
            RadioButton rd = sender as RadioButton;

            if (rd.Checked == false) return;

            if (rd.Name == "rdFileIo")
                this.IOTestType = EngineSpeed.TestTypes.FileIO;
            else
                this.IOTestType = EngineSpeed.TestTypes.ByteIO;
        }

        private void OnTextChanged(object sender, EventArgs e)
        {
            TextBox tb = sender as TextBox;
            int size = 10;
            int.TryParse(tb.Text, out size);

            if (size > 1000)
                tb.Text = "1000";
        }

        private void OnTextBoxKeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox tb = sender as TextBox;

            if (Char.IsDigit(e.KeyChar) || e.KeyChar == '\b')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void OnTextBoxLostFocus(object sender, EventArgs e)
        {
            TextBox tb = sender as TextBox;

            if (tb.Name == "txtSizeMB")
            {
                if (string.IsNullOrEmpty(tb.Text))
                {
                    tb.Text = "10";
                }
                else
                {
                    int size = 10;
                    int.TryParse(tb.Text, out size);

                    if (size == 0)
                        tb.Text = "10";
                    else if (size > 1000)
                        tb.Text = "1000";
                }
            }
        }
        #endregion

        #region Threaded Response
        private void OnAnalysisDoWork(object sender, DoWorkEventArgs e)
        {
            // run
            _testResults = Test.Run();
        }

        private void OnAnalysisWorkCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // return ui
            EnabledState(true);
            pbTestStatus.Value = pbTestStatus.Maximum;

            // whoops
            if (_testResults.Count < 1)
            {
                lblTestStatus.Text = "The test Failed!";
                return;
            }

            // put the values to list
            foreach (var val in _testResults)
            {
                ListViewItem item = new ListViewItem(val.Key);
                string[] sub = val.Value.Split(',');

                if (sub.Length > 1)
                {
                    item.SubItems.Add(sub[0]);
                    item.SubItems.Add(sub[1]);
                    lvAlgorithmTest.Items.Add(item);
                }
            }

            // yay!
            lblTestStatus.Text = "Test Complete!";

            if (chkLogResults.Checked)
                AnalysisToLog();
        }

        private void OnSpeedDoWork(object sender, DoWorkEventArgs e)
        {
            _engTime = Tests.Test.SpeedTest(this.Engine, this.Mode, _sizeMB, _keySize, _roundsCount, this.IsEncryption, this.IsParallel, this.IOTestType);
        }

        private void OnSpeedWorkCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            EnabledState(true);

            const int MIN = 60000;
            TimeSpan ts = new TimeSpan();
            TimeSpan.TryParseExact(_engTime, @"m\:ss\.ff", CultureInfo.CurrentCulture, out ts);
            double time = ts.TotalMilliseconds;

            if (time > 0)
            {
                double bytes = Convert.ToDouble(_sizeMB);
                double bpm = (bytes / time);
                double mpm = (bpm * MIN) / MB1;
                lblEngineTime.Text = _engTime + "; " + Math.Round(mpm, 3) + " MB per minute";
            }
            else
            {
                lblEngineTime.Text = _engTime;
            }
        }
        #endregion

        #region Tests
        private void RunSpecTests()
        {
            this.TestCount = GetTestCount();

            if (this.TestCount == 0)
            {
                MessageBox.Show("There are no tests selected!");
                return;
            }

            // get the tests
            SetTestParams();
            // clear old data
            _testResults.Clear();
            // clear lv
            lvAlgorithmTest.Items.Clear();
            // setup progress
            Test.ProgressChanged -= OnProgressChanged;
            Test.ProgressChanged += new Action<int, string>(OnProgressChanged);
            this.TestCount = GetTestCount();
            pbTestStatus.Maximum = this.TestCount;
            // disable ui
            EnabledState(false);
            // run
            _analysisWorker.RunWorkerAsync();
        }

        private void RunSpeedTest()
        {
            // disable ui
            EnabledState(false);

            int.TryParse(txtSizeMB.Text, out _sizeMB);
            if (_sizeMB == 0)
            {
                MessageBox.Show("Size can not be 0!");
                return;
            }
            _sizeMB = _sizeMB * MB1;

            // run
            _speedWorker.RunWorkerAsync();
        }
        #endregion
    }
}
