﻿
namespace VTDev.Projects.CEX.Tests
{
    public interface IVectorTest
    {
        /// <summary>
        /// Run the test
        /// </summary>
        /// <returns>Test result pass/fail [bool]</returns>
        bool Test();
    }
}
