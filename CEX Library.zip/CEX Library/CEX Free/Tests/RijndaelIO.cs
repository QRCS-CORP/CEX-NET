﻿using System;
using System.IO;
using System.Security.Cryptography;
using VTDev.Libraries.CEXEngine.Crypto;
using VTDev.Libraries.CEXEngine.Crypto.Ciphers;
using VTDev.Libraries.CEXEngine.Utilities;
using VTDev.Projects.CEX.Helpers;

namespace VTDev.Projects.CEX.Tests
{
    /// <summary>
    /// Tests I/O and vector values
    /// </summary>
    public class RijndaelIO : IVectorTest
    {
        internal static readonly string[] cipherTests =
		{
			"000102030405060708090a0b0c0d0e0f",
			"00112233445566778899aabbccddeeff",
			"69c4e0d86a7b0430d8cdb78070b4c55a",
			"000102030405060708090a0b0c0d0e0f1011121314151617",
			"00112233445566778899aabbccddeeff",
			"dda97ca4864cdfe06eaf70a0ec0d7191",
			"000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f",
			"00112233445566778899aabbccddeeff",
			"8ea2b7ca516745bfeafc49904b496089",
		};

        #region Properties
        internal int BlockCount { get; set; }
        #endregion

        #region Public
        /// <summary>
        /// I/O and KAT tests run through all engine accessors
        /// </summary>
        /// <returns>Success [bool]</returns>
        public bool Test()
        {
            byte[] key = new byte[32];
            byte[] iv = new byte[16];
            byte[] data = new byte[BlockCount * 16];

            try
            {
                // run the I/O test
                for (int i = 0; i != cipherTests.Length; i += 3)
                {
                    TestIO(Hex.Decode(cipherTests[i]),
                        Hex.Decode(cipherTests[i + 1]),
                        Hex.Decode(cipherTests[i + 2]));
                }

                using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider())
                {
                    data = new byte[2048];
                    rng.GetBytes(key);
                    rng.GetBytes(data);
                    TestIO2(key, data);
                }

                return true;
            }
            catch (Exception Ex)
            {
                string message = Ex.Message == null ? "" : Ex.Message;
                Logger.LogError("StandardIO", message, Ex);
                return false;
            }
        }
        #endregion

        #region Tests
        private void TestIO(byte[] Key, byte[] Input, byte[] Output)
        {
            RDX inCipher = new RDX();
            RDX outCipher = new RDX();
            byte[] outBytes = new byte[Output.Length];
            byte[] inBytes = new byte[Input.Length];

            // 1: test initialization
            try
            {
                outCipher.Init(true, new KeyParams(Key));
            }
            catch
            {
                throw new Exception("1E: Initialization Failure");
            }

            try
            {
                inCipher.Init(false, new KeyParams(Key));
            }
            catch
            {
                throw new Exception("1D: Initialization Failure");
            }

            // 2: EncryptBlock
            try
            {
                outCipher.EncryptBlock(Input, outBytes);
            }
            catch (IOException Ex)
            {
                throw new Exception("4: Processing Failure " + Ex.Message);
            }

            // not equal
            if (Compare.AreEqual(Output, outBytes) == false)
                throw new Exception("4: EncryptArray: Arrays are not equal!");

            // 3: DecryptBlock
            try
            {
                inCipher.DecryptBlock(outBytes, inBytes);
            }
            catch (Exception Ex)
            {
                throw new Exception("D5: DecryptArray Failure " + Ex.Message);
            }

            if (Compare.AreEqual(Input, inBytes) == false)
                throw new Exception("D5: Arrays are not equal!");

            // 4: EncryptBlock
            try
            {
                outCipher.EncryptBlock(Input, 0, outBytes, 0);
            }
            catch (IOException Ex)
            {
                throw new Exception("6: Processing Failure " + Ex.Message);
            }

            // not equal
            if (Compare.AreEqual(Output, outBytes) == false)
                throw new Exception("6: EncryptArray: Arrays are not equal!");

            // 5: DecryptBlock
            try
            {
                inCipher.DecryptBlock(outBytes, 0, inBytes, 0);
            }
            catch (Exception Ex)
            {
                throw new Exception("D7: DecryptArray Failure " + Ex.Message);
            }

            if (Compare.AreEqual(Input, inBytes) == false)
                throw new Exception("D7: Arrays are not equal!");

        }

        private void TestIO2(byte[] Key, byte[] Input)
        {
            byte[] outBytes = new byte[Input.Length];
            byte[] inBytes = new byte[Input.Length];
            int blocks = Input.Length / 16;

            try
            {
                using (RDX transform = new RDX())
                {
                    transform.Init(true, new KeyParams(Key));

                    for (int i = 0; i < blocks; i++)
                        transform.Transform(Input, i * 16, outBytes, i * 16);

                    transform.Init(false, new KeyParams(Key));

                    for (int i = 0; i < blocks; i++)
                        transform.Transform(outBytes, i * 16, inBytes, i * 16);

                    // equal
                    if (Compare.AreEqual(Input, inBytes) == false)
                        throw new Exception("TestIO2: Arrays are not equal!");
                }
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }
        #endregion

        #region RDX
        private byte[] DecryptRDX(byte[] Key, byte[] Data)
        {
            int blocks = Data.Length / 16;
            byte[] outputData = new byte[Data.Length];

            using (RDX transform = new RDX())
            {
                transform.Init(false, new KeyParams(Key));

                for (int i = 0; i < blocks; i++)
                    transform.Transform(Data, i * 16, outputData, i * 16);
            }

            return outputData;
        }

        private byte[] EncryptRDX(byte[] Key, byte[] Data)
        {
            int blocks = Data.Length / 16;
            byte[] outputData = new byte[Data.Length];

            using (RDX transform = new RDX())
            {
                transform.Init(true, new KeyParams(Key));

                for (int i = 0; i < blocks; i++)
                    transform.Transform(Data, i * 16, outputData, i * 16);
            }

            return outputData;
        }
        #endregion
    }
}
