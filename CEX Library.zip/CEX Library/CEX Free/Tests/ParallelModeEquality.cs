﻿using System;
using System.Security.Cryptography;
using VTDev.Libraries.CEXEngine.Crypto;
using VTDev.Libraries.CEXEngine.Crypto.Ciphers;
using VTDev.Libraries.CEXEngine.Crypto.Modes;
using VTDev.Libraries.CEXEngine.Utilities;
using VTDev.Projects.CEX.Helpers;

namespace VTDev.Projects.CEX.Tests
{
    /// <remarks>
    /// Compares the output of SIC mode with parallel output from PSC
    /// </remarks>
    public class ParallelModeEquality : IVectorTest
    {
        #region Properties
        private bool IsParallel { get; set; }
        #endregion

        #region Public
        /// <summary>
        /// Compares CTR linear with parallel output for equivalence
        /// </summary>
        /// <returns>Success [bool]</returns>
        public bool Test()
        {
            try
            {
                using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider())
                {
                    byte[] key = new byte[32];
                    byte[] iv = new byte[16];
                    // 2 psc blocks
                    byte[] data = new byte[2048];
                    rng.GetBytes(key);
                    rng.GetBytes(iv);
                    rng.GetBytes(data);

                    CompareBlocks(key, iv, data);

                    // 1 + partial
                    data = new byte[1025];
                    rng.GetBytes(data);
                    CompareBlocks(key, iv, data);

                    // 2 + partial
                    data = new byte[2056];
                    rng.GetBytes(data);
                    CompareBlocks(key, iv, data);
                }
                return true;
            }
            catch (Exception Ex)
            {
                string message = Ex.Message == null ? "" : Ex.Message;
                Logger.LogError("PSCEquality", message, Ex);
                return false;
            }
        }
        #endregion

        #region Helpers
        private void CompareBlocks(byte[] Key, byte[] Vector, byte[] Data)
        {
            this.IsParallel = true;
            byte[] enc1 = EncryptRDX(Key, Vector, Data);
            byte[] dec1 = DecryptRDX(Key, Vector, enc1);

            // compare to SIC mode output
            this.IsParallel = false;
            byte[] enc2 = EncryptRDX(Key, Vector, Data);
            byte[] dec2 = DecryptRDX(Key, Vector, enc2);

            if (Compare.AreEqual(enc1, enc2) == false)
                throw new Exception("PSCEquality: Encrypted output is not equal!");
            if (Compare.AreEqual(dec1, dec2) == false)
                throw new Exception("PSCEquality: Decrypted output is not equal to input data!");
        }
        #endregion

        #region RDX
        private byte[] DecryptRDX(byte[] Key, byte[] Vector, byte[] Data)
        {
            int blocks = Data.Length / 1024;
            byte[] outputData = new byte[Data.Length];

            if (this.IsParallel)
            {
                using (ICipherMode mode = new CTR(new RDX()))
                {
                    mode.Init(true, new KeyParams(Key, Vector));
                    mode.IsParallel = true;
                    for (int i = 0; i < blocks; i++)
                        mode.Transform(Data, i * 1024, outputData, i * 1024);
                }
            }
            else
            {
                using (ICipherMode mode = new CTR(new RDX()))
                {
                    blocks = Data.Length / 16;
                    mode.Init(true, new KeyParams(Key, Vector));
                    mode.IsParallel = false;
                    for (int i = 0; i < blocks; i++)
                        mode.Transform(Data, i * 16, outputData, i * 16);
                }
            }

            return outputData;
        }

        private byte[] EncryptRDX(byte[] Key, byte[] Vector, byte[] Data)
        {
            int blocks = Data.Length / 1024;
            byte[] outputData = new byte[Data.Length];

            if (this.IsParallel)
            {
                using (ICipherMode mode = new CTR(new RDX()))
                {
                    mode.Init(true, new KeyParams(Key, Vector));
                    mode.IsParallel = true;

                    for (int i = 0; i < blocks; i++)
                        mode.Transform(Data, i * 1024, outputData, i * 1024);
                }
            }
            else
            {
                using (ICipherMode mode = new CTR(new RDX()))
                {
                    blocks = Data.Length / 16;
                    mode.Init(true, new KeyParams(Key, Vector));
                    mode.IsParallel = false;

                    for (int i = 0; i < blocks; i++)
                        mode.Transform(Data, i * 16, outputData, i * 16);
                }
            }

            return outputData;
        }
        #endregion
    }
}
