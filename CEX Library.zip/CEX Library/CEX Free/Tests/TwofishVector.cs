﻿using System;
using VTDev.Libraries.CEXEngine.Crypto;
using VTDev.Libraries.CEXEngine.Crypto.Ciphers;
using VTDev.Libraries.CEXEngine.Utilities;
using VTDev.Projects.CEX.Helpers;

namespace VTDev.Projects.CEX.Tests
{
    public class TwofishVector : IVectorTest
    {
        /// <summary>
        /// Official TwoFish key vectors
        /// https://www.schneier.com/twofish.html
        /// </summary>
        #region Vectors
        private static byte[] _plainText = Hex.Decode("00000000000000000000000000000000");
        #endregion

        #region Public
        /// <summary>
        /// Run the test
        /// </summary>
        /// <returns>Success [bool]</returns>
        public bool Test()
        {
            try
            {
                byte[] cip = new byte[16];
                byte[] key = new byte[16];

                // vector tests //
                // 128 bit keys
                string cipStr = VTDev.Projects.CEX.Properties.Resources.twofishcipher_128;
                string keyStr = VTDev.Projects.CEX.Properties.Resources.twofishkey_128;

                for (int i = 0; i < keyStr.Length; i += 32)
                {
                    cip = Hex.Decode(cipStr.Substring(i, 32));
                    key = Hex.Decode(keyStr.Substring(i, 32));

                    // vector comparison
                    VectorTest(key, _plainText, cip);
                }

                // 192 bit keys
                cipStr = VTDev.Projects.CEX.Properties.Resources.twofishcipher_192;
                keyStr = VTDev.Projects.CEX.Properties.Resources.twofishkey_192;

                for (int i = 0, j = 0; j < keyStr.Length; i += 32, j += 48)
                {
                    cip = Hex.Decode(cipStr.Substring(i, 32));
                    key = Hex.Decode(keyStr.Substring(j, 48));

                    // vector comparison
                    VectorTest(key, _plainText, cip);
                }

                // 256 bit keys
                cipStr = VTDev.Projects.CEX.Properties.Resources.twofishcipher_256;
                keyStr = VTDev.Projects.CEX.Properties.Resources.twofishkey_256;

                for (int i = 0, j = 0; j < keyStr.Length; i += 32, j += 64)
                {
                    cip = Hex.Decode(cipStr.Substring(i, 32));
                    key = Hex.Decode(keyStr.Substring(j, 64));

                    // vector comparison
                    VectorTest(key, _plainText, cip);
                }

                // monte carlo tests: //
                // encrypt 10,000 rounds each
                key = new byte[16];
                byte[] output = Hex.Decode("282BE7E4FA1FBDC29661286F1F310B7E");
                // 128 key
                MonteCarloTest(key, _plainText, output);
                // 192 key
                key = new byte[24];
                output = Hex.Decode("9AB71D7F280FF79F0D135BBD5FAB7E37");
                MonteCarloTest(key, _plainText, output);
                // 256 key
                key = new byte[32];
                output = Hex.Decode("04F2F36CA927AE506931DE8F78B2513C");
                MonteCarloTest(key, _plainText, output);

                // decrypt 10,000 rounds
                key = new byte[16];
                output = Hex.Decode("21D3F7F6724513946B72CFAE47DA2EED");
                // 128 key
                MonteCarloTest(key, _plainText, output, false);
                // 192 key
                key = new byte[24];
                output = Hex.Decode("B4582FA55072FCFEF538F39072F234A9");
                MonteCarloTest(key, _plainText, output, false);
                // 256 key
                key = new byte[32];
                output = Hex.Decode("BC7D078C4872063869DEAB891FB42761");
                MonteCarloTest(key, _plainText, output, false);

                return true;
            }
            catch (Exception Ex)
            {
                string message = Ex.Message == null ? "" : Ex.Message;
                Logger.LogError("TwofishVector", message, Ex);
                return false;
            }
        }
        #endregion

        #region Private
        private void MonteCarloTest(byte[] Key, byte[] Input, byte[] Output, bool Encrypt = true, int Count = 10000)
        {
            byte[] outBytes = new byte[Input.Length];
            Array.Copy(Input, 0, outBytes, 0, outBytes.Length);

            using (TFX engine = new TFX())
            {
                engine.Init(Encrypt, new KeyParams(Key));

                for (int i = 0; i < Count; i++)
                    engine.Transform(outBytes, outBytes);
            }

            if (Compare.AreEqual(outBytes, Output) == false)
                throw new Exception("Twofish MonteCarlo: Arrays are not equal!");
        }

        private void VectorTest(byte[] Key, byte[] Input, byte[] Output)
        {
            byte[] outBytes = new byte[Input.Length];

            using (TFX tfx = new TFX())
            {
                tfx.Init(true, new KeyParams(Key));
                tfx.EncryptBlock(Input, outBytes);
            }

            if (Compare.AreEqual(outBytes, Output) == false)
                throw new Exception("Twofish Vector: Encrypted arrays are not equal!");

            using (TFX tfx = new TFX())
            {
                tfx.Init(false, new KeyParams(Key));
                tfx.Transform(Output, outBytes);
            }

            if (Compare.AreEqual(outBytes, Input) == false)
                throw new Exception("Twofish Vector: Decrypted arrays are not equal!");
        }
        #endregion
    }
}
