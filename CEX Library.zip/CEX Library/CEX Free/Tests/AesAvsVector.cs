﻿using System;
using VTDev.Libraries.CEXEngine.Crypto;
using VTDev.Libraries.CEXEngine.Crypto.Ciphers;
using VTDev.Libraries.CEXEngine.Utilities;
using VTDev.Projects.CEX.Helpers;

namespace VTDev.Projects.CEX.Tests
{
    /// <summary>
    /// NIST Advanced Encryption Standard Algorithm Validation Suite (AESAVS)
    /// AESAVS certification vectors: http://csrc.nist.gov/groups/STM/cavp/documents/aes/AESAVS.pdf
    /// </summary>
    public class AesAvsVector : IVectorTest
    {
        #region Public
        /// <summary>
        /// The full range of ascending Key and Plaintext Vector KATs, 960 tests total.
        /// Throws on all failures.
        /// </summary>
        /// <returns>Success [bool]</returns>
        public bool Test()
        {
            byte[] plainText = Hex.Decode("00000000000000000000000000000000");
            byte[] key;
            byte[] cipherText;

            try
            {

                string data = VTDev.Projects.CEX.Properties.Resources.keyvect128;
                        
                for (int i = 0, j = 32; i < data.Length; i += 64, j += 64)
                {
                    key = Hex.Decode(data.Substring(i, 32));
                    cipherText = Hex.Decode(data.Substring(j, 32));

                    VectorTest(key, plainText, cipherText);
                }

                data = VTDev.Projects.CEX.Properties.Resources.keyvect192;

                for (int i = 0, j = 48; i < data.Length; i += 80, j += 80)
                {
                    key = Hex.Decode(data.Substring(i, 48));
                    cipherText = Hex.Decode(data.Substring(j, 32));

                    VectorTest(key, plainText, cipherText);
                }

                data = VTDev.Projects.CEX.Properties.Resources.keyvect256;

                for (int i = 0, j = 64; i < data.Length; i += 96, j += 96)
                {
                    key = Hex.Decode(data.Substring(i, 64));
                    cipherText = Hex.Decode(data.Substring(j, 32));

                    VectorTest(key, plainText, cipherText);
                }

                key = Hex.Decode("00000000000000000000000000000000");
                data = VTDev.Projects.CEX.Properties.Resources.plainvect128;

                for (int i = 0, j = 32; i < data.Length; i += 64, j += 64)
                {
                    plainText = Hex.Decode(data.Substring(i, 32));
                    cipherText = Hex.Decode(data.Substring(j, 32));

                    VectorTest(key, plainText, cipherText);
                }

                key = Hex.Decode("000000000000000000000000000000000000000000000000");
                data = VTDev.Projects.CEX.Properties.Resources.plainvect192;

                for (int i = 0, j = 32; i < data.Length; i += 64, j += 64)
                {
                    plainText = Hex.Decode(data.Substring(i, 32));
                    cipherText = Hex.Decode(data.Substring(j, 32));

                    VectorTest(key, plainText, cipherText);
                }

                key = Hex.Decode("0000000000000000000000000000000000000000000000000000000000000000");
                data = VTDev.Projects.CEX.Properties.Resources.plainvect256;

                for (int i = 0, j = 32; i < data.Length; i += 64, j += 64)
                {
                    plainText = Hex.Decode(data.Substring(i, 32));
                    cipherText = Hex.Decode(data.Substring(j, 32));

                    VectorTest(key, plainText, cipherText);
                }

                return true;
            }
            catch (Exception Ex)
            {
                string message = Ex.Message == null ? "" : Ex.Message;
                Logger.LogError("AvsKey", message, Ex);
                return false;
            }
        }
        #endregion

        #region Helpers
        private void VectorTest(byte[] Key, byte[] Input, byte[] Output)
        {
            using (RDX engine = new RDX())
            {
                byte[] outBytes = new byte[Input.Length];
                engine.Init(true, new KeyParams(Key));
                engine.Transform(Input, outBytes);

                if (Compare.AreEqual(outBytes, Output) == false)
                    throw new Exception("AVSVector: Encrypted arrays are not equal!");
            }
        }
        #endregion
    }
}
