﻿using System;
using System.Diagnostics;
using System.IO;
using VTDev.Libraries.CEXEngine.Crypto;
using VTDev.Libraries.CEXEngine.Crypto.Ciphers;
using VTDev.Libraries.CEXEngine.Crypto.Helpers;
using VTDev.Libraries.CEXEngine.Crypto.Modes;

namespace VTDev.Projects.CEX.Tests
{
    public class EngineSpeed : ISpeedTest
    {
        #region Constants
        private const int MB1 = 1000000;
        private const int MB10 = 10000000;
        #endregion

        #region Enums
        public enum TestTypes : int
        {
            FileIO,
            ByteIO
        }
        #endregion

        #region Properties
        private int DataSize { get; set; }
        private bool Encryption { get; set; }
        private Engines Engine { get; set; }
        private bool IsParallel { get; set; }
        private int KeySize { get; set; }
        private KeyParams KeyParam { get; set; }
        private CipherModes Mode { get; set; }
        private int Rounds { get; set; }
        private TestTypes TestType { get; set; }
        #endregion

        #region Constructor
        public EngineSpeed(Engines Engine, CipherModes Mode, int DataSize, int KeySize, int Rounds, bool Encryption, bool Parallel, TestTypes TestType = TestTypes.FileIO)
        {
            this.DataSize = DataSize;
            this.Encryption = Encryption;
            this.Engine = Engine;
            this.IsParallel = Parallel;
            this.KeySize = KeySize;
            this.Mode = Mode;
            this.Rounds = Rounds;
            this.TestType = TestType;
            this.KeyParam = GetKeyParams();
        }
        #endregion

        #region Public
        /// <summary>
        /// Get time elapsed to encrypt a file
        /// </summary>
        /// <returns>Elapsed milliseconds [string]</returns>
        public string Test()
        {
            string ft = @"m\:ss\.ff";
            Stopwatch runTimer = new Stopwatch();
            KeyParams keyParam = GetKeyParams();

            if (this.TestType == TestTypes.FileIO)
            {
                string inputPath = FileGetTemp();
                string outputPath = FileGetTemp();

                CreateFile(inputPath);

                if (!File.Exists(inputPath))
                    return "File could not be created!";

                runTimer.Start();

                FileIOTest(inputPath, outputPath);

                runTimer.Stop();

                DestroyFile(inputPath);
                DestroyFile(outputPath);
            }
            else
            {
                runTimer.Start();

                ByteEncryptIOTest();

                runTimer.Stop();
            }

            TimeSpan t1 = TimeSpan.FromMilliseconds(runTimer.Elapsed.TotalMilliseconds);

            return t1.ToString(ft);
        }
        #endregion

        #region Tests
        private void BlockCipherArrayTest()
        {
            using (ICipherMode cipher = GetCipher())
            {
                int block = cipher.BlockSize;
                if (this.IsParallel && cipher.Name == "CTR" || this.IsParallel && this.Encryption == false && cipher.Name == "CBC")
                    block = MB1;
                byte[] data = new byte[block];
                int cnt = this.DataSize / block;

                cipher.Init(this.Encryption, this.KeyParam);

                for (int i = 0; i < cnt; i++)
                    cipher.Transform(data, data);
            }
        }

        private void BlockCipherFileTest(string InputPath, string OutputPath)
        {
            using (BinaryReader inputReader = new BinaryReader(new FileStream(InputPath, FileMode.Open, FileAccess.Read, FileShare.None)))
            {
                long bytesRead = 0;

                using (BinaryWriter outputWriter = new BinaryWriter(new FileStream(OutputPath, FileMode.Create, FileAccess.Write, FileShare.None)))
                {
                    using (ICipherMode cipher = GetCipher())
                    {
                        int block = cipher.BlockSize;
                        if (this.IsParallel && cipher.Name == "CTR" || this.IsParallel && this.Encryption == false && cipher.Name == "CBC")
                            block = MB1;
                        byte[] inputBuffer = new byte[block];
                        byte[] outputBuffer = new byte[block];

                        cipher.Init(this.Encryption, this.KeyParam);

                        while ((bytesRead = inputReader.Read(inputBuffer, 0, block)) > 0)
                        {
                            cipher.Transform(inputBuffer, outputBuffer);
                            outputWriter.Write(outputBuffer);
                        }
                    }
                }
            }
        }

        private void ByteEncryptIOTest()
        {
            if (this.Engine == Engines.ChaCha)
                StreamCipherArrayTest(new ChaCha());
            else if (this.Engine == Engines.Salsa)
                StreamCipherArrayTest(new Salsa20());
            else if (this.Engine == Engines.DCS)
                DCSArrayTest();
            else if (this.Engine == Engines.Fusion)
                FusionArrayTest();
            else
                BlockCipherArrayTest();
        }

        private void DCSArrayTest()
        {
            byte[] data = new byte[102400];
            int cnt = this.DataSize / 102400;

            using (DCS enc = new DCS())
            {
                enc.Init(this.KeyParam);

                for (int i = 0; i < cnt; i++)
                    enc.Transform(data, data);
            }
        }

        private void DCSFileTest(string InputPath, string OutputPath)
        {
            using (BinaryReader inputReader = new BinaryReader(new FileStream(InputPath, FileMode.Open, FileAccess.Read, FileShare.None)))
            {
                byte[] inputBuffer = new byte[MB1];
                byte[] outputBuffer = new byte[MB1];
                long bytesRead = 0;

                using (BinaryWriter outputWriter = new BinaryWriter(new FileStream(OutputPath, FileMode.Create, FileAccess.Write, FileShare.None)))
                {
                    using (DCS enc = new DCS())
                    {
                        enc.Init(this.KeyParam);

                        while ((bytesRead = inputReader.Read(inputBuffer, 0, MB1)) > 0)
                        {
                            enc.Transform(inputBuffer, outputBuffer);
                            outputWriter.Write(outputBuffer);
                        }
                    }
                }
            }
        }

        private void FusionArrayTest()
        {
            byte[] data = new byte[102400];
            int cnt = this.DataSize / 102400;

            using (Fusion enc = new Fusion())
            {
                enc.Init(this.KeyParam);

                for (int i = 0; i < cnt; i++)
                    enc.Transform(data, data);
            }
        }

        private void FusionFileTest(string InputPath, string OutputPath)
        {
            using (BinaryReader inputReader = new BinaryReader(new FileStream(InputPath, FileMode.Open, FileAccess.Read, FileShare.None)))
            {
                byte[] inputBuffer = new byte[MB1];
                byte[] outputBuffer = new byte[MB1];
                long bytesRead = 0;

                using (BinaryWriter outputWriter = new BinaryWriter(new FileStream(OutputPath, FileMode.Create, FileAccess.Write, FileShare.None)))
                {
                    using (Fusion enc = new Fusion())
                    {
                        enc.Init(this.KeyParam);

                        while ((bytesRead = inputReader.Read(inputBuffer, 0, MB1)) > 0)
                        {
                            enc.Transform(inputBuffer, outputBuffer);
                            outputWriter.Write(outputBuffer);
                        }
                    }
                }
            }
        }

        private void FileIOTest(string InputPath, string OututPath)
        {
            if (this.Engine == Engines.ChaCha)
                StreamCipherFileTest(new ChaCha(), InputPath, OututPath);
            else if (this.Engine == Engines.Salsa)
                StreamCipherFileTest(new Salsa20(), InputPath, OututPath);
            else if (this.Engine == Engines.DCS)
                DCSFileTest(InputPath, OututPath);
            else if (this.Engine == Engines.Fusion)
                FusionFileTest(InputPath, OututPath);
            else
                BlockCipherFileTest(InputPath, OututPath);
        }

        private void StreamCipherArrayTest(IStreamCipher Cipher)
        {
            byte[] data = new byte[64];
            int cnt = this.DataSize / 64;

            Cipher.Init(this.KeyParam);

            for (int i = 0; i < cnt; i++)
                Cipher.Transform(data, data);
        }

        private void StreamCipherFileTest(IStreamCipher Cipher, string InputPath, string OutputPath)
        {
            using (BinaryReader inputReader = new BinaryReader(new FileStream(InputPath, FileMode.Open, FileAccess.Read, FileShare.None)))
            {
                byte[] inputBuffer = new byte[64];
                byte[] outputBuffer = new byte[64];
                long bytesRead = 0;

                using (BinaryWriter outputWriter = new BinaryWriter(new FileStream(OutputPath, FileMode.Create, FileAccess.Write, FileShare.None)))
                {
                    Cipher.Init(this.KeyParam);

                    while ((bytesRead = inputReader.Read(inputBuffer, 0, 64)) > 0)
                    {
                        Cipher.Transform(inputBuffer, outputBuffer);
                        outputWriter.Write(outputBuffer);
                    }
                }
            }
        }

        #endregion

        #region Helpers
        private void CreateFile(string FilePath)
        {
            byte[] data = new byte[1024];
            int ct = 0;

            for (int i = 0; i < 1024; i++)
            {
                data[i] = (byte)ct;
                if (i % 255 == 0)
                    ct = 0;

                ct++;
            }

            ct = 0;
            using (FileStream fs = new FileStream(FilePath, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                while (ct < this.DataSize)
                {
                    fs.Write(data, 0, data.Length);
                    ct += data.Length;
                }
            }
        }

        private void DestroyFile(string FilePath)
        {
            if (File.Exists(FilePath))
                File.Delete(FilePath);
        }

        private string FileGetTemp()
        {
            return Path.GetTempFileName();
        }

        private IBlockCipher GetBlockEngine()
        {
            if (this.Engine == Engines.RDX)
                return new RDX();
            else if (this.Engine == Engines.RHX)
                return new RHX(this.Rounds);
            else if (this.Engine == Engines.RSM)
                return new RSM(this.Rounds);
            else if (this.Engine == Engines.RSX)
                return new RSX();
            else if (this.Engine == Engines.SHX)
                return new SHX(this.Rounds);
            else if (this.Engine == Engines.SPX)
                return new SPX(this.Rounds);
            else if (this.Engine == Engines.TFX)
                return new TFX(this.Rounds);
            else if (this.Engine == Engines.THX)
                return new THX(this.Rounds);
            else
                return null;
        }

        private ICipherMode GetCipher()
        {
            if (this.Mode == CipherModes.CBC)
                return new CBC(GetBlockEngine());
            else if (this.Mode == CipherModes.CTR)
                return new CTR(GetBlockEngine());
            else
                return new CTR(GetBlockEngine());
        }

        private IStreamCipher GetStreamEngine()
        {
            if (this.Engine == Engines.ChaCha)
                return new ChaCha();
            else if (this.Engine == Engines.Fusion)
                return new Fusion();
            else if (this.Engine == Engines.DCS)
                return new DCS();
            else if (this.Engine == Engines.Salsa)
                return new Salsa20();
            else
                return null;
        }

        private KeyParams GetKeyParams()
        {
            if (this.Engine == Engines.ChaCha)
                return new KeyParams(KeyGenerator.Generate(48), KeyGenerator.Generate(8));
            else if (this.Engine == Engines.DCS)
                return new KeyParams(KeyGenerator.Generate(96));
            else if (this.Engine == Engines.Salsa)
                return new KeyParams(KeyGenerator.Generate(48), KeyGenerator.Generate(8));
            else if (this.Engine == Engines.Fusion)
                return new KeyParams(KeyGenerator.Generate(320), KeyGenerator.Generate(16));

            if (this.KeySize != 0)
                return new KeyParams(KeyGenerator.Generate(this.KeySize), KeyGenerator.Generate(16));
            else if (this.Engine == Engines.RDX)
                return new KeyParams(KeyGenerator.Generate(32), KeyGenerator.Generate(16));
            else if (this.Engine == Engines.RHX)
                return new KeyParams(KeyGenerator.Generate(192), KeyGenerator.Generate(16));
            else if (this.Engine == Engines.RSM)
                return new KeyParams(KeyGenerator.Generate(192), KeyGenerator.Generate(16));
            else if (this.Engine == Engines.RSX)
                return new KeyParams(KeyGenerator.Generate(64), KeyGenerator.Generate(16));
            else if (this.Engine == Engines.SHX)
                return new KeyParams(KeyGenerator.Generate(192), KeyGenerator.Generate(16));
            else if (this.Engine == Engines.SPX)
                return new KeyParams(KeyGenerator.Generate(32), KeyGenerator.Generate(16));
            else if (this.Engine == Engines.TFX)
                return new KeyParams(KeyGenerator.Generate(32), KeyGenerator.Generate(16));
            else
                return null;
        }
        #endregion
    }
}
