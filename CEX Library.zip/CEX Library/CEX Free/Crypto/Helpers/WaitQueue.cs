﻿using System;
using System.Diagnostics;
using System.Threading;

namespace VTDev.Projects.CEX.Crypto.Helpers
{
    public class WaitQueue
    {
        #region Structs
        /// <summary>
        /// Contains high and low processing times
        /// </summary>
        public struct ProcessingTimes
        {
            internal double Low;
            internal double High;
        }
        #endregion

        #region Fields
        private double _Delay = 0.0;
        private double _Elapsed = 0;
        private int _Size = 0;
        private int _Count = 0;
        private byte[] _Queue;
        private byte[] _Temp;
        private Stopwatch _Timer;
        private EventWaitHandle _Wait;
        #endregion

        #region Constructor
        /// <summary>
        /// Initialize the class
        /// </summary>
        /// <param name="Size">Queue size, should be a multible of cipher block size, e.g. 16 block = 1440 queue</param>
        /// <param name="CTime">Constant time value for each queue processed</param>
        public WaitQueue(int Size, double CTime)
        {
            _Size = Size;
            _Delay = CTime;
            _Queue = new byte[Size];
        }

        ~ WaitQueue()
        {
            Destroy();
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Empty the queue
        /// </summary>
        /// <returns></returns>
        public byte[] DeQueue()
        {
            _Count = 0;
            return _Queue;
        }

        /// <summary>
        /// Process a partial queue size, then trigger wait
        /// </summary>
        /// <param name="Data">Queue input</param>
        public void Final(byte[] Data)
        {
            Array.Resize<byte>(ref _Queue, _Count + Data.Length);
            Buffer.BlockCopy(Data, Data.Length, _Queue, _Count, Data.Length);
            _Count = _Size;
            Wait();

            _Timer.Stop();
            _Timer.Reset();
            _Count = 0;
        }

        /// <summary>
        /// Initialize the queue
        /// </summary>
        public virtual void Init()
        {
            _Timer = new Stopwatch();
            _Wait = new AutoResetEvent(true);
            _Timer.Start();
        }

        /// <summary>
        /// Add data to the queue
        /// </summary>
        /// <param name="Data">Queue input</param>
        /// <returns>Returns true if queue is full</returns>
        public bool Queue(byte[] Data)
        {
            int len = Data.Length;

            if (_Temp != null)
            {
                Buffer.BlockCopy(_Temp, 0, _Queue, 0, _Temp.Length);
                _Count += _Temp.Length;
                _Temp = null;
                Wait();
            }

            if (len + _Count > _Size)
            {
                len = _Size - _Count;
                int tlen = Data.Length - len;
                _Temp = new byte[tlen];
                Buffer.BlockCopy(Data, len, _Temp, 0, tlen);
            }

            Buffer.BlockCopy(Data, 0, _Queue, _Count, len);
            _Count += len;

            return Wait();
        }
        #endregion

        #region Private Methods
        private void Destroy()
        {
            if (_Queue != null)
            {
                Array.Clear(_Queue, 0, _Queue.Length);
                _Queue = null;
            }
            if (_Temp != null)
            {
                Array.Clear(_Temp, 0, _Temp.Length);
                _Temp = null;
            }
            if (_Wait != null)
            {
                _Wait.Dispose();
                _Wait = null;
            }
            if (_Timer != null)
            {
                _Timer = null;
            }
        }

        private double GetElapsed()
        {
            double tms = _Timer.Elapsed.TotalMilliseconds;
            double cms = tms - _Elapsed;
            _Elapsed = tms;

            return cms;
        }

        private bool Wait()
        {
            if (_Count >= _Size)
            {
                int cms = (int)GetElapsed();
                if (cms > 0)
                    _Wait.WaitOne(cms);
                _Count = 0;

                return true;
            }

            return false;
        }
        #endregion

        public class SampleQueue : WaitQueue
        {
            #region Public Methods
            /// <summary>
            /// Timing samples, maximum and minimum times
            /// </summary>
            public ProcessingTimes Samples;
            #endregion

            #region Public Methods
            /// <summary>
            /// Initialize the class
            /// </summary>
            /// <param name="Size">Size of queue</param>
            /// <param name="CTime">Not used</param>
            public SampleQueue(int Size, double CTime)
                : base(Size, CTime)
            {
                _Size = Size;
                _Delay = CTime;
                _Queue = new byte[Size];
            }
            #endregion

            #region Public Methods
            /// <summary>
            /// Initialize the queue
            /// </summary>
            public override void Init()
            {
                base.Init();
                Samples = new ProcessingTimes();
            }

            /// <summary>
            /// Add data to the queue
            /// </summary>
            /// <param name="Data">Queue input</param>
            public void SQueue(byte[] Data)
            {
                int len = Data.Length;

                if (_Temp != null)
                {
                    Buffer.BlockCopy(_Temp, 0, _Queue, 0, _Temp.Length);
                    _Count += _Temp.Length;
                    _Temp = null;
                    if (_Count >= _Size)
                        SampleTime();
                }

                if (len + _Count > _Size)
                {
                    len = _Size - _Count;
                    int tlen = Data.Length - len;
                    _Temp = new byte[tlen];
                    Buffer.BlockCopy(Data, len, _Temp, 0, tlen);
                }

                Buffer.BlockCopy(Data, 0, _Queue, _Count, len);
                _Count += len;

                SampleTime();
            }
            #endregion

            #region Private Methods
            private void SampleTime()
            {
                if (_Count >= _Size)
                {
                    double ms = GetElapsed();

                    if (Samples.Low == 0 || Samples.Low > ms)
                        Samples.Low = ms;
                    if (Samples.High == 0 || Samples.High < ms)
                        Samples.High = ms;

                    _Count = 0;
                }
            }
            #endregion
        }
    }
}
