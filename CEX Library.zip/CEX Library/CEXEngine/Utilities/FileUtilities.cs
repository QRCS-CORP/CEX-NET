﻿using System;
using System.IO;
using System.Security.AccessControl;
using System.Security.Principal;

namespace VTDev.Libraries.CEXEngine.Utilities
{
    public static class FileUtilities
    {
        #region Drive Tools
        /// <summary>
        /// Get Total Drive space
        /// </summary>
        /// <param name="DrivePath">Path to drive</param>
        /// <returns>Result [long]</returns>
        public static long DriveGetSize(string DrivePath)
        {
            if (!string.IsNullOrEmpty(DrivePath))
            {
                DriveInfo d = new DriveInfo(DrivePath);

                if (d.IsReady)
                    return d.TotalSize;
            }
            return 0;
        }

        /// <summary>
        /// Get Drive Free space
        /// </summary>
        /// <param name="DrivePath">Path to drive</param>
        /// <returns>Result [long]</returns>
        public static long DriveGetFreeSpace(string DrivePath)
        {
            if (!string.IsNullOrEmpty(DrivePath))
            {
                DriveInfo d = new DriveInfo(DrivePath);

                if (d.IsReady)
                    return d.AvailableFreeSpace;
            }
            return 0;
        }

        /// <summary>
        /// Get Drive Free space
        /// </summary>
        /// <param name="DrivePath">Path to drive</param>
        /// <returns>Result [long]</returns>
        public static long DriveGetFreeSpaceMB(string DrivePath)
        {
            if (!string.IsNullOrEmpty(DrivePath))
            {
                DriveInfo d = new DriveInfo(DrivePath);

                if (d.IsReady)
                {
                    double bytes = d.AvailableFreeSpace;
                    double divisor = Math.Pow(1024, 2);

                    return (bytes > divisor) ? (long)(bytes / divisor) : 0;
                }
            }
            return 0;
        }

        /// <summary>
        /// Get the drive path from a directory or file path
        /// </summary>
        /// <param name="DirectoryPath">Path</param>
        /// <returns>Result [string]</returns>
        public static string DriveGetPath(string DirectoryPath)
        {
            return (!string.IsNullOrEmpty(DirectoryPath) ? Path.GetPathRoot(DirectoryPath) : string.Empty);
        }

        /// <summary>
        /// Drive is available
        /// </summary>
        /// <param name="DrivePath">Path to drive</param>
        /// <returns>Result [bool]</returns>
        public static bool IsDriveReady(string DrivePath)
        {
            return (!string.IsNullOrEmpty(DrivePath)) ? new DriveInfo(DrivePath).IsReady : false;
        }
        #endregion

        #region Directory Tools
        /// <summary>
        /// Create a folder
        /// </summary>
        /// <param name="DirectoryPath">Full path to folder</param>
        /// <returns>Success [bool]</returns>
        public static bool DirectoryCreate(string DirectoryPath)
        {
            return (!string.IsNullOrEmpty(DirectoryPath)) ? Directory.CreateDirectory(DirectoryPath).Exists : false;
        }

        /// <summary>
        /// Test for directory and create
        /// </summary>
        /// <param name="DirectoryPath">Full path to folder</param>
        /// <returns>Success [bool]</returns>
        public static bool DirectoryChecked(string DirectoryPath)
        {
            if (!string.IsNullOrEmpty(DirectoryPath)) return false;
            return Directory.Exists(DirectoryPath) ? true : DirectoryCreate(DirectoryPath);
        }

        /// <summary>
        /// Test for directory
        /// </summary>
        /// <param name="DirectoryPath">Full path to folder</param>
        /// <returns>Success [bool]</returns>
        public static bool DirectoryExists(string DirectoryPath)
        {


            bool b = Directory.Exists(DirectoryPath);
            return (!string.IsNullOrEmpty(DirectoryPath)) ? Directory.Exists(DirectoryPath) : false;
        }

        /// <summary>
        /// Get the number of files in a directory
        /// </summary>
        /// <param name="DirectoryPath">Full directory path</param>
        /// <returns>Count [int]</returns>
        public static int DirectoryGetFileCount(string DirectoryPath)
        {
            string[] filePaths = DirectoryGetFiles(DirectoryPath);
            return filePaths == null ? 0 : filePaths.Length;
        }

        /// <summary>
        /// Return all the files in a directory
        /// </summary>
        /// <param name="DirectoryPath">Directory path</param>
        /// <returns>File names [string]]</returns>
        public static string[] DirectoryGetFiles(string DirectoryPath)
        {
            try
            {
                return (DirectoryExists(DirectoryPath)) ? Directory.GetFiles(DirectoryPath) : null;
            }
            catch { }
            return null;
        }

        /// <summary>
        /// Get common directories
        /// </summary>
        /// <param name="FileName">Folder enum</param>
        /// <returns>Directory [string]</returns>
        public static string DirectoryGetCommon(Environment.SpecialFolder FolderPath)
        {
            try
            {
                return Environment.GetFolderPath(FolderPath);
            }
            catch { }
            return string.Empty;
        }

        /// <summary>
        /// Get file directory from path
        /// </summary>
        /// <param name="FileName">File path</param>
        /// <returns>Directory [string]</returns>
        public static string DirectoryGetPath(string FilePath)
        {
            return (!string.IsNullOrEmpty(FilePath)) ? Path.GetDirectoryName(FilePath) : string.Empty;
        }

        /// <summary>
        /// Return all the files in a directory
        /// </summary>
        /// <param name="DirectoryPath">Directory path</param>
        /// <returns>File names [string]]</returns>
        public static long DirectoryGetSize(string DirectoryPath)
        {
            if (!DirectoryExists(DirectoryPath)) return -1;
            long size = 0;

            try
            {
                string[] files = Directory.GetFiles(DirectoryPath, "*.*", SearchOption.AllDirectories);

                foreach (var file in files)
                    size += FileGetSize(file);

                return size;
            }
            catch { }
            return -1;
        }

        /// <summary>
        /// Test a directory for create file access permissions
        /// </summary>
        /// <param name="DirectoryPath">Full path to file or directory </param>
        /// <param name="AccessRight">File System right tested</param>
        /// <returns>State [bool]</returns>
        public static bool DirectoryHasPermission(string DirectoryPath, FileSystemRights AccessRight)
        {
            if (string.IsNullOrEmpty(DirectoryPath)) return false;

            try
            {
                AuthorizationRuleCollection rules = Directory.GetAccessControl(DirectoryPath).GetAccessRules(true, true, typeof(System.Security.Principal.SecurityIdentifier));
                WindowsIdentity identity = WindowsIdentity.GetCurrent();

                foreach (FileSystemAccessRule rule in rules)
                {
                    if (identity.Groups.Contains(rule.IdentityReference))
                    {
                        if ((AccessRight & rule.FileSystemRights) == AccessRight)
                        {
                            if (rule.AccessControlType == AccessControlType.Allow)
                                return true;
                        }
                    }
                }
            }
            catch { }
            return false;
        }

        /// <summary>
        /// Directory can write/create
        /// </summary>
        /// <param name="DirectoryPath">Directory path</param>
        /// <returns>Success [bool]</returns>
        public static bool DirectoryIsWritable(string DirectoryPath)
        {
            try
            {
                if (!DirectoryExists(DirectoryPath)) return false;

                string path = Path.Combine(DirectoryPath, Path.GetRandomFileName());
                using (FileStream fs = File.Create(path, 1, FileOptions.DeleteOnClose))
                {
                    return File.Exists(path);
                }
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Test a directory for create file access permissions
        /// </summary>
        /// <param name="DirectoryPath">Full directory path</param>
        /// <returns>State [bool]</returns>
        public static bool DirectoryCanCreate(string DirectoryPath)
        {
            if (string.IsNullOrEmpty(DirectoryPath)) return false;

            try
            {
                AuthorizationRuleCollection rules = Directory.GetAccessControl(DirectoryPath).GetAccessRules(true, true, typeof(System.Security.Principal.SecurityIdentifier));
                WindowsIdentity identity = WindowsIdentity.GetCurrent();

                foreach (FileSystemAccessRule rule in rules)
                {
                    if (identity.Groups.Contains(rule.IdentityReference))
                    {
                        if ((FileSystemRights.CreateFiles & rule.FileSystemRights) == FileSystemRights.CreateFiles)
                        {
                            if (rule.AccessControlType == AccessControlType.Allow)
                                return true;
                        }
                    }
                }
            }
            catch { }
            return false;
        }

        /// <summary>
        /// Test a directory for write file access permissions
        /// </summary>
        /// <param name="DirectoryPath">Full directory path</param>
        /// <returns>State [bool]</returns>
        public static bool DirectoryCanWrite(string DirectoryPath)
        {
            if (string.IsNullOrEmpty(DirectoryPath)) return false;

            try
            {
                AuthorizationRuleCollection rules = Directory.GetAccessControl(DirectoryPath).GetAccessRules(true, true, typeof(System.Security.Principal.SecurityIdentifier));
                WindowsIdentity identity = WindowsIdentity.GetCurrent();

                foreach (FileSystemAccessRule rule in rules)
                {
                    if (identity.Groups.Contains(rule.IdentityReference))
                    {
                        if ((FileSystemRights.Write & rule.FileSystemRights) == FileSystemRights.Write)
                        {
                            if (rule.AccessControlType == AccessControlType.Allow)
                                return true;
                        }
                    }
                }
            }
            catch { }
            return false;
        }
        #endregion

        #region Directory Security
        /// <summary>
        /// Add an access rule to a folder
        /// </summary>
        /// <param name="Path">Folder path</param>
        /// <param name="User">UNC path to user profile ex. Environment.UserDomainName + "\\" + Environment.UserName</param>
        /// <param name="Rights">Desired file system rights</param>
        /// <param name="Access">Desired level of access</param>
        public static void DirectoryAddAccessRule(string Path, string User, FileSystemRights Rights, AccessControlType Access)
        {
            // Get a DirectorySecurity object that represents the current security settings
            System.Security.AccessControl.DirectorySecurity sec = System.IO.Directory.GetAccessControl(Path);
            // Add the FileSystemAccessRule to the security settings
            FileSystemAccessRule accRule = new FileSystemAccessRule(User, Rights, Access);
            sec.AddAccessRule(accRule);
        }

        /// <summary>
        /// Add a file system right to a directory
        /// </summary>
        /// <param name="Path">Full path to directory</param>
        /// <param name="Account">UNC path to user profile</param>
        /// <param name="Rights">Desired file system rights</param>
        /// <param name="ControlType">Access control type</param>
        public static void DirectoryAddSecurity(string Path, string Account, FileSystemRights Rights, AccessControlType ControlType)
        {
            // Create a new DirectoryInfo object
            DirectoryInfo dInfo = new DirectoryInfo(Path);
            // Get a DirectorySecurity object that represents the current security settings
            DirectorySecurity dSecurity = dInfo.GetAccessControl();
            // Add the FileSystemAccessRule to the security settings
            dSecurity.AddAccessRule(new FileSystemAccessRule(Account, Rights, ControlType));
            // Set the new access settings
            dInfo.SetAccessControl(dSecurity);
        }

        /// <summary>
        /// Get access rules for a folder
        /// </summary>
        /// <param name="Path">Folder path</param>
        /// <param name="Account">UNC path to user profile</param>
        /// <returns>Rule collection [AuthorizationRuleCollection]</returns>
        public static AuthorizationRuleCollection DirectoryGetAccessRules(string Path, string Account)
        {
            DirectoryInfo dInfo = new DirectoryInfo(Path);
            DirectorySecurity dSecurity = dInfo.GetAccessControl();
            return dSecurity.GetAccessRules(true, true, typeof(System.Security.Principal.SecurityIdentifier));
        }

        /// <summary>
        /// Remove a file system right to a directory
        /// </summary>
        /// <param name="Path">Full path to directory</param>
        /// <param name="Account">UNC path to user profile</param>
        /// <param name="Rights">Desired file system rights</param>
        /// <param name="ControlType">Access control type</param>
        public static void DirectoryRemoveSecurity(string FileName, string Account, FileSystemRights Rights, AccessControlType ControlType)
        {
            // Create a new DirectoryInfo object.
            DirectoryInfo dInfo = new DirectoryInfo(FileName);
            // Get a DirectorySecurity object that represents the current security settings  
            DirectorySecurity dSecurity = dInfo.GetAccessControl();
            // Add the FileSystemAccessRule to the security settings
            dSecurity.RemoveAccessRule(new FileSystemAccessRule(Account, Rights, ControlType));
            // Set the new access settings
            dInfo.SetAccessControl(dSecurity);
        }
        #endregion

        #region File Tools
        /// <summary>
        /// Append data to a file
        /// </summary>
        /// <param name="FilePath">Full path to file</param>
        /// <param name="Data">Data to write</param>
        /// <returns>Success [bool]</returns>
        public static bool FileAppendData(string FilePath, MemoryStream Data)
        {
            if (!FileExists(FilePath)) return false;

            try
            {
                using (FileStream fs = new FileStream(FilePath, FileMode.Append | FileMode.Create))
                    fs.Write(Data.ToArray(), 0, (int)Data.Length);

                return true;
            }
            catch { }
            return false;
        }

        /// <summary>
        /// Append binary data to start of file
        /// </summary>
        /// <param name="FilePath">Full file path</param>
        /// <param name="Data">Data stream</param>
        /// <returns>Success [bool]</returns>
        public static bool FileAppendBinaryToStart(string FilePath, MemoryStream Data)
        {
            if (!FileExists(FilePath)) return false;
            if (Data == null) return false;
            if (Data.Length < 1) return false;

            var tempfile = Path.GetTempFileName();
            byte[] buffer = new byte[1024];
            int read = 0;

            try
            {
                using (FileStream tempStream = new FileStream(tempfile, FileMode.Append, FileAccess.Write))
                {
                    using (BinaryWriter writer = new BinaryWriter(tempStream))
                    {
                        writer.Write(Data.ToArray());
                        using (FileStream fileStream = new FileStream(FilePath, FileMode.Open))
                        {
                            using (BinaryReader reader = new BinaryReader(fileStream))
                            {
                                while ((read = reader.Read(buffer, 0, buffer.Length)) > 0)
                                    writer.Write(buffer, 0, read);
                            }
                        }
                        writer.Close();
                    }
                }

                File.Copy(tempfile, FilePath, true);
                File.Delete(tempfile);

                return true;
            }
            catch { }
            return false;
        }

        /// <summary>
        /// Append binary data into a file
        /// </summary>
        /// <param name="FilePath">Full path to file</param>
        /// <param name="Data">Data to write</param>
        /// <returns>Success [bool]</returns>
        public static bool FileAppendBinary(string FilePath, MemoryStream Data)
        {
            if (Data == null) return false;
            if (Data.Length < 1) return false;
            if (!FileExists(FilePath)) return FilePutBinary(FilePath, Data);

            try
            {
                using (FileStream fs = new FileStream(FilePath, FileMode.Append, FileAccess.Write, FileShare.ReadWrite))
                {
                    using (BinaryWriter writer = new BinaryWriter(fs))
                    {
                        writer.Write(Data.ToArray());
                        writer.Close();
                    }
                }
                long l = FileGetSize(FilePath);
                return true;
            }
            catch { }
            return false;
        }

        /// <summary>
        /// Copy a file
        /// </summary>
        /// <param name="FilePath">File to delete</param>
        /// <returns>Success [bool]</returns>
        public static bool FileCopy(string SourceFile, string DestinationFile)
        {
            if (!FileExists(SourceFile)) return false;

            try
            {
                File.Copy(SourceFile, DestinationFile, true);
                return FileExists(DestinationFile);
            }
            catch { }
            return false;
        }

        /// <summary>
        /// Copy a file with progress using the web client
        /// </summary>
        /// <param name="SourceFile"></param>
        /// <param name="DestinationFile"></param>
        public delegate void CopyProgressDelegate(int progress);
        public static event CopyProgressDelegate FileCopyProgress;
        public static bool FileCopyWithProgress(string SourceFile, string DestinationFile)
        {
            if (!FileExists(SourceFile)) return false;

            try
            {
                var fileClient = new System.Net.WebClient();

                if (fileClient == null) return false;

                fileClient.DownloadProgressChanged += DownloadProgress;
                fileClient.DownloadFileAsync(new Uri(SourceFile), DestinationFile);
                return true;
            }
            catch { }
            return false;
        }

        /// <summary>
        /// FileCopyWithProgress progress tick
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private static void DownloadProgress(object sender, System.Net.DownloadProgressChangedEventArgs e)
        {
            if (FileCopyProgress != null)
                FileCopyProgress(e.ProgressPercentage);
        }

        /// <summary>
        /// Delete a file
        /// </summary>
        /// <param name="FilePath">File to delete</param>
        /// <returns>Success [bool]</returns>
        public static bool FileDelete(string FilePath)
        {
            if (!FileExists(FilePath)) return false;

            try
            {
                File.Delete(FilePath);
                return !FileExists(FilePath);
            }
            catch { }
            return false;
        }

        /// <summary>
        /// Test if file Exists
        /// </summary>
        /// <returns>Success [bool]</returns>
        public static bool FileExists(string FilePath)
        {
            return (IsValidFilePath(FilePath) ? File.Exists(FilePath) : false);
        }

        /// <summary>
        /// Safely create a full path
        /// </summary>
        /// <param name="DirectoryPath">Directory path</param>
        /// <param name="FileName">File name</param>
        /// <returns>Full path to file</returns>
        public static string FileJoinPaths(string DirectoryPath, string FileName)
        {
            const string slash = @"\";

            if (string.IsNullOrEmpty(DirectoryPath)) return string.Empty;
            if (string.IsNullOrEmpty(FileName)) return string.Empty;

            if (!DirectoryPath.EndsWith(slash))
                DirectoryPath += slash;

            if (FileName.StartsWith(slash))
                FileName = FileName.Substring(1);

            return DirectoryPath + FileName;
        }

        /// <summary>
        /// Get the File Attributes
        /// </summary>
        /// <param name="FilePath">Full path to file</param>
        /// <returns>Attributes [FileAttributes]</returns>
        public static FileAttributes FileGetAttributes(string FilePath)
        {
            if (!FileExists(FilePath)) return FileAttributes.Offline;

            return File.GetAttributes(FilePath);
        }

        /// <summary>
        /// Remove a specific file attribute
        /// </summary>
        /// <param name="FilePath">Full path to file</param>
        /// <param name="Attribute">File attribute [FileAttributes]</param>
        public static void FileRemoveAttribute(string FilePath, FileAttributes Attribute)
        {
            if (!FileExists(FilePath)) return;

            try
            {
                FileAttributes attributes = File.GetAttributes(FilePath);

                if (attributes.HasFlag(Attribute))
                    File.SetAttributes(FilePath, attributes & ~Attribute);
            }
            catch { }
        }

        /// <summary>
        /// Set a File Attribute
        /// </summary>
        /// <param name="FilePath">Full path to file</param>
        /// <param name="Attribute">FileAttributes</param>
        public static void FileSetAttributes(string FilePath, FileAttributes Attribute)
        {
            if (!FileExists(FilePath)) return;

            File.SetAttributes(FilePath, Attribute & FileGetAttributes(FilePath));
        }

        /// <summary>
        /// Test a file for create file access permissions
        /// </summary>
        /// <param name="FilePath">Full path to file</param>
        /// <param name="AccessRight">File System right tested</param>
        /// <returns>State [bool]</returns>
        public static bool FileHasPermission(string FilePath, FileSystemRights AccessRight)
        {
            if (string.IsNullOrEmpty(FilePath)) return false;

            try
            {
                AuthorizationRuleCollection rules = File.GetAccessControl(FilePath).GetAccessRules(true, true, typeof(System.Security.Principal.SecurityIdentifier));
                WindowsIdentity identity = WindowsIdentity.GetCurrent();

                foreach (FileSystemAccessRule rule in rules)
                {
                    if (identity.Groups.Contains(rule.IdentityReference))
                    {
                        if ((AccessRight & rule.FileSystemRights) == AccessRight)
                        {
                            if (rule.AccessControlType == AccessControlType.Allow)
                                return true;
                        }
                    }
                }
            }
            catch { }
            return false;
        }

        /// <summary>
        /// Read binary data from a file
        /// </summary>
        /// <param name="FilePath">Full path to file</param>
        /// <param name="StartPosition">Start position in file</param>
        /// <param name="DataLength">Length of data to read</param>
        /// <returns>Stream [MemoryStream]</returns>
        public static MemoryStream FileGetBinaryData(string FilePath, int StartPosition, int DataLength)
        {
            if (!FileExists(FilePath)) return null;

            byte[] data = new byte[0];

            try
            {
                using (FileStream fs = new FileStream(FilePath, FileMode.Open))
                {
                    using (BinaryReader br = new BinaryReader(fs))
                    {
                        if (StartPosition + DataLength <= fs.Length)
                        {
                            data = new byte[DataLength];
                            br.Read(data, StartPosition, data.Length);
                        }
                    }
                }
                if (data.Length > 0)
                    return new MemoryStream(data);
            }
            catch { }
            return null;
        }

        /// <summary>
        /// Read binary data from a file
        /// </summary>
        /// <param name="FilePath">Full path to file</param>
        /// <returns>Stream [MemoryStream]</returns>
        public static MemoryStream FileGetBinaryData(string FilePath)
        {
            if (!FileExists(FilePath)) return null;

            byte[] data = new byte[0];

            try
            {
                using (FileStream fs = new FileStream(FilePath, FileMode.Open))
                {
                    using (BinaryReader br = new BinaryReader(fs))
                    {
                        data = new byte[fs.Length];
                        br.Read(data, 0, data.Length);
                    }
                }
                if (data.Length > 0)
                    return new MemoryStream(data);
            }
            catch { }
            return null;
        }

        /// <summary>
        /// Extract data from file
        /// </summary>
        /// <param name="FilePath">Full path to file</param>
        /// <returns>File stream [MemoryStream]</returns>
        public static MemoryStream FileGetData(string FilePath)
        {
            if (!FileExists(FilePath)) return null;

            byte[] data;
            MemoryStream stream = new MemoryStream();

            try
            {
                using (FileStream fs = new FileStream(FilePath, FileMode.Open))
                {
                    data = new byte[fs.Length];
                    fs.Read(data, 0, data.Length);
                    stream.Write(data, 0, data.Length);
                    stream.Position = 0;
                }
                return stream;
            }
            catch { }
            return null;
        }

        /// <summary>
        /// Get the file extension
        /// </summary>
        /// <param name="FileName">File name</param>
        /// <returns>Success [bool]</returns>
        public static string FileGetExtension(string FileName)
        {
            try
            {
                return (!string.IsNullOrEmpty(FileName)) ? Path.GetExtension(FileName) : string.Empty;
            }
            catch { }
            return string.Empty;
        }

        /// <summary>
        /// Get file name without extension
        /// </summary>
        /// <param name="FilePath">File path</param>
        /// <returns>Name [string]</returns>
        public static string FileGetName(string FilePath)
        {
            return (IsValidFileName(FilePath)) ? Path.GetFileNameWithoutExtension(FilePath) : string.Empty;
        }

        /// <summary>
        /// Get file name with extension
        /// </summary>
        /// <param name="FilePath">File path</param>
        /// <returns>Name [string]</returns>
        public static string FileGetFullName(string FilePath)
        {
            return (IsValidFileName(FilePath)) ? Path.GetFileName(FilePath) : string.Empty;
        }

        /// <summary>
        /// Get the size of  file
        /// </summary>
        /// <param name="FilePath">Full path to file</param>
        /// <returns>File length [long]</returns>
        public static long FileGetSize(string FilePath)
        {
            try
            {
                return FileExists(FilePath) ? new FileInfo(FilePath).Length : 0;
            }
            catch { }
            return -1;
        }

        /// <summary>
        /// Creates a temporary file
        /// </summary>
        /// <returns>File path [string]</returns>
        public static string FileGetTemp()
        {
            return Path.GetTempFileName();
        }

        /// <summary>
        /// Adds an extension to a file unique to the directory
        /// </summary>
        /// <param name="FullPath">Full file path</param>
        /// <returns>Unique filename in original path</returns>
        public static string FileGetUniqueName(string FullPath)
        {
            if (!IsValidFilePath(FullPath)) return string.Empty;
            if (!DirectoryExists(DirectoryGetPath(FullPath))) return string.Empty;

            string folderPath = DirectoryGetPath(FullPath);
            string fileName = FileGetName(FullPath);
            string fileExtension = FileGetExtension(FullPath);

            string filePath = Path.Combine(folderPath, fileName + fileExtension);

            for (int i = 1; i < 10240; i++)
            {
                // test unique names
                if (File.Exists(filePath))
                    filePath = Path.Combine(folderPath, fileName + " " + i.ToString() + fileExtension);
                else
                    break;
            }

            return filePath;
        }

        /// <summary>
        /// File is readable
        /// </summary>
        /// <param name="FilePath">Full path to file</param>
        /// <returns>Success [bool]</returns>
        public static bool FileIsReadable(string FilePath)
        {
            try
            {
                if (!FileExists(FilePath)) return false;
                using (FileStream fs = new FileStream(FilePath, FileMode.Open, FileAccess.Read)) { }
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Test a file to see if it is readonly
        /// </summary>
        /// <param name="FilePath">Full path to file</param>
        /// <returns>Read only [bool]</returns>
        public static bool FileIsReadOnly(string FilePath)
        {
            if (!IsValidFilePath(FilePath)) return false;
            if (!FileExists(FilePath)) return false;

            FileAttributes fa = File.GetAttributes(FilePath);
            return (fa.ToString().IndexOf(FileAttributes.ReadOnly.ToString()) > -1);
        }

        /// <summary>
        /// Put binary data into a file
        /// </summary>
        /// <param name="FilePath">Full path to file</param>
        /// <param name="Data">Data to write</param>
        /// <returns>Success [bool]</returns>
        public static bool FilePutBinary(string FilePath, MemoryStream Data)
        {
            if (!IsValidFilePath(FilePath)) return false;
            if (Data == null) return false;
            if (Data.Length < 1) return false;

            try
            {
                using (FileStream fs = new FileStream(FilePath, FileMode.CreateNew, FileAccess.Write, FileShare.Read))
                {
                    using (BinaryWriter writer = new BinaryWriter(fs))
                    {
                        writer.Write(Data.ToArray());
                        writer.Close();
                    }
                }
                return true;
            }
            catch { }
            return false;
        }

        /// <summary>
        /// Put data into a file
        /// </summary>
        /// <param name="FilePath">Full path to file</param>
        /// <param name="Data">Data to write</param>
        /// <returns>Success [bool]</returns>
        ///[method: FileIOPermission(SecurityAction.Demand, Unrestricted = true, AllLocalFiles = FileIOPermissionAccess.AllAccess)] <--useless
        public static bool FilePutData(string FilePath, MemoryStream Data)
        {
            if (!IsValidFilePath(FilePath)) return false;
            if (Data == null) return false;
            if (Data.Length < 1) return false;

            try
            {
                byte[] data = Data.ToArray();
                using (FileStream fs = new FileStream(FilePath, FileMode.CreateNew, FileAccess.Write, FileShare.Read))
                {
                    fs.Write(data, 0, data.Length);
                }

                return true;
            }
            catch { }
            return false;
        }

        /// <summary>
        /// Rename a file
        /// </summary>
        /// <param name="FilePath">Full path to old File</param>
        /// /// <param name="FilePath">Full path to New file</param>
        /// <returns>Success [bool]</returns>
        public static bool FileRename(string OldFilePath, string NewFilePath)
        {
            if (!FileExists(OldFilePath)) return false;
            if (FileExists(NewFilePath)) return false;

            try
            {
                File.Move(OldFilePath, NewFilePath);
                return FileExists(NewFilePath);
            }
            catch { }
            return false;
        }

        /// <summary>
        /// Save a file
        /// </summary>
        /// <param name="FilePath">Full path to file</param>
        /// <param name="Data">File data [MemoryStream]</param>
        /// <returns>Success [bool]</returns>
        public static bool FileSave(string FilePath, MemoryStream Data)
        {
            if (IsValidFilePath(FilePath))
                if (Data != null)
                    if (Data.Length > 0)
                        return (FilePutData(FilePath, Data));

            return false;
        }

        /// <summary>
        /// Save a file
        /// </summary>
        /// <param name="FilePath">Full path to file</param>
        /// <param name="Data">File data [byte[]]</param>
        /// <returns>Success [bool]</returns>
        public static bool FileSave(string FilePath, byte[] Data)
        {
            if (IsValidFilePath(FilePath))
                if (Data != null)
                    if (Data.Length > 0)
                        return (FilePutData(FilePath, new MemoryStream(Data)));

            return false;
        }

        /// <summary>
        /// Delete a file securely
        /// </summary>
        /// <param name="FilePath">Full path to file</param>
        /// <returns>Success [bool]</returns>
        ///[method: FileIOPermission(SecurityAction.Demand, Unrestricted = true, AllLocalFiles = FileIOPermissionAccess.AllAccess)]
        public static bool FileSecureDelete(string FilePath)
        {
            if (!FileExists(FilePath)) return false;

            try
            {
                if (FileExists(FilePath))
                {
                    long size = FileGetSize(FilePath);
                    // zero byte
                    const int blocksize = 1024;
                    byte[] zbyte = new byte[size];
                    // 1's array
                    byte[] ntemp = new byte[blocksize];
                    byte[] nbyte = new byte[size];
                    // init 1's array
                    for (int i = 0; i < blocksize; i++)
                        ntemp[i] = 0xff;

                    // get dimensions
                    int blocks = (int)(size / blocksize);
                    int remainder = (int)(size - (blocks * blocksize));
                    int count = 0;

                    // copy to the buffer
                    do
                    {
                        Buffer.BlockCopy(ntemp, 0, nbyte, blocksize * count, blocksize);
                        count++;
                    } while (count < blocks);

                    // copy remaining bytes
                    Buffer.BlockCopy(ntemp, 0, nbyte, blocksize * count, remainder);

                    // overwite alternating 1s and 0s
                    for (int i = 0; i < 8; i++)
                    {
                        if ((i % 2) == 0)
                        {
                            using (FileStream fs = new FileStream(FilePath, FileMode.Create))
                            {
                                fs.Write(nbyte, 0, nbyte.Length);
                            }
                        }
                        else
                        {
                            using (FileStream fs = new FileStream(FilePath, FileMode.Create))
                            {
                                fs.Write(zbyte, 0, zbyte.Length);
                            }
                        }
                    }
                    // delete the file
                    FileDelete(FilePath);
                }
                return true;
            }
            catch { }
            return false;
        }

        /// <summary>
        /// Test if file name is valid [has extension]
        /// </summary>
        /// <param name="FileName">File name</param>
        /// <returns>Valid [bool]</returns>
        public static bool IsValidFileName(string FileName)
        {
            try
            {
                return (!string.IsNullOrEmpty(FileName) ? !string.IsNullOrEmpty(Path.GetExtension(FileName)) : false);
            }
            catch { }
            return false;
        }

        /// <summary>
        /// Test path to see if directory exists and file name has proper format
        /// </summary>
        /// <param name="FilePath">Full path to file</param>
        /// <returns>Valid [bool]</returns>
        public static bool IsValidFilePath(string FilePath)
        {
            if (DirectoryExists(DirectoryGetPath(FilePath)))
                if (IsValidFileName(FilePath))
                    return true;

            return false;
        }
        #endregion

        #region Utilities
        /// <summary>
        /// Format bytes into larger sizes
        /// </summary>
        /// <param name="bytes">Length in bytes</param>
        /// <returns>Size string</returns>
        public static string FormatBytes(long bytes)
        {
            if (bytes < 0) return string.Empty;

            const int scale = 1024;
            string[] orders = new string[] { "TB", "GB", "MB", "KB", "Bytes" };
            long max = (long)Math.Pow(scale, orders.Length - 1);

            foreach (string order in orders)
            {
                if (bytes > max)
                    return string.Format("{0:##.#} {1}", Decimal.Divide(bytes, max), order);

                max /= scale;
            }

            return string.Empty;
        }

        /// <summary>
        /// Get the local profile path
        /// </summary>
        /// <returns>Profile path [string]</returns>
        public static string GetLocalProfile()
        {
            return Environment.UserDomainName + "\\" + Environment.UserName;
        }
        #endregion
    }
}
