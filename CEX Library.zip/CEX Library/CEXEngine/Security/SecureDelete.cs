﻿using System;
using System.IO;
using System.Security.AccessControl;
using System.Security.Principal;

namespace VTDev.Libraries.CEXEngine.Security
{
    /// <summary>
    /// Referenced Table A-5 clear and purge on an ATA drive: 
    /// http://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-88r1.pdf
    /// </summary>
    public sealed class SecureDelete : IDisposable
    {
        #region Constants
        private const int BUFFER_SIZE = 4096;
        #endregion

        #region Fields
        private bool _Disposed = false;
        private byte[] _rndBuffer = new byte[BUFFER_SIZE];
        private byte[] _revBuffer = new byte[BUFFER_SIZE];
        private byte[] _zerBuffer = new byte[BUFFER_SIZE];
        #endregion

        #region Properties
        public long FileSize { get; private set; }
        #endregion

        #region Constructor
        public SecureDelete()
        {
            // get random buffer
            using (System.Security.Cryptography.RNGCryptoServiceProvider rng = new System.Security.Cryptography.RNGCryptoServiceProvider())
                rng.GetBytes(_rndBuffer);

            // create reverse random buffer
            Buffer.BlockCopy(_rndBuffer, 0, _revBuffer, 0, _revBuffer.Length);
            Array.Reverse(_revBuffer);
        }

        ~SecureDelete()
        {
            Dispose(false);
        }
        #endregion

        #region Public Methods
        public bool Delete(string FilePath)
        {
            if (!File.Exists(FilePath))
                return false;

            // permissions
            //if (!CanDelete(FilePath))
            //    return false;

            this.FileSize = GetFileSize(FilePath);

            if (this.FileSize < 1)
                return false;

            // three overwrite passes are more than enough
            OverWrite(FilePath, _rndBuffer);    // random
            OverWrite(FilePath, _revBuffer);    // reverse random
            OverWrite(FilePath, _zerBuffer);    // 0x0

            // rename 30 times
            Rename(ref FilePath);

            // delete
            DeleteFile(FilePath);

            return !File.Exists(FilePath);
        }
        #endregion

        #region Private Methods
        private void DeleteFile(string FilePath)
        {
            if (File.Exists(FilePath))
                File.Delete(FilePath);
        }

        private void OverWrite(string FilePath, byte[] Buffer)
        {
            long bytesWritten = 0;
            int bufferSize = BUFFER_SIZE;

            if (this.FileSize < BUFFER_SIZE)
                bufferSize = (int)this.FileSize;

            using (BinaryWriter outputWriter = new BinaryWriter(new FileStream(FilePath, FileMode.Create, FileAccess.Write, FileShare.None)))
            {
                while (bytesWritten < this.FileSize)
                {
                    outputWriter.Write(Buffer, 0, bufferSize);
                    bytesWritten += bufferSize;

                    if (this.FileSize - bytesWritten < bufferSize)
                        bufferSize = (int)(this.FileSize - bytesWritten);
                }
            }
        }

        private void Rename(ref string FilePath)
        {
            string newPath = "";
            string dirPath = Path.GetDirectoryName(FilePath);

            for (int i = 0; i < 30; i++)
            {
                newPath = Path.Combine(dirPath, Path.GetRandomFileName());

                if (File.Exists(newPath))
                    File.Delete(newPath);

                File.Move(FilePath, newPath);
                FilePath = newPath;
            }
        }
        #endregion

        #region Helpers
        private bool CanDelete(string FilePath)
        {
            return (GetFilePermission(FilePath, FileSystemRights.Write) && GetFilePermission(FilePath, FileSystemRights.Delete));
        }

        private bool GetFilePermission(string FilePath, FileSystemRights AccessRight)
        {
            try
            {
                AuthorizationRuleCollection rules = File.GetAccessControl(FilePath).GetAccessRules(true, true, typeof(System.Security.Principal.SecurityIdentifier));
                WindowsIdentity identity = WindowsIdentity.GetCurrent();

                foreach (FileSystemAccessRule rule in rules)
                {
                    if (identity.Groups.Contains(rule.IdentityReference))
                    {
                        if ((AccessRight & rule.FileSystemRights) == AccessRight)
                        {
                            if (rule.AccessControlType == AccessControlType.Allow)
                                return true;
                        }
                    }
                }
            }
            catch { }
            return false;
        }

        private long GetFileSize(string FilePath)
        {
            try
            {
                return new FileInfo(FilePath).Length;
            }
            catch { }
            return -1;
        }
        #endregion

        #region IDispose
        void IDisposable.Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (!_Disposed)
            {
                if (disposing)
                {
                    if (_revBuffer != null)
                    {
                        Array.Clear(_revBuffer, 0, _revBuffer.Length);
                        _revBuffer = null;
                    }
                    if (_rndBuffer != null)
                    {
                        Array.Clear(_rndBuffer, 0, _rndBuffer.Length);
                        _rndBuffer = null;
                    }
                    if (_zerBuffer != null)
                    {
                        Array.Clear(_zerBuffer, 0, _zerBuffer.Length);
                        _zerBuffer = null;
                    }
                }
                _Disposed = true;
            }
        }
        #endregion
    }
}
