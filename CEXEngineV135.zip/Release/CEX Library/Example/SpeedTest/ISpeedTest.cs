﻿
namespace VTDev.Projects.CEX.Tests
{
    public interface ISpeedTest
    {
        /// <summary>
        /// Run the test
        /// </summary>
        void Test();
    }
}
