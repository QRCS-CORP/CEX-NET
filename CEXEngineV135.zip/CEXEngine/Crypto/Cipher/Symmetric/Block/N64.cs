﻿#region Directives
using System;
using VTDev.Libraries.CEXEngine.Crypto.Generator;
using VTDev.Libraries.CEXEngine.Crypto.Mac;
using VTDev.Libraries.CEXEngine.Crypto.Digest;
using System.ComponentModel;
#endregion

#region License Information
// The MIT License (MIT)
// 
// Copyright (c) 2015 John Underhill
// This file is part of the CEX Cryptographic library.
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
// 
// Principal Algorithms:
// Cipher implementation based on the Rijndael block cipher designed by Joan Daemen and Vincent Rijmen:
// Rijndael <see href="http://csrc.nist.gov/archive/aes/rijndael/Rijndael-ammended.pdf">Specification</see>.
// AES specification <see href="http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf">Fips 197</see>.
// 
// Implementation Details:
// An implementation based on the Rijndael block cipher, 
// using HKDF with a selectable Message Digest for expanded key generation.
// Rijndael HKDF Extended (RHX)
// Written by John Underhill, November 11, 2014
// contact: develop@vtdev.com
#endregion

namespace VTDev.Libraries.CEXEngine.Crypto.Cipher.Symmetric.Block
{
    /// <summary>
    /// Drafting
    /// </summary>
    public sealed class N64 : IDisposable
    {
        #region Constants
        private const string ALG_NAME = "N64";
        private const Int32 BLOCK16 = 16;
        private const Int32 BLOCK32 = 32;
        private const Int32 DEFAULT_ROUNDS = 22;
        private const Int32 LEGAL_KEYS = 10;
        private const Int32 MAX_ROUNDS = 38;
        private const Int32 MIN_ROUNDS = 10;
        #endregion

        #region Fields
        private Int32 _blockSize = BLOCK16;
        private Int32 _dfnRounds = 22;
        private UInt64[] _expKey;
        // configurable nonce can create a unique distribution, can be byte(0)
        private byte[] _hkdfInfo = System.Text.Encoding.ASCII.GetBytes("information string RHX version 1");
        private Int32 _ikmSize = 0;
        private IDigest _keyEngine;
        private bool _isDisposed = false;
        private bool _isEncryption = false;
        private bool _isInitialized = false;
        private int[] _legalKeySizes = new int[LEGAL_KEYS];
        private Int32 _wrdBlocks = 4;
        #endregion

        #region Properties
        /// <summary>
        /// Get: Unit block size of internal cipher in bytes.
        /// <para>Block size must be 16 or 32 bytes wide. 
        /// Value set in class constructor.</para>
        /// </summary>
        public int BlockSize
        {
            get { return _blockSize; }
            private set { _blockSize = value; }
        }

        /// <summary>
        /// Get/Set: Sets the Info value in the HKDF initialization parameters. 
        /// <para>Must be set before <see cref="Initialize(bool, KeyParams)"/> is called.
        /// Changing this code will create a unique distribution of the cipher.
        /// Code can be either a zero byte array, or a multiple of the HKDF digest engines return size.</para>
        /// </summary>
        public byte[] DistributionCode
        {
            get { return _hkdfInfo; }
            set 
            {
                if (value == null)
                    throw new ArgumentNullException("Distribution Code can not be null!");

                _hkdfInfo = value; 
            }
        }

        /// <summary>
        /// Get/Set: Specify the size of the HMAC key; extracted from the cipher key
        /// <para>Default is the digest return size; can only be a multiple of that length</para>
        /// </summary>
        /// 
        /// <remarks>
        /// This is an advanced option, hidden for that reason
        /// </remarks>
        [EditorBrowsable(EditorBrowsableState.Never)]
        public int IkmSize
        {
            get { return _ikmSize; }
            set
            {
                if (value > 0 && value < _keyEngine.DigestSize)
                    _ikmSize = _keyEngine.DigestSize;
                else if (value > 0 && value % _keyEngine.DigestSize > 0)
                    _ikmSize = value - (value % _keyEngine.DigestSize);
                else
                    _ikmSize = 0;
            }
        }

        /// <summary>
        /// Get: Initialized for encryption, false for decryption.
        /// <para>Value set in <see cref="Initialize(bool, KeyParams)"/>.</para>
        /// </summary>
        public bool IsEncryption
        {
            get { return _isEncryption; }
            private set { _isEncryption = value; }
        }

        /// <summary>
        /// Get: Cipher is ready to transform data
        /// </summary>
        public bool IsInitialized
        {
            get { return _isInitialized; }
            private set { _isInitialized = value; }
        }

        /// <summary>
        /// Get: Available block sizes for this cipher
        /// </summary>
        public static int[] LegalBlockSizes
        {
            get { return new int[] { 16, 32 }; }
        }

        /// <summary>
        /// Get: Available Encryption Key Sizes in bytes
        /// </summary>
        public int[] LegalKeySizes
        {
            get { return _legalKeySizes; }
            private set { _legalKeySizes = value; }
        }

        /// <summary>
        /// Get: Available diffusion round assignments
        /// </summary>
        public static int[] LegalRounds
        {
            get { return new int[] { 10, 12, 14, 22, 38 }; }
        }

        /// <summary>
        /// Get: Cipher name
        /// </summary>
        public string Name
        {
            get { return ALG_NAME; }
        }
        #endregion

        #region Constructor
        /// <summary>
        /// Initialize the class
        /// </summary>
        /// 
        /// <param name="Rounds">Number of diffusion rounds. The <see cref="LegalRounds"/> property contains available sizes</param>
        /// <param name="BlockSize">Cipher input <see cref="BlockSize"/>. The <see cref="LegalBlockSizes"/> property contains available sizes</param>
        /// <param name="KeyEngine"><para>The Key Schedule KDF digest engine; can be any one of the <see cref="VTDev.Libraries.CEXEngine.Crypto.Digests">Digest</see> 
        /// implementations. The default engine is <see cref="SHA512"/></para>.</param>
        /// 
        /// <exception cref="System.ArgumentException">Thrown if an invalid block size or invalid rounds count are used</exception>
        /// <exception cref="System.ArgumentOutOfRangeException">Thrown if the HKDF Ikm is an invalid size.</exception>
        public N64(int Rounds = DEFAULT_ROUNDS, int BlockSize = BLOCK16, Digests KeyEngine = Digests.SHA512)
        {
            if (BlockSize != BLOCK16 && BlockSize != BLOCK32)
                throw new ArgumentException("Invalid block size! Supported block sizes are 16 and 32 bytes.");
            if (Rounds < MIN_ROUNDS || Rounds > MAX_ROUNDS || Rounds % 2 > 0)
                throw new ArgumentException("Invalid rounds size! Sizes supported are even numbers between 10 and 38.");

            // get the hkdf digest engine
            _keyEngine = GetKeyEngine(KeyEngine);
            // set the hmac key size
            _ikmSize = _ikmSize == 0 ? _keyEngine.DigestSize : _ikmSize;

            for (int i = 0; i < _legalKeySizes.Length; i++)
                _legalKeySizes[i] = (_keyEngine.BlockSize * (i + 1)) + _ikmSize;

            _dfnRounds = Rounds;
            _blockSize = BlockSize;
        }

        /// <summary>
        /// Finalize objects
        /// </summary>
        ~N64()
        {
            Dispose(false);
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Initialize the Cipher.
        /// </summary>
        /// 
        /// <param name="Encryption">Using Encryption or Decryption mode</param>
        /// <param name="KeyParam">Cipher key container. <para>The <see cref="LegalKeySizes"/> property contains valid sizes.</para></param>
        /// 
        /// <exception cref="System.ArgumentNullException">Thrown if a null key is used</exception>
        /// <exception cref="System.ArgumentOutOfRangeException">Thrown if an invalid key size is used</exception>
        public void Initialize(bool Encryption, KeyParams KeyParam)
        {
            if (KeyParam.Key == null)
                throw new ArgumentNullException("Invalid key! Key can not be null.");
            if (KeyParam.Key.Length < LegalKeySizes[0])
                throw new ArgumentOutOfRangeException(String.Format("Invalid key size! Key must be at least {0}  bytes ({1} bit).", LegalKeySizes[0], LegalKeySizes[0] * 8));
            if ((KeyParam.Key.Length - _keyEngine.DigestSize) % _keyEngine.BlockSize != 0)
                throw new ArgumentOutOfRangeException(String.Format("Invalid key size! Key must be (length - IKm length: {0} bytes) + multiple of {1} block size.", _keyEngine.DigestSize, _keyEngine.BlockSize));

            _isEncryption = Encryption;
            // expand the key
            _expKey = ExpandKey(KeyParam.Key, Encryption);
            // ready to transform data
            _isInitialized = true;
        }

        /// <summary>
        /// Transform a block of bytes.
        /// <para><see cref="Initialize(bool, KeyParams)"/> must be called before this method can be used.
        /// Input and Output array lengths must be at least <see cref="BlockSize"/> in length.</para>
        /// </summary>
        /// 
        /// <param name="Input">Bytes to Encrypt or Decrypt</param>
        /// <param name="Output">Encrypted or Decrypted bytes</param>
        public void Transform(byte[] Input, byte[] Output)
        {
            Encrypt64(Input, 0, Output, 0);
        }

        /// <summary>
        /// Transform a block of bytes with offset parameters.
        /// <para><see cref="Initialize(bool, KeyParams)"/> must be called before this method can be used.
        /// Input and Output arrays with Offsets must be at least <see cref="BlockSize"/> in length.</para>
        /// </summary>
        /// 
        /// <param name="Input">Bytes to Encrypt</param>
        /// <param name="InOffset">Offset in the Input array</param>
        /// <param name="Output">Encrypted bytes</param>
        /// <param name="OutOffset">Offset in the Output array</param>
        public void Transform(byte[] Input, int InOffset, byte[] Output, int OutOffset)
        {
            Encrypt64(Input, InOffset, Output, OutOffset);
        }
        #endregion

        #region Key Schedule
        /// <remarks>
        /// Expand the key and initialize state variables
        /// </remarks>
        private UInt64[] ExpandKey(byte[] Key, bool Encryption)
        {
            // block and key in 64 bit words
            _wrdBlocks = _blockSize / 8;

            // expanded key size
            int keySize = _wrdBlocks * (_dfnRounds + 1);

            // hkdf return array
            int keyBytes = keySize * 8;
            byte[] rawKey = new byte[keyBytes];
            int saltSize = Key.Length - _ikmSize;

            // salt must be divisible of hash blocksize
            if (saltSize % _keyEngine.BlockSize != 0)
                saltSize = saltSize - saltSize % _keyEngine.BlockSize;

            // hkdf input
            byte[] hkdfKey = new byte[_ikmSize];
            byte[] hkdfSalt = new byte[saltSize];

            // copy hkdf key and salt from user key
            Buffer.BlockCopy(Key, 0, hkdfKey, 0, _ikmSize);
            Buffer.BlockCopy(Key, _ikmSize, hkdfSalt, 0, saltSize);

            // HKDF generator expands array
            using (HKDF gen = new HKDF(_keyEngine, false))
            {
                gen.Initialize(hkdfSalt, hkdfKey, _hkdfInfo);
                gen.Generate(rawKey);
            }

            // initialize working key
            UInt64[] wK = new UInt64[keySize];
            // copy bytes to working key
            Buffer.BlockCopy(rawKey, 0, wK, 0, keyBytes);

            // return the expanded key
            return wK;
        }

        private IDigest GetKeyEngine(Digests KeyEngine)
        {
            switch (KeyEngine)
            {
                case Digests.Blake256:
                    return new Blake256();
                case Digests.Blake512:
                    return new Blake512();
                case Digests.Keccak256:
                    return new Keccak256();
                case Digests.Keccak512:
                    return new Keccak512();
                case Digests.SHA256:
                    return new SHA256();
                case Digests.Skein256:
                    return new Skein256();
                case Digests.Skein512:
                    return new Skein512();
                case Digests.Skein1024:
                    return new Skein1024();
                default:
                    return new SHA512();
            }
        }
        #endregion

        #region Rounds Processing
        private UInt64[] T0 = new UInt64[256];
        private UInt64[] T1 = new UInt64[256];
        private UInt64[] T2 = new UInt64[256];
        private UInt64[] T3 = new UInt64[256];
        private UInt64[] T4 = new UInt64[256];
        private UInt64[] T5 = new UInt64[256];
        private UInt64[] T6 = new UInt64[256];
        private UInt64[] T7 = new UInt64[256];

        private void Encrypt64(byte[] Input, int InOffset, byte[] Output, int OutOffset)
        {
            int keyCtr = 0;

            // round 0: whitening
            UInt64 X0 = BytesToInt64(Input, Input[InOffset += 8]) ^ _expKey[keyCtr++];
            UInt64 X1 = BytesToInt64(Input, Input[InOffset += 8]) ^ _expKey[keyCtr++];
            UInt64 X2 = BytesToInt64(Input, Input[InOffset += 8]) ^ _expKey[keyCtr++];
            UInt64 X3 = BytesToInt64(Input, Input[InOffset += 8]) ^ _expKey[keyCtr++];
            UInt64 X4 = BytesToInt64(Input, Input[InOffset += 8]) ^ _expKey[keyCtr++];
            UInt64 X5 = BytesToInt64(Input, Input[InOffset += 8]) ^ _expKey[keyCtr++];
            UInt64 X6 = BytesToInt64(Input, Input[InOffset += 8]) ^ _expKey[keyCtr++];
            UInt64 X7 = BytesToInt64(Input, Input[InOffset += 8]) ^ _expKey[keyCtr++];

            // round 1
            UInt64 Y0 = T0[X0 >> 56] ^ T1[(byte)(X1 >> 48)] ^ T2[(byte)(X3 >> 40)] ^ T3[(byte)X4 >> 32] ^ T4[X5 >> 24] ^ T5[(byte)(X6 >> 16)] ^ T6[(byte)(X7 >> 8)] ^ T7[(byte)X2] ^ _expKey[keyCtr++];
            UInt64 Y1 = T0[X1 >> 56] ^ T1[(byte)(X2 >> 48)] ^ T2[(byte)(X4 >> 40)] ^ T3[(byte)X5 >> 32] ^ T4[X6 >> 24] ^ T5[(byte)(X7 >> 16)] ^ T6[(byte)(X0 >> 8)] ^ T7[(byte)X3] ^ _expKey[keyCtr++];
            UInt64 Y2 = T0[X2 >> 56] ^ T1[(byte)(X3 >> 48)] ^ T2[(byte)(X5 >> 40)] ^ T3[(byte)X6 >> 32] ^ T4[X7 >> 24] ^ T5[(byte)(X0 >> 16)] ^ T6[(byte)(X1 >> 8)] ^ T7[(byte)X4] ^ _expKey[keyCtr++];
            UInt64 Y3 = T0[X3 >> 56] ^ T1[(byte)(X4 >> 48)] ^ T2[(byte)(X6 >> 40)] ^ T3[(byte)X7 >> 32] ^ T4[X0 >> 24] ^ T5[(byte)(X1 >> 16)] ^ T6[(byte)(X2 >> 8)] ^ T7[(byte)X5] ^ _expKey[keyCtr++];
            UInt64 Y4 = T0[X4 >> 56] ^ T1[(byte)(X5 >> 48)] ^ T2[(byte)(X7 >> 40)] ^ T3[(byte)X0 >> 32] ^ T4[X1 >> 24] ^ T5[(byte)(X2 >> 16)] ^ T6[(byte)(X3 >> 8)] ^ T7[(byte)X6] ^ _expKey[keyCtr++];
            UInt64 Y5 = T0[X5 >> 56] ^ T1[(byte)(X6 >> 48)] ^ T2[(byte)(X0 >> 40)] ^ T3[(byte)X1 >> 32] ^ T4[X2 >> 24] ^ T5[(byte)(X3 >> 16)] ^ T6[(byte)(X4 >> 8)] ^ T7[(byte)X7] ^ _expKey[keyCtr++];
            UInt64 Y6 = T0[X6 >> 56] ^ T1[(byte)(X7 >> 48)] ^ T2[(byte)(X1 >> 40)] ^ T3[(byte)X2 >> 32] ^ T4[X3 >> 24] ^ T5[(byte)(X3 >> 16)] ^ T6[(byte)(X5 >> 8)] ^ T7[(byte)X0] ^ _expKey[keyCtr++];
            UInt64 Y7 = T0[X7 >> 56] ^ T1[(byte)(X0 >> 48)] ^ T2[(byte)(X2 >> 40)] ^ T3[(byte)X3 >> 32] ^ T4[X4 >> 24] ^ T5[(byte)(X4 >> 16)] ^ T6[(byte)(X6 >> 8)] ^ T7[(byte)X1] ^ _expKey[keyCtr++];

            // rounds loop
            while (keyCtr < _expKey.Length - 8)
            {
                X0 = T0[Y0 >> 56] ^ T1[(byte)(Y1 >> 48)] ^ T2[(byte)(Y3 >> 40)] ^ T3[(byte)Y4 >> 32] ^ T4[Y5 >> 24] ^ T5[(byte)(Y6 >> 16)] ^ T6[(byte)(Y7 >> 8)] ^ T7[(byte)Y2] ^ _expKey[keyCtr++];
                X1 = T0[Y1 >> 56] ^ T1[(byte)(Y2 >> 48)] ^ T2[(byte)(Y4 >> 40)] ^ T3[(byte)Y5 >> 32] ^ T4[Y6 >> 24] ^ T5[(byte)(Y7 >> 16)] ^ T6[(byte)(Y0 >> 8)] ^ T7[(byte)Y3] ^ _expKey[keyCtr++];
                X2 = T0[Y2 >> 56] ^ T1[(byte)(Y3 >> 48)] ^ T2[(byte)(Y5 >> 40)] ^ T3[(byte)Y6 >> 32] ^ T4[Y7 >> 24] ^ T5[(byte)(Y0 >> 16)] ^ T6[(byte)(Y1 >> 8)] ^ T7[(byte)Y4] ^ _expKey[keyCtr++];
                X3 = T0[Y3 >> 56] ^ T1[(byte)(Y4 >> 48)] ^ T2[(byte)(Y6 >> 40)] ^ T3[(byte)Y7 >> 32] ^ T4[Y0 >> 24] ^ T5[(byte)(Y1 >> 16)] ^ T6[(byte)(Y2 >> 8)] ^ T7[(byte)Y5] ^ _expKey[keyCtr++];
                X4 = T0[Y4 >> 56] ^ T1[(byte)(Y5 >> 48)] ^ T2[(byte)(Y7 >> 40)] ^ T3[(byte)Y0 >> 32] ^ T4[Y1 >> 24] ^ T5[(byte)(Y2 >> 16)] ^ T6[(byte)(Y3 >> 8)] ^ T7[(byte)Y6] ^ _expKey[keyCtr++];
                X5 = T0[Y5 >> 56] ^ T1[(byte)(Y6 >> 48)] ^ T2[(byte)(Y0 >> 40)] ^ T3[(byte)Y1 >> 32] ^ T4[Y2 >> 24] ^ T5[(byte)(Y3 >> 16)] ^ T6[(byte)(Y4 >> 8)] ^ T7[(byte)Y7] ^ _expKey[keyCtr++];
                X6 = T0[Y6 >> 56] ^ T1[(byte)(Y7 >> 48)] ^ T2[(byte)(Y1 >> 40)] ^ T3[(byte)Y2 >> 32] ^ T4[Y3 >> 24] ^ T5[(byte)(Y4 >> 16)] ^ T6[(byte)(Y5 >> 8)] ^ T7[(byte)Y0] ^ _expKey[keyCtr++];
                X7 = T0[Y7 >> 56] ^ T1[(byte)(Y0 >> 48)] ^ T2[(byte)(Y2 >> 40)] ^ T3[(byte)Y3 >> 32] ^ T4[Y4 >> 24] ^ T5[(byte)(Y5 >> 16)] ^ T6[(byte)(Y6 >> 8)] ^ T7[(byte)Y1] ^ _expKey[keyCtr++];

                Y0 = T0[X0 >> 56] ^ T1[(byte)(X1 >> 48)] ^ T2[(byte)(X3 >> 40)] ^ T3[(byte)X4 >> 32] ^ T4[X0 >> 24] ^ T5[(byte)(X6 >> 16)] ^ T6[(byte)(X3 >> 8)] ^ T7[(byte)X2] ^ _expKey[keyCtr++];
                Y1 = T0[X1 >> 56] ^ T1[(byte)(X2 >> 48)] ^ T2[(byte)(X4 >> 40)] ^ T3[(byte)X5 >> 32] ^ T4[X1 >> 24] ^ T5[(byte)(X7 >> 16)] ^ T6[(byte)(X4 >> 8)] ^ T7[(byte)X3] ^ _expKey[keyCtr++];
                Y2 = T0[X2 >> 56] ^ T1[(byte)(X3 >> 48)] ^ T2[(byte)(X5 >> 40)] ^ T3[(byte)X6 >> 32] ^ T4[X2 >> 24] ^ T5[(byte)(X0 >> 16)] ^ T6[(byte)(X5 >> 8)] ^ T7[(byte)X4] ^ _expKey[keyCtr++];
                Y3 = T0[X3 >> 56] ^ T1[(byte)(X4 >> 48)] ^ T2[(byte)(X6 >> 40)] ^ T3[(byte)X7 >> 32] ^ T4[X3 >> 24] ^ T5[(byte)(X1 >> 16)] ^ T6[(byte)(X6 >> 8)] ^ T7[(byte)X5] ^ _expKey[keyCtr++];
                Y4 = T0[X4 >> 56] ^ T1[(byte)(X5 >> 48)] ^ T2[(byte)(X7 >> 40)] ^ T3[(byte)X0 >> 32] ^ T4[X4 >> 24] ^ T5[(byte)(X2 >> 16)] ^ T6[(byte)(X7 >> 8)] ^ T7[(byte)X6] ^ _expKey[keyCtr++];
                Y5 = T0[X5 >> 56] ^ T1[(byte)(X6 >> 48)] ^ T2[(byte)(X0 >> 40)] ^ T3[(byte)X1 >> 32] ^ T4[X5 >> 24] ^ T5[(byte)(X3 >> 16)] ^ T6[(byte)(X0 >> 8)] ^ T7[(byte)X7] ^ _expKey[keyCtr++];
                Y6 = T0[X6 >> 56] ^ T1[(byte)(X7 >> 48)] ^ T2[(byte)(X1 >> 40)] ^ T3[(byte)X2 >> 32] ^ T4[X6 >> 24] ^ T5[(byte)(X4 >> 16)] ^ T6[(byte)(X1 >> 8)] ^ T7[(byte)X0] ^ _expKey[keyCtr++];
                Y7 = T0[X7 >> 56] ^ T1[(byte)(X0 >> 48)] ^ T2[(byte)(X2 >> 40)] ^ T3[(byte)X3 >> 32] ^ T4[X7 >> 24] ^ T5[(byte)(X5 >> 16)] ^ T6[(byte)(X2 >> 8)] ^ T7[(byte)X1] ^ _expKey[keyCtr++];
            }

            // final round: whitening and mixing
            Output[OutOffset++] = (byte)(SBox[(byte)(Y0 >> 56)] ^ (byte)(_expKey[keyCtr] >> 56));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y1 >> 48)] ^ (byte)(_expKey[keyCtr] >> 48));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y2 >> 40)] ^ (byte)(_expKey[keyCtr] >> 40));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y3 >> 32)] ^ (byte)(_expKey[keyCtr] >> 32));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y4 >> 24)] ^ (byte)(_expKey[keyCtr] >> 24));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y5 >> 16)] ^ (byte)(_expKey[keyCtr] >> 16));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y6 >> 8)] ^ (byte)(_expKey[keyCtr] >> 8));
            Output[OutOffset++] = (byte)(SBox[(byte)Y7] ^ (byte)_expKey[keyCtr++]);

            Output[OutOffset++] = (byte)(SBox[(byte)(Y1 >> 56)] ^ (byte)(_expKey[keyCtr] >> 56));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y2 >> 48)] ^ (byte)(_expKey[keyCtr] >> 48));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y4 >> 40)] ^ (byte)(_expKey[keyCtr] >> 40));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y5 >> 32)] ^ (byte)(_expKey[keyCtr] >> 32));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y6 >> 24)] ^ (byte)(_expKey[keyCtr] >> 24));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y7 >> 16)] ^ (byte)(_expKey[keyCtr] >> 16));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y1 >> 8)] ^ (byte)(_expKey[keyCtr] >> 8));
            Output[OutOffset++] = (byte)(SBox[(byte)Y0] ^ (byte)_expKey[keyCtr++]);

            Output[OutOffset++] = (byte)(SBox[(byte)(Y2 >> 56)] ^ (byte)(_expKey[keyCtr] >> 56));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y3 >> 48)] ^ (byte)(_expKey[keyCtr] >> 48));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y5 >> 40)] ^ (byte)(_expKey[keyCtr] >> 40));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y6 >> 32)] ^ (byte)(_expKey[keyCtr] >> 32));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y2 >> 24)] ^ (byte)(_expKey[keyCtr] >> 24));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y3 >> 16)] ^ (byte)(_expKey[keyCtr] >> 16));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y5 >> 8)] ^ (byte)(_expKey[keyCtr] >> 8));
            Output[OutOffset++] = (byte)(SBox[(byte)Y6] ^ (byte)_expKey[keyCtr++]);

            Output[OutOffset++] = (byte)(SBox[(byte)(Y3 >> 56)] ^ (byte)(_expKey[keyCtr] >> 56));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y4 >> 48)] ^ (byte)(_expKey[keyCtr] >> 48));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y6 >> 40)] ^ (byte)(_expKey[keyCtr] >> 40));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y7 >> 32)] ^ (byte)(_expKey[keyCtr] >> 32));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y3 >> 24)] ^ (byte)(_expKey[keyCtr] >> 24));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y4 >> 16)] ^ (byte)(_expKey[keyCtr] >> 16));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y6 >> 8)] ^ (byte)(_expKey[keyCtr] >> 8));
            Output[OutOffset++] = (byte)(SBox[(byte)Y7] ^ (byte)_expKey[keyCtr++]);

            Output[OutOffset++] = (byte)(SBox[(byte)(Y4 >> 56)] ^ (byte)(_expKey[keyCtr] >> 56));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y5 >> 48)] ^ (byte)(_expKey[keyCtr] >> 48));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y7 >> 40)] ^ (byte)(_expKey[keyCtr] >> 40));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y0 >> 32)] ^ (byte)(_expKey[keyCtr] >> 32));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y4 >> 24)] ^ (byte)(_expKey[keyCtr] >> 24));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y5 >> 16)] ^ (byte)(_expKey[keyCtr] >> 16));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y7 >> 8)] ^ (byte)(_expKey[keyCtr] >> 8));
            Output[OutOffset++] = (byte)(SBox[(byte)Y0] ^ (byte)_expKey[keyCtr++]);

            Output[OutOffset++] = (byte)(SBox[(byte)(Y5 >> 56)] ^ (byte)(_expKey[keyCtr] >> 56));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y6 >> 48)] ^ (byte)(_expKey[keyCtr] >> 48));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y0 >> 40)] ^ (byte)(_expKey[keyCtr] >> 40));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y1 >> 32)] ^ (byte)(_expKey[keyCtr] >> 32));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y5 >> 24)] ^ (byte)(_expKey[keyCtr] >> 24));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y6 >> 16)] ^ (byte)(_expKey[keyCtr] >> 16));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y0 >> 8)] ^ (byte)(_expKey[keyCtr] >> 8));
            Output[OutOffset++] = (byte)(SBox[(byte)Y1] ^ (byte)_expKey[keyCtr++]);

            Output[OutOffset++] = (byte)(SBox[(byte)(Y6 >> 56)] ^ (byte)(_expKey[keyCtr] >> 56));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y7 >> 48)] ^ (byte)(_expKey[keyCtr] >> 48));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y1 >> 40)] ^ (byte)(_expKey[keyCtr] >> 40));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y2 >> 32)] ^ (byte)(_expKey[keyCtr] >> 32));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y6 >> 24)] ^ (byte)(_expKey[keyCtr] >> 24));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y7 >> 16)] ^ (byte)(_expKey[keyCtr] >> 16));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y1 >> 8)] ^ (byte)(_expKey[keyCtr] >> 8));
            Output[OutOffset++] = (byte)(SBox[(byte)Y2] ^ (byte)_expKey[keyCtr++]);

            Output[OutOffset++] = (byte)(SBox[(byte)(Y7 >> 56)] ^ (byte)(_expKey[keyCtr] >> 56));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y0 >> 48)] ^ (byte)(_expKey[keyCtr] >> 48));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y2 >> 40)] ^ (byte)(_expKey[keyCtr] >> 40));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y3 >> 32)] ^ (byte)(_expKey[keyCtr] >> 32));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y7 >> 24)] ^ (byte)(_expKey[keyCtr] >> 24));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y0 >> 16)] ^ (byte)(_expKey[keyCtr] >> 16));
            Output[OutOffset++] = (byte)(SBox[(byte)(Y2 >> 8)] ^ (byte)(_expKey[keyCtr] >> 8));
            Output[OutOffset] = (byte)(SBox[(byte)Y3] ^ (byte)_expKey[keyCtr]);
        }
        #endregion

        #region Helpers
        private static UInt64 BytesToInt64(byte[] Input, Int32 InOffset)
        {
            return (((UInt64)Input[InOffset] << 56) |
                ((UInt64)Input[InOffset + 1] << 48) |
                ((UInt64)Input[InOffset + 2] << 40) |
                ((UInt64)Input[InOffset + 3] << 32) |
                ((UInt64)Input[InOffset + 4] << 24) |
                ((UInt64)Input[InOffset + 5] << 16) |
                ((UInt64)Input[InOffset + 6] << 8) |
                ((UInt64)Input[InOffset + 7]));
        }

        private static void Int64ToBytes(UInt64 Dword, byte[] Output, Int32 OutOffset)
        {
            Output[OutOffset + 7] = (byte)(Dword);
            Output[OutOffset + 6] = (byte)(Dword >> 8);
            Output[OutOffset + 5] = (byte)(Dword >> 16);
            Output[OutOffset + 4] = (byte)(Dword >> 24);
            Output[OutOffset + 3] = (byte)(Dword >> 32);
            Output[OutOffset + 2] = (byte)(Dword >> 40);
            Output[OutOffset + 1] = (byte)(Dword >> 48);
            Output[OutOffset] = (byte)(Dword >> 56);
        }

        private UInt32 SubByte(UInt32 Rot)
        {
            UInt32 value = 0xff & Rot;
            UInt32 result = SBox[value];
            value = 0xff & (Rot >> 8);
            result |= (UInt32)SBox[value] << 8;
            value = 0xff & (Rot >> 16);
            result |= (UInt32)SBox[value] << 16;
            value = 0xff & (Rot >> 24);
            return result | (UInt32)(SBox[value] << 24);
        }
        #endregion

        #region Constant Tables
        private static readonly byte[] SBox = new byte[] {
			0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
			0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
			0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
			0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
			0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
			0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
			0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
			0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
			0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
			0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
			0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
			0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
			0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
			0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
			0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
			0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16
		};
        #endregion

        #region IDispose
        /// <summary>
        /// Dispose of this class
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool Disposing)
        {
            if (!_isDisposed && Disposing)
            {
                try
                {
                    if (_keyEngine != null)
                    {
                        _keyEngine.Dispose();
                        _keyEngine = null;
                    }
                    if (_expKey != null)
                    {
                        Array.Clear(_expKey, 0, _expKey.Length);
                        _expKey = null;
                    }
                    if (_hkdfInfo != null)
                    {
                        Array.Clear(_hkdfInfo, 0, _hkdfInfo.Length);
                        _hkdfInfo = null;
                    }
                }
                finally
                {
                    _isDisposed = true;
                }
            }
        }
        #endregion
    }
}
