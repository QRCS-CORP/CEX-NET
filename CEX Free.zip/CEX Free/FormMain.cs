﻿using System;
using System.ComponentModel;
using System.IO;
using System.Windows.Forms;
using VTDev.Projects.CEX.Cryptographic.Digests;
using VTDev.Projects.CEX.Cryptographic.Helpers;
using VTDev.Projects.CEX.Cryptographic.Macs;

/// Permission is hereby granted, free of charge, to any person obtaining
/// a copy of this software and associated documentation files (the
/// "Software"), to deal in the Software without restriction, including
/// without limitation the rights to use, copy, modify, merge, publish,
/// distribute, sublicense, and/or sell copies of the Software, and to
/// permit persons to whom the Software is furnished to do so, subject to
/// the following conditions:
/// 
/// The above copyright notice and this permission notice shall be
/// included in all copies or substantial portions of the Software.
/// 
/// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
/// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
/// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
/// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
/// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
/// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
/// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
///
/// 
/// Dual CTR Stream (DCS)
/// Valid Key size is 768 bit (96 bytes).
/// 
/// Rijndael Extended (RDX)
/// Valid Key sizes are 128, 192, 256, and 512 bit.
/// Valid block sizes are 16 and 32 byte wide.
/// 
/// Rijndael/Serpent Extended (RSX)
/// Valid Key sizes are 256, and 512 bit.
/// Valid block sizes are 16 and 32 byte wide.
/// 
/// Written by John Underhill, September, 2014
/// contact: steppenwolfe_2000@yahoo.com

namespace VTDev.Projects.CEX
{
    public partial class FormMain : Form
    {
        #region Constants
        private const string ALL_FILT = "All Files | *.*";
        private const string CENC_EXT = ".cen";
        private const string CKEY_EXT = ".ckey";
        private const string KEY_DEF = "Key";
        private const string FILE_DEFN = "[Select a File to Encrypt or Decrypt]";
        private const string FILE_DESC = "Select a File to Encrypt or Decrypt";
        private const string FOLD_DEFN = "[Save Key File As]";
        private const string FOLD_DESC = "Choose a Key Name and Path";
        private const string KPTH_DEFN = "[Save Key File As]";
        private const string KPTH_DESC = "Save Key File As";
        private const string KEY_DEFN = "[Select a Key File]";
        private const string KEY_DESC = "Select a Key File";
        private const string KEY_FILT = "Key File | *.ckey";
        private const string KEY_NAME = "Key";
        private const string SAVE_DEFN = "[Save File to Destination]";
        private const string SAVE_DESC = "Save File As";
        #endregion

        #region Fields
        private BackgroundWorker _transformWorker = new BackgroundWorker();
        #endregion

        #region Properties
        private Engines Engine { get; set; }
        private BlockSizes BlockSize { get; set; }
        private CipherModes CipherMode { get; set; }
        private PaddingModes PaddingMode { get; set; }
        private string InputPath { get; set; }
        private bool IsEncryption { get; set; }
        private string KeyFilePath { get; set; }
        private KeySizes KeySize { get; set; }
        private string LastInputPath { get; set; }
        private string LastOutputPath { get; set; }
        private string LastKeyPath { get; set; }
        private string OutputPath { get; set; }
        #endregion

        #region Constructor
        public FormMain()
        {
            InitializeComponent();
        }
        #endregion

        #region Cryptographic
        private byte[] CreateKey()
        {
            if (this.Engine == Engines.DCS)
                return KeyGenerator.GetSeed96();

            if (KeySize == KeySizes.K128)
                return KeyGenerator.GenerateKey(KeySizes.K128);
            else if (KeySize == KeySizes.K192)
                return KeyGenerator.GenerateKey(KeySizes.K192);
            else if (KeySize == KeySizes.K512)
                return KeyGenerator.GenerateKey(KeySizes.K512);
            else
                return KeyGenerator.GenerateKey(KeySizes.K256);
        }

        private byte[] CreateIV()
        {
            if (this.BlockSize == BlockSizes.B16)
                return KeyGenerator.GenerateIV(IVSizes.V128);
            else
                return KeyGenerator.GenerateIV(IVSizes.V256);
        }

        private void Decrypt()
        {
            Transform dec = new Transform(this.KeyFilePath);

            dec.ProgressCounter -= OnProgressCounter;
            dec.ProgressCounter += new Transform.ProgressCounterDelegate(OnProgressCounter);

            try
            {
                string extension = GetMessageExtension(this.InputPath, this.KeyFilePath);
                this.OutputPath = Utilities.GetUniquePath(this.OutputPath + extension);

                dec.Decrypt(this.InputPath, this.OutputPath);

                if (!dec.Verify(this.InputPath, this.OutputPath, this.KeyFilePath))
                    MessageBox.Show("Message hash does not match! The file has been tampered with.");
            }
            catch (Exception ex)
            {
                if (File.Exists(this.OutputPath))
                    File.Delete(this.OutputPath);

                string message = ex.Message == null ? "" : ex.Message;
                MessageBox.Show("An error occured, the file could not be decrypted! " + message);
            }
        }

        private void Encrypt()
        {
            Transform enc = new Transform(this.KeyFilePath);

            enc.ProgressCounter -= OnProgressCounter;
            enc.ProgressCounter += new Transform.ProgressCounterDelegate(OnProgressCounter);

            try
            {
                enc.Encrypt(this.InputPath, this.OutputPath);
            }
            catch (Exception ex)
            {
                if (File.Exists(this.OutputPath))
                    File.Delete(this.OutputPath);

                string message = ex.Message == null ? "" : ex.Message;
                MessageBox.Show("An error occured, the file could not be encrypted! " + message);
            }
        }

        private string GetMessageExtension(string MessagePath, string KeyPath)
        {
            if (IsValidMessage(MessagePath))
            {
                return MessageHeader.GetExtension(MessagePath, KeyHeader.GetExtRandom(KeyPath));
            }
            return "";
        }

        private bool IsValidMessage(string MessagePath)
        {
            return MessageHeader.HasHeader(MessagePath);
        }
        #endregion

        #region Helpers
        private void EnabledState(bool State)
        {
            grpKey.Enabled = State;
            grpOutput.Enabled = State;
        }

        private long FileGetSize(string FilePath)
        {
            try
            {
                return File.Exists(FilePath) ? new FileInfo(FilePath).Length : 0;
            }
            catch { }
            return -1;
        }

        private int GetBlockSize()
        {
            if (this.BlockSize == BlockSizes.B16)
                return 16;
            else
                return 32;
        }

        private string GetFileOpenPath(string Description, string Filter = ALL_FILT, string DefaultDirectory = "")
        {
            using (OpenFileDialog openDialog = new OpenFileDialog())
            {
                openDialog.AutoUpgradeEnabled = false;
                openDialog.CheckFileExists = true;
                openDialog.Filter = Filter;
                if (!string.IsNullOrEmpty(DefaultDirectory))
                    openDialog.InitialDirectory = DefaultDirectory;
                openDialog.RestoreDirectory = true;
                openDialog.Title = Description;

                if (openDialog.ShowDialog() == DialogResult.OK)
                    return openDialog.FileName;
            }

            return string.Empty;
        }

        private string GetFileSavePath(string Description, string Filter = ALL_FILT, string FileName = "", string DefaultDirectory = "")
        {
            using (SaveFileDialog saveDialog = new SaveFileDialog())
            {
                saveDialog.AddExtension = true;
                saveDialog.AutoUpgradeEnabled = false;
                saveDialog.CheckPathExists = true;
                saveDialog.Filter = Filter;
                saveDialog.FileName = FileName;
                if (!string.IsNullOrEmpty(DefaultDirectory))
                    saveDialog.InitialDirectory = DefaultDirectory;
                saveDialog.OverwritePrompt = true;
                saveDialog.Title = Description;
                saveDialog.RestoreDirectory = true;

                if (saveDialog.ShowDialog() == DialogResult.OK)
                    return saveDialog.FileName;
            }

            return string.Empty;
        }

        private bool IsMatchingKey(string MessagePath, string KeyPath)
        {
            if (File.Exists(MessagePath) && File.Exists(KeyPath))
            {
                Guid messageId = MessageHeader.GetMessageId(MessagePath);
                Guid keyId = KeyHeader.GetKeyId(KeyPath);
                return messageId.Equals(keyId);
            }

            return false;
        }

        private void Reset()
        {
            txtKeyFolder.Text = FOLD_DEFN;
            txtInputFile.Text = FILE_DEFN;
            txtKeyFile.Text = KEY_DEFN;
            txtOutputFile.Text = SAVE_DEFN;
            this.InputPath = string.Empty;
            this.KeyFilePath = string.Empty;
            this.OutputPath = string.Empty;
            lblStatus.Text = "Waiting..";
            pbStatus.Value = 0;
            btnCreateKey.Enabled = false;
            btnEncrypt.Enabled = false;
            btnKeyFile.Enabled = false;
            btnOutputFile.Enabled = false;
        }

        private void SaveKey()
        {
            try
            {
                // seperate iv and block sizes for buffered feedback modes
                IVSizes ivSize = this.BlockSize == BlockSizes.B16 ? IVSizes.V128 : IVSizes.V256;
                // create and populate key header
                KeyHeaderStruct keyHeader = new KeyHeaderStruct(this.Engine, this.KeySize, ivSize, this.CipherMode, this.PaddingMode, this.BlockSize);
                MemoryStream keyStream = (MemoryStream)KeyHeader.SerializeHeader(keyHeader);

                using (BinaryWriter outputWriter = new BinaryWriter(new FileStream(this.KeyFilePath, FileMode.Create, FileAccess.Write, FileShare.None)))
                {
                    // write key header
                    outputWriter.Write(keyStream.ToArray());
                    // write the key
                    outputWriter.Write(CreateKey());
                    // write the iv
                    if (this.Engine != Engines.DCS && this.CipherMode != CipherModes.None)
                        outputWriter.Write(CreateIV());
                }

                if (!string.IsNullOrEmpty(this.KeyFilePath))
                    this.LastKeyPath = Path.GetDirectoryName(this.KeyFilePath);

                Reset();
                lblStatus.Text = "The Key has been saved!";
            }
            catch(Exception ex)
            {
                if (File.Exists(this.KeyFilePath))
                    File.Delete(this.KeyFilePath);

                string message = ex.Message == null ? "" : ex.Message;
                MessageBox.Show("An error occured, the key could not be created! " + message);
            }
        }
        #endregion

        #region Event Handlers
        private void OnAlgorithmChanged(object sender, EventArgs e)
        {
            ComboBox cb = sender as ComboBox;

            if (cb.Text.Equals("RDX"))
            {
                this.Engine = Engines.RDX;
                cbKeySize.Items.Clear();
                cbKeySize.Items.Add("K128");
                cbKeySize.Items.Add("K256");
                cbKeySize.Items.Add("K512");
                cbKeySize.SelectedIndex = 1;
            }
            else if (cb.Text.Equals("RSX"))
            {
                this.Engine = Engines.RSX;
                cbKeySize.Items.Clear();
                cbKeySize.Items.Add("K256");
                cbKeySize.Items.Add("K512");
                cbKeySize.SelectedIndex = 0;
            }
            else
            {
                this.Engine = Engines.DCS;
            }

            bool state = this.Engine != Engines.DCS;

            cbCipherMode.Enabled = state;
            cbKeySize.Enabled = state;
            cbVectorSize.Enabled = state;
            cbPaddingMode.Enabled = state;
        }

        private void OnCipherModeChanged(object sender, EventArgs e)
        {
            ComboBox cb = sender as ComboBox;

            if (cb.Text == "CBC")
                this.CipherMode = CipherModes.CBC;
            else if (cb.Text == "CTR")
                this.CipherMode = CipherModes.CTR;
            else if (cb.Text == "PSC")
                this.CipherMode = CipherModes.PSC;
            else
                this.CipherMode = CipherModes.None;
        }

        private void OnFormClose(object sender, FormClosingEventArgs e)
        {
            _transformWorker.Dispose();
            SaveSettings();
        }

        private void OnFormLoad(object sender, EventArgs e)
        {
            Reset();
            LoadSettings();

            _transformWorker.DoWork += OnTransformDoWork;
            _transformWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(TransformWorkerCompleted);
        }

        private void OnInputFileClick(object sender, EventArgs e)
        {
            Reset();

            string inputFile = GetFileOpenPath(FILE_DESC, ALL_FILT, this.LastInputPath);

            if (!string.IsNullOrEmpty(inputFile) && File.Exists(inputFile))
            {
                this.InputPath = inputFile;
                txtInputFile.Text = this.InputPath;
                btnOutputFile.Enabled = true;

                if (!string.IsNullOrEmpty(this.InputPath))
                    this.LastInputPath = Path.GetDirectoryName(this.InputPath);

                if (this.InputPath.Contains(CENC_EXT))
                {
                    btnEncrypt.Text = "Decrypt";
                    this.IsEncryption = false;
                }
                else
                {
                    btnEncrypt.Text = "Encrypt";
                    this.IsEncryption = true;
                }

                string folderPath = Path.GetDirectoryName(inputFile);

                if (Utilities.DirectoryIsWritable(folderPath))
                {
                    if (this.IsEncryption)
                    {
                        string extension = Path.GetExtension(inputFile);
                        string fileName = Path.GetFileNameWithoutExtension(inputFile);
                        this.OutputPath = Utilities.GetUniquePath(folderPath, fileName, CENC_EXT);
                    }
                    else
                    {
                        this.OutputPath = Path.Combine(Path.GetDirectoryName(inputFile), Path.GetFileNameWithoutExtension(inputFile));
                    }

                    txtOutputFile.Text = this.OutputPath;
                    btnKeyFile.Enabled = true;
                }
            }
            else
            {
                btnOutputFile.Enabled = false;
                btnKeyFile.Enabled = false;
                btnCreateKey.Enabled = false;
            }
        }

        private void OnKeyCreateClick(object sender, EventArgs e)
        {
            SaveKey();
        }

        private void OnKeyPathClick(object sender, EventArgs e)
        {
            Reset();

            string filePath = GetFileSavePath(KPTH_DESC, KEY_FILT, KEY_DEF, this.LastKeyPath);
            if (string.IsNullOrEmpty(filePath)) return;

            if (!Utilities.DirectoryIsWritable(Path.GetDirectoryName(filePath)))
            {
                MessageBox.Show("You do not have permission to create files in this directory! Choose a different path..");
                txtKeyFolder.Text = KPTH_DESC;
                this.KeyFilePath = string.Empty;
            }
            else
            {
                this.KeyFilePath = Utilities.GetUniquePath(filePath);
                if (!string.IsNullOrEmpty(this.KeyFilePath))
                    this.LastKeyPath = Path.GetDirectoryName(this.KeyFilePath);
                txtKeyFolder.Text = this.KeyFilePath;
                btnCreateKey.Enabled = true;
            }
        }

        private void OnKeySizeChanged(object sender, EventArgs e)
        {
            ComboBox cb = sender as ComboBox;

            if (cb.Text == "K128")
                this.KeySize = KeySizes.K128;
            else if (cb.Text == "K256")
                this.KeySize = KeySizes.K256;
            else
                this.KeySize = KeySizes.K512;
        }

        private void OnOutputFileClick(object sender, EventArgs e)
        {
            string filePath = GetFileSavePath(SAVE_DESC, ALL_FILT, "", this.LastOutputPath);
            if (string.IsNullOrEmpty(filePath)) return;

            if (!Utilities.DirectoryIsWritable(Path.GetDirectoryName(filePath)))
            {
                MessageBox.Show("You do not have permission to create files in this directory! Choose a different path..");
                txtOutputFile.Text = SAVE_DEFN;
                this.OutputPath = string.Empty;
                btnKeyFile.Enabled = false;
                btnCreateKey.Enabled = false;
            }
            else
            {
                this.OutputPath = Utilities.GetUniquePath(filePath);
                if (!string.IsNullOrEmpty(this.OutputPath))
                    this.LastOutputPath = Path.GetDirectoryName(this.OutputPath);
                txtOutputFile.Text = this.OutputPath;
                btnKeyFile.Enabled = true;
            }
        }

        private void OnPaddingModeChanged(object sender, EventArgs e)
        {
            ComboBox cb = sender as ComboBox;

            if (cb.Text == "PKCS7")
                this.PaddingMode = PaddingModes.PKCS7;
            else if (cb.Text == "X923")
                this.PaddingMode = PaddingModes.X923;
            else
                this.PaddingMode = PaddingModes.Zeros;
        }

        private void OnProgressCounter(int count)
        {
            if (this.IsHandleCreated)
                pbStatus.Invoke(new MethodInvoker(delegate { pbStatus.Value = count; }));
        }

        private void OnRunTestsClick(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FormTest ft = new FormTest();
            ft.ShowDialog(this);
        }

        private void OnSelectKeyClick(object sender, EventArgs e)
        {
            string keyFile = GetFileOpenPath(KEY_DESC, KEY_FILT, this.LastKeyPath);

            if (string.IsNullOrEmpty(keyFile)) return;

            if (!this.IsEncryption)
            {
                if (IsMatchingKey(this.InputPath, keyFile))
                {
                    this.KeyFilePath = keyFile;
                    txtKeyFile.Text = keyFile;
                    btnEncrypt.Enabled = true;
                }
                else
                {
                    this.KeyFilePath = string.Empty;
                    txtKeyFile.Text = KEY_DEFN;
                    btnEncrypt.Enabled = false;
                    MessageBox.Show("Key does not match the message! Choose a different key..");
                }
            }
            else
            {
                this.KeyFilePath = keyFile;
                txtKeyFile.Text = this.KeyFilePath;
                btnEncrypt.Enabled = true;
            }

            if (!string.IsNullOrEmpty(this.KeyFilePath))
                this.LastKeyPath = Path.GetDirectoryName(this.KeyFilePath);
        }

        private void OnTransformClick(object sender, EventArgs e)
        {
            lblStatus.Text = "Transforming output..";
            EnabledState(false);
            _transformWorker.RunWorkerAsync();
        }

        private void OnTransformDoWork(object sender, DoWorkEventArgs e)
        {
            if (this.IsEncryption)
                Encrypt();
            else
                Decrypt();
        }

        private void TransformWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            EnabledState(true);
            Reset();

            if (this.IsEncryption)
                lblStatus.Text = "The File has been Encrypted..";
            else
                lblStatus.Text = "The File has been Decrypted..";
        }

        private void OnVectorSizeChanged(object sender, EventArgs e)
        {
            ComboBox cb = sender as ComboBox;

            if (cb.Text.Equals("B16"))
                this.BlockSize = BlockSizes.B16;
            else
                this.BlockSize = BlockSizes.B32;
        }
        #endregion

        #region Settings
        private void LoadDefaults()
        {
            this.Engine = Engines.RDX;
            this.BlockSize = BlockSizes.B16;
            this.KeySize = KeySizes.K256;
            this.PaddingMode = PaddingModes.PKCS7;
            cbAlgorithm.SelectedIndex = 0;
            cbCipherMode.SelectedIndex = 0;
            cbKeySize.SelectedIndex = 1;
            cbVectorSize.SelectedIndex = 0;
            cbPaddingMode.SelectedIndex = 0;
        }

        private void LoadSettings()
        {
            if (Properties.Settings.Default.SettingFirstRun == true)
            {
                Properties.Settings.Default.SettingFirstRun = false;
                LoadDefaults();

                return;
            }

            cbAlgorithm.SelectedIndex = Properties.Settings.Default.SettingAlgorithm;
            cbCipherMode.SelectedIndex = Properties.Settings.Default.SettingCipherMode;
            cbKeySize.SelectedIndex = Properties.Settings.Default.SettingKeySize;
            this.LastKeyPath = Properties.Settings.Default.SettingLastKeyPath;
            this.LastInputPath = Properties.Settings.Default.SettingLastInputPath;
            this.LastOutputPath = Properties.Settings.Default.SettingLastOutputPath;
            cbPaddingMode.SelectedIndex = Properties.Settings.Default.SettingPaddingMode;
            cbVectorSize.SelectedIndex = Properties.Settings.Default.SettingVectorSize;
        }

        private void SaveSettings()
        {
            Properties.Settings.Default.SettingAlgorithm = cbAlgorithm.SelectedIndex;
            Properties.Settings.Default.SettingCipherMode = cbCipherMode.SelectedIndex;
            Properties.Settings.Default.SettingKeySize = cbKeySize.SelectedIndex;
            Properties.Settings.Default.SettingLastKeyPath = this.LastKeyPath;
            Properties.Settings.Default.SettingLastInputPath = this.LastInputPath;
            Properties.Settings.Default.SettingLastOutputPath = this.LastOutputPath;
            Properties.Settings.Default.SettingPaddingMode = cbPaddingMode.SelectedIndex;
            Properties.Settings.Default.SettingVectorSize = cbVectorSize.SelectedIndex;
            Properties.Settings.Default.Save();
        }
        #endregion

        #region Saved
        private bool HashTest()
        {
            byte[] hash1 = new byte[32];
            byte[] hash2 = new byte[32];
            byte[] hashKey = KeyGenerator.GetSeed32();
            byte[] buffer = KeyGenerator.GetSeed64();

            // test digest
            using (VTDev.Projects.CEX.Cryptographic.Digests.SHA256Digest sha1 = new VTDev.Projects.CEX.Cryptographic.Digests.SHA256Digest())
                hash1 = sha1.ComputeHash(buffer);

            using (System.Security.Cryptography.SHA256 sha2 = System.Security.Cryptography.SHA256Managed.Create())
                hash2 = sha2.ComputeHash(buffer);

            if (!IsEqual(hash1, hash2))
                throw new Exception("hash is not equal!");


            // hmac test 1
            HMAC hmac = new HMAC(new SHA256Digest());
            hmac.Init(hashKey);
            hmac.BlockUpdate(buffer, 0, buffer.Length);
            hmac.DoFinal(hash1, 0);

            using (System.Security.Cryptography.HMACSHA256 hmac2 = new System.Security.Cryptography.HMACSHA256(hashKey))
                hash2 = hmac2.ComputeHash(buffer);

            if (!IsEqual(hash1, hash2))
                throw new Exception("hmac is not equal!");


            // hmac test 2
            using (SHA256HMAC hmac3 = new SHA256HMAC(hashKey))
                hash1 = hmac3.ComputeHash(buffer);

            if (!IsEqual(hash1, hash2))
                throw new Exception("hmac is not equal!");

            return true;
        }

        private void FormatFile(string InputPath, string OutputPath)
        {
            using (FileStream reader = new FileStream(InputPath, FileMode.Open, FileAccess.Read, FileShare.None))
            {
                int blockSize = (int)reader.Length;
                byte[] inputBuffer = new byte[blockSize];
                reader.Read(inputBuffer, 0, blockSize);
                var str = System.Text.Encoding.Default.GetString(inputBuffer);
                str = str.Replace(" ", "");
                str = str.Replace(Environment.NewLine, "");

                using (FileStream writer = new FileStream(OutputPath, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    byte[] buffer = System.Text.Encoding.ASCII.GetBytes(str);
                    writer.Write(buffer, 0, buffer.Length);
                }
            }
        }

        private static bool IsEqual(byte[] a, byte[] b)
        {
            int i = a.Length;

            if (i != b.Length)
                return false;

            while (i != 0)
            {
                --i;
                if (a[i] != b[i])
                    return false;
            }

            return true;
        }
        #endregion
    }
}
