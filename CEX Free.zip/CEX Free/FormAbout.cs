﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Reflection;

namespace VTDev.Projects.CEX
{
    public partial class FormAbout : Form
    {
        public FormAbout()
        {
            InitializeComponent();
        }

        private void OnFormLoad(object sender, EventArgs e)
        {
            LoadText();
        }

        private void LoadText()
        {
            const string about = "VTDev.Projects.CEX.about.rtf";

            try
            {
                rtbAbout.Clear();
                Assembly helpAssm = Assembly.GetExecutingAssembly();

                using (Stream stream = helpAssm.GetManifestResourceStream(about))
                {
                    if (stream != null)
                        rtbAbout.LoadFile(stream, RichTextBoxStreamType.RichText);
                }
            }
            catch { }
        }

        private void OnCloseClick(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
