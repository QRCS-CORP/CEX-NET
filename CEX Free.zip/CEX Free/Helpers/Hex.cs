﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VTDev.Projects.CEX.Helpers
{
    internal static class Hex
    {
        internal static readonly byte[] decodingTable = new byte[128];
        private static readonly byte[] encodingTable =
		{
			(byte)'0', (byte)'1', (byte)'2', (byte)'3', (byte)'4', (byte)'5', (byte)'6', (byte)'7',
			(byte)'8', (byte)'9', (byte)'a', (byte)'b', (byte)'c', (byte)'d', (byte)'e', (byte)'f'
		};

		static Hex()
		{
			for (int i = 0; i < encodingTable.Length; i++)
				decodingTable[encodingTable[i]] = (byte)i;

			decodingTable['A'] = decodingTable['a'];
			decodingTable['B'] = decodingTable['b'];
			decodingTable['C'] = decodingTable['c'];
			decodingTable['D'] = decodingTable['d'];
			decodingTable['E'] = decodingTable['e'];
			decodingTable['F'] = decodingTable['f'];
		}

        internal static byte[] Encode(byte[] data, int off, int length)
        {
            byte[] temp = new byte[length * 2];
            int ct = 0;

            for (int i = off; i < (off + length); i++)
            {
                int v = data[i];
                temp[ct++] = encodingTable[v >> 4];
                temp[ct++] = encodingTable[v & 0xf];
            }

            return temp;
        }

        /**
        * decode the Hex encoded string data writing it to the given output stream,
        * whitespace characters will be ignored.
        *
        * @return the number of bytes produced.
        */
        internal static byte[] Decode(string data)
        {
            byte b1, b2;
            int length = 0;
            int end = data.Length;
            byte[] temp = new byte[end / 2];

            while (end > 0)
            {
                if (!ignore(data[end - 1]))
                    break;

                end--;
            }

            int i = 0;
            int ct = 0;
            while (i < end)
            {
                while (i < end && ignore(data[i]))
                    i++;

                b1 = decodingTable[data[i++]];

                while (i < end && ignore(data[i]))
                    i++;

                b2 = decodingTable[data[i++]];
                temp[ct++] = (byte)((b1 << 4) | b2);
                length++;
            }

            return temp;
        }

        private static bool ignore(char c)
        {
            return (c == '\n' || c == '\r' || c == '\t' || c == ' ');
        }
    }
}
