﻿namespace VTDev.Projects.CEX
{
    partial class FormTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpTests = new System.Windows.Forms.GroupBox();
            this.Sha2Vector = new System.Windows.Forms.CheckBox();
            this.SerpentVector = new System.Windows.Forms.CheckBox();
            this.SerpentKey = new System.Windows.Forms.CheckBox();
            this.Sha3Vector = new System.Windows.Forms.CheckBox();
            this.SalsaVector = new System.Windows.Forms.CheckBox();
            this.HmacVector = new System.Windows.Forms.CheckBox();
            this.HKDFVector = new System.Windows.Forms.CheckBox();
            this.ChaChaVector = new System.Windows.Forms.CheckBox();
            this.AesAvs = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ModeVectors = new System.Windows.Forms.CheckBox();
            this.RijndaelIO = new System.Windows.Forms.CheckBox();
            this.AesMonteCarlo = new System.Windows.Forms.CheckBox();
            this.RijndaelVector = new System.Windows.Forms.CheckBox();
            this.ModePSCEquality = new System.Windows.Forms.CheckBox();
            this.btnAlgoTest = new System.Windows.Forms.Button();
            this.lvAlgorithmTest = new System.Windows.Forms.ListView();
            this.col1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.grpSpeed = new System.Windows.Forms.GroupBox();
            this.rdSalsa20 = new System.Windows.Forms.RadioButton();
            this.lblCompileWarning = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.rdSPX = new System.Windows.Forms.RadioButton();
            this.rdSHX = new System.Windows.Forms.RadioButton();
            this.rdRSX = new System.Windows.Forms.RadioButton();
            this.rdRHX = new System.Windows.Forms.RadioButton();
            this.rdRDX = new System.Windows.Forms.RadioButton();
            this.rdDCS = new System.Windows.Forms.RadioButton();
            this.rdChaCha20 = new System.Windows.Forms.RadioButton();
            this.btnSpeedTest = new System.Windows.Forms.Button();
            this.txtSizeMB = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lblEngineTime = new System.Windows.Forms.Label();
            this.lblTestStatus = new System.Windows.Forms.Label();
            this.pbTestStatus = new System.Windows.Forms.ProgressBar();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.grpLogging = new System.Windows.Forms.GroupBox();
            this.pnlLog = new System.Windows.Forms.Panel();
            this.btnLogBrowse = new System.Windows.Forms.Button();
            this.chkLogResults = new System.Windows.Forms.CheckBox();
            this.txtLogFile = new System.Windows.Forms.TextBox();
            this.rdLogConsole = new System.Windows.Forms.RadioButton();
            this.lblOutput = new System.Windows.Forms.Label();
            this.rdLogFile = new System.Windows.Forms.RadioButton();
            this.grpTests.SuspendLayout();
            this.grpSpeed.SuspendLayout();
            this.grpLogging.SuspendLayout();
            this.pnlLog.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpTests
            // 
            this.grpTests.Controls.Add(this.Sha2Vector);
            this.grpTests.Controls.Add(this.SerpentVector);
            this.grpTests.Controls.Add(this.SerpentKey);
            this.grpTests.Controls.Add(this.Sha3Vector);
            this.grpTests.Controls.Add(this.SalsaVector);
            this.grpTests.Controls.Add(this.HmacVector);
            this.grpTests.Controls.Add(this.HKDFVector);
            this.grpTests.Controls.Add(this.ChaChaVector);
            this.grpTests.Controls.Add(this.AesAvs);
            this.grpTests.Controls.Add(this.label2);
            this.grpTests.Controls.Add(this.label1);
            this.grpTests.Controls.Add(this.ModeVectors);
            this.grpTests.Controls.Add(this.RijndaelIO);
            this.grpTests.Controls.Add(this.AesMonteCarlo);
            this.grpTests.Controls.Add(this.RijndaelVector);
            this.grpTests.Controls.Add(this.ModePSCEquality);
            this.grpTests.Controls.Add(this.btnAlgoTest);
            this.grpTests.Controls.Add(this.lvAlgorithmTest);
            this.grpTests.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpTests.Location = new System.Drawing.Point(12, 12);
            this.grpTests.Name = "grpTests";
            this.grpTests.Size = new System.Drawing.Size(700, 383);
            this.grpTests.TabIndex = 25;
            this.grpTests.TabStop = false;
            this.grpTests.Text = "Algorithm Testing";
            // 
            // Sha2Vector
            // 
            this.Sha2Vector.AutoSize = true;
            this.Sha2Vector.Checked = true;
            this.Sha2Vector.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Sha2Vector.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sha2Vector.Location = new System.Drawing.Point(511, 278);
            this.Sha2Vector.Name = "Sha2Vector";
            this.Sha2Vector.Size = new System.Drawing.Size(117, 17);
            this.Sha2Vector.TabIndex = 115;
            this.Sha2Vector.Text = "Sha-2 KAT Vectors";
            this.Sha2Vector.UseVisualStyleBackColor = true;
            // 
            // SerpentVector
            // 
            this.SerpentVector.AutoSize = true;
            this.SerpentVector.Checked = true;
            this.SerpentVector.CheckState = System.Windows.Forms.CheckState.Checked;
            this.SerpentVector.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SerpentVector.Location = new System.Drawing.Point(511, 258);
            this.SerpentVector.Name = "SerpentVector";
            this.SerpentVector.Size = new System.Drawing.Size(130, 17);
            this.SerpentVector.TabIndex = 107;
            this.SerpentVector.Text = "Serpent Vector Tests";
            this.SerpentVector.UseVisualStyleBackColor = true;
            // 
            // SerpentKey
            // 
            this.SerpentKey.AutoSize = true;
            this.SerpentKey.Checked = true;
            this.SerpentKey.CheckState = System.Windows.Forms.CheckState.Checked;
            this.SerpentKey.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SerpentKey.Location = new System.Drawing.Point(511, 238);
            this.SerpentKey.Name = "SerpentKey";
            this.SerpentKey.Size = new System.Drawing.Size(174, 17);
            this.SerpentKey.TabIndex = 105;
            this.SerpentKey.Text = "RSX/Serpent Key Comparison";
            this.SerpentKey.UseVisualStyleBackColor = true;
            // 
            // Sha3Vector
            // 
            this.Sha3Vector.AutoSize = true;
            this.Sha3Vector.Checked = true;
            this.Sha3Vector.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Sha3Vector.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sha3Vector.Location = new System.Drawing.Point(511, 298);
            this.Sha3Vector.Name = "Sha3Vector";
            this.Sha3Vector.Size = new System.Drawing.Size(117, 17);
            this.Sha3Vector.TabIndex = 104;
            this.Sha3Vector.Text = "Sha-3 KAT Vectors";
            this.Sha3Vector.UseVisualStyleBackColor = true;
            // 
            // SalsaVector
            // 
            this.SalsaVector.AutoSize = true;
            this.SalsaVector.Checked = true;
            this.SalsaVector.CheckState = System.Windows.Forms.CheckState.Checked;
            this.SalsaVector.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalsaVector.Location = new System.Drawing.Point(511, 218);
            this.SalsaVector.Name = "SalsaVector";
            this.SalsaVector.Size = new System.Drawing.Size(114, 17);
            this.SalsaVector.TabIndex = 103;
            this.SalsaVector.Text = "Salsa KAT Vectors";
            this.SalsaVector.UseVisualStyleBackColor = true;
            // 
            // HmacVector
            // 
            this.HmacVector.AutoSize = true;
            this.HmacVector.Checked = true;
            this.HmacVector.CheckState = System.Windows.Forms.CheckState.Checked;
            this.HmacVector.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HmacVector.Location = new System.Drawing.Point(511, 118);
            this.HmacVector.Name = "HmacVector";
            this.HmacVector.Size = new System.Drawing.Size(176, 17);
            this.HmacVector.TabIndex = 101;
            this.HmacVector.Text = "HMAC KAT Vectors (RFC 4321)";
            this.HmacVector.UseVisualStyleBackColor = true;
            // 
            // HKDFVector
            // 
            this.HKDFVector.AutoSize = true;
            this.HKDFVector.Checked = true;
            this.HKDFVector.CheckState = System.Windows.Forms.CheckState.Checked;
            this.HKDFVector.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HKDFVector.Location = new System.Drawing.Point(511, 98);
            this.HKDFVector.Name = "HKDFVector";
            this.HKDFVector.Size = new System.Drawing.Size(172, 17);
            this.HKDFVector.TabIndex = 100;
            this.HKDFVector.Text = "HKDF KAT Vectors (RFC 5869)";
            this.HKDFVector.UseVisualStyleBackColor = true;
            // 
            // ChaChaVector
            // 
            this.ChaChaVector.AutoSize = true;
            this.ChaChaVector.Checked = true;
            this.ChaChaVector.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ChaChaVector.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChaChaVector.Location = new System.Drawing.Point(511, 78);
            this.ChaChaVector.Name = "ChaChaVector";
            this.ChaChaVector.Size = new System.Drawing.Size(128, 17);
            this.ChaChaVector.TabIndex = 99;
            this.ChaChaVector.Text = "ChaCha KAT Vectors";
            this.ChaChaVector.UseVisualStyleBackColor = true;
            // 
            // AesAvs
            // 
            this.AesAvs.AutoSize = true;
            this.AesAvs.Checked = true;
            this.AesAvs.CheckState = System.Windows.Forms.CheckState.Checked;
            this.AesAvs.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AesAvs.Location = new System.Drawing.Point(511, 38);
            this.AesAvs.Name = "AesAvs";
            this.AesAvs.Size = new System.Drawing.Size(137, 17);
            this.AesAvs.TabIndex = 98;
            this.AesAvs.Text = "AESAVS Vectors (NIST)";
            this.AesAvs.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(8, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 96;
            this.label2.Text = "Results:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(508, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 95;
            this.label1.Text = "Test Vectors:";
            // 
            // ModeVectors
            // 
            this.ModeVectors.AutoSize = true;
            this.ModeVectors.Checked = true;
            this.ModeVectors.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ModeVectors.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ModeVectors.Location = new System.Drawing.Point(511, 138);
            this.ModeVectors.Name = "ModeVectors";
            this.ModeVectors.Size = new System.Drawing.Size(157, 17);
            this.ModeVectors.TabIndex = 85;
            this.ModeVectors.Text = "Mode KATs (NIST 800-38A)";
            this.ModeVectors.UseVisualStyleBackColor = true;
            // 
            // RijndaelIO
            // 
            this.RijndaelIO.AutoSize = true;
            this.RijndaelIO.Checked = true;
            this.RijndaelIO.CheckState = System.Windows.Forms.CheckState.Checked;
            this.RijndaelIO.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RijndaelIO.Location = new System.Drawing.Point(511, 178);
            this.RijndaelIO.Name = "RijndaelIO";
            this.RijndaelIO.Size = new System.Drawing.Size(115, 17);
            this.RijndaelIO.TabIndex = 93;
            this.RijndaelIO.Text = "Rijndael I/O Tests";
            this.RijndaelIO.UseVisualStyleBackColor = true;
            // 
            // AesMonteCarlo
            // 
            this.AesMonteCarlo.AutoSize = true;
            this.AesMonteCarlo.Checked = true;
            this.AesMonteCarlo.CheckState = System.Windows.Forms.CheckState.Checked;
            this.AesMonteCarlo.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AesMonteCarlo.Location = new System.Drawing.Point(511, 58);
            this.AesMonteCarlo.Name = "AesMonteCarlo";
            this.AesMonteCarlo.Size = new System.Drawing.Size(163, 17);
            this.AesMonteCarlo.TabIndex = 92;
            this.AesMonteCarlo.Text = "AES Monte Carlo (Fips 197)";
            this.AesMonteCarlo.UseVisualStyleBackColor = true;
            // 
            // RijndaelVector
            // 
            this.RijndaelVector.AutoSize = true;
            this.RijndaelVector.Checked = true;
            this.RijndaelVector.CheckState = System.Windows.Forms.CheckState.Checked;
            this.RijndaelVector.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RijndaelVector.Location = new System.Drawing.Point(511, 198);
            this.RijndaelVector.Name = "RijndaelVector";
            this.RijndaelVector.Size = new System.Drawing.Size(132, 17);
            this.RijndaelVector.TabIndex = 89;
            this.RijndaelVector.Text = "Rijndael Vector Tests";
            this.RijndaelVector.UseVisualStyleBackColor = true;
            // 
            // ModePSCEquality
            // 
            this.ModePSCEquality.AutoSize = true;
            this.ModePSCEquality.Checked = true;
            this.ModePSCEquality.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ModePSCEquality.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ModePSCEquality.Location = new System.Drawing.Point(511, 158);
            this.ModePSCEquality.Name = "ModePSCEquality";
            this.ModePSCEquality.Size = new System.Drawing.Size(128, 17);
            this.ModePSCEquality.TabIndex = 86;
            this.ModePSCEquality.Text = "PSC/SIC Equivalency";
            this.ModePSCEquality.UseVisualStyleBackColor = true;
            // 
            // btnAlgoTest
            // 
            this.btnAlgoTest.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlgoTest.Location = new System.Drawing.Point(611, 330);
            this.btnAlgoTest.Name = "btnAlgoTest";
            this.btnAlgoTest.Size = new System.Drawing.Size(72, 35);
            this.btnAlgoTest.TabIndex = 27;
            this.btnAlgoTest.Text = "Test";
            this.btnAlgoTest.UseVisualStyleBackColor = true;
            this.btnAlgoTest.Click += new System.EventHandler(this.OnAlgoTestClick);
            // 
            // lvAlgorithmTest
            // 
            this.lvAlgorithmTest.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.col1,
            this.col2,
            this.col3});
            this.lvAlgorithmTest.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvAlgorithmTest.FullRowSelect = true;
            this.lvAlgorithmTest.GridLines = true;
            this.lvAlgorithmTest.Location = new System.Drawing.Point(11, 38);
            this.lvAlgorithmTest.Name = "lvAlgorithmTest";
            this.lvAlgorithmTest.Size = new System.Drawing.Size(486, 270);
            this.lvAlgorithmTest.TabIndex = 1;
            this.lvAlgorithmTest.UseCompatibleStateImageBehavior = false;
            this.lvAlgorithmTest.View = System.Windows.Forms.View.Details;
            // 
            // col1
            // 
            this.col1.Text = "Test Name";
            this.col1.Width = 87;
            // 
            // col2
            // 
            this.col2.Text = "Description";
            this.col2.Width = 345;
            // 
            // col3
            // 
            this.col3.Text = "State";
            this.col3.Width = 50;
            // 
            // grpSpeed
            // 
            this.grpSpeed.Controls.Add(this.lblEngineTime);
            this.grpSpeed.Controls.Add(this.rdSalsa20);
            this.grpSpeed.Controls.Add(this.lblCompileWarning);
            this.grpSpeed.Controls.Add(this.label3);
            this.grpSpeed.Controls.Add(this.rdSPX);
            this.grpSpeed.Controls.Add(this.rdSHX);
            this.grpSpeed.Controls.Add(this.rdRSX);
            this.grpSpeed.Controls.Add(this.rdRHX);
            this.grpSpeed.Controls.Add(this.rdRDX);
            this.grpSpeed.Controls.Add(this.rdDCS);
            this.grpSpeed.Controls.Add(this.rdChaCha20);
            this.grpSpeed.Controls.Add(this.btnSpeedTest);
            this.grpSpeed.Controls.Add(this.txtSizeMB);
            this.grpSpeed.Controls.Add(this.label15);
            this.grpSpeed.Controls.Add(this.label13);
            this.grpSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpSpeed.Location = new System.Drawing.Point(718, 12);
            this.grpSpeed.Name = "grpSpeed";
            this.grpSpeed.Size = new System.Drawing.Size(330, 270);
            this.grpSpeed.TabIndex = 27;
            this.grpSpeed.TabStop = false;
            this.grpSpeed.Text = "Cipher Speed Test (Encrypt a Temp File)";
            // 
            // rdSalsa20
            // 
            this.rdSalsa20.AutoSize = true;
            this.rdSalsa20.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdSalsa20.Location = new System.Drawing.Point(14, 137);
            this.rdSalsa20.Name = "rdSalsa20";
            this.rdSalsa20.Size = new System.Drawing.Size(63, 17);
            this.rdSalsa20.TabIndex = 98;
            this.rdSalsa20.Text = "Salsa20";
            this.rdSalsa20.UseVisualStyleBackColor = true;
            this.rdSalsa20.CheckedChanged += new System.EventHandler(this.OnEngineCheckChanged);
            // 
            // lblCompileWarning
            // 
            this.lblCompileWarning.AutoSize = true;
            this.lblCompileWarning.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompileWarning.Location = new System.Drawing.Point(129, 20);
            this.lblCompileWarning.Name = "lblCompileWarning";
            this.lblCompileWarning.Size = new System.Drawing.Size(184, 13);
            this.lblCompileWarning.TabIndex = 97;
            this.lblCompileWarning.Text = "(Compile in Release mode to test!)";
            this.lblCompileWarning.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(11, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 13);
            this.label3.TabIndex = 96;
            this.label3.Text = "Engines:";
            // 
            // rdSPX
            // 
            this.rdSPX.AutoSize = true;
            this.rdSPX.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdSPX.Location = new System.Drawing.Point(14, 177);
            this.rdSPX.Name = "rdSPX";
            this.rdSPX.Size = new System.Drawing.Size(151, 17);
            this.rdSPX.TabIndex = 50;
            this.rdSPX.Text = "SPX (256 Key, 32 Rounds)";
            this.rdSPX.UseVisualStyleBackColor = true;
            this.rdSPX.CheckedChanged += new System.EventHandler(this.OnEngineCheckChanged);
            // 
            // rdSHX
            // 
            this.rdSHX.AutoSize = true;
            this.rdSHX.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdSHX.Location = new System.Drawing.Point(14, 157);
            this.rdSHX.Name = "rdSHX";
            this.rdSHX.Size = new System.Drawing.Size(109, 17);
            this.rdSHX.TabIndex = 49;
            this.rdSHX.Text = "SHX (64 Rounds)";
            this.rdSHX.UseVisualStyleBackColor = true;
            this.rdSHX.CheckedChanged += new System.EventHandler(this.OnEngineCheckChanged);
            // 
            // rdRSX
            // 
            this.rdRSX.AutoSize = true;
            this.rdRSX.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdRSX.Location = new System.Drawing.Point(14, 117);
            this.rdRSX.Name = "rdRSX";
            this.rdRSX.Size = new System.Drawing.Size(152, 17);
            this.rdRSX.TabIndex = 48;
            this.rdRSX.Text = "RSX (512 Key, 22 Rounds)";
            this.rdRSX.UseVisualStyleBackColor = true;
            this.rdRSX.CheckedChanged += new System.EventHandler(this.OnEngineCheckChanged);
            // 
            // rdRHX
            // 
            this.rdRHX.AutoSize = true;
            this.rdRHX.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdRHX.Location = new System.Drawing.Point(14, 97);
            this.rdRHX.Name = "rdRHX";
            this.rdRHX.Size = new System.Drawing.Size(110, 17);
            this.rdRHX.TabIndex = 47;
            this.rdRHX.Text = "RHX (22 Rounds)";
            this.rdRHX.UseVisualStyleBackColor = true;
            this.rdRHX.CheckedChanged += new System.EventHandler(this.OnEngineCheckChanged);
            // 
            // rdRDX
            // 
            this.rdRDX.AutoSize = true;
            this.rdRDX.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdRDX.Location = new System.Drawing.Point(14, 77);
            this.rdRDX.Name = "rdRDX";
            this.rdRDX.Size = new System.Drawing.Size(154, 17);
            this.rdRDX.TabIndex = 46;
            this.rdRDX.Text = "RDX (256 Key, 14 Rounds)";
            this.rdRDX.UseVisualStyleBackColor = true;
            this.rdRDX.CheckedChanged += new System.EventHandler(this.OnEngineCheckChanged);
            // 
            // rdDCS
            // 
            this.rdDCS.AutoSize = true;
            this.rdDCS.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdDCS.Location = new System.Drawing.Point(14, 57);
            this.rdDCS.Name = "rdDCS";
            this.rdDCS.Size = new System.Drawing.Size(109, 17);
            this.rdDCS.TabIndex = 45;
            this.rdDCS.Text = "Dual CTR Stream";
            this.rdDCS.UseVisualStyleBackColor = true;
            this.rdDCS.CheckedChanged += new System.EventHandler(this.OnEngineCheckChanged);
            // 
            // rdChaCha20
            // 
            this.rdChaCha20.AutoSize = true;
            this.rdChaCha20.Checked = true;
            this.rdChaCha20.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdChaCha20.Location = new System.Drawing.Point(14, 37);
            this.rdChaCha20.Name = "rdChaCha20";
            this.rdChaCha20.Size = new System.Drawing.Size(77, 17);
            this.rdChaCha20.TabIndex = 44;
            this.rdChaCha20.TabStop = true;
            this.rdChaCha20.Text = "ChaCha20";
            this.rdChaCha20.UseVisualStyleBackColor = true;
            this.rdChaCha20.CheckedChanged += new System.EventHandler(this.OnEngineCheckChanged);
            // 
            // btnSpeedTest
            // 
            this.btnSpeedTest.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSpeedTest.Location = new System.Drawing.Point(241, 218);
            this.btnSpeedTest.Name = "btnSpeedTest";
            this.btnSpeedTest.Size = new System.Drawing.Size(72, 35);
            this.btnSpeedTest.TabIndex = 43;
            this.btnSpeedTest.Text = "Test";
            this.btnSpeedTest.UseVisualStyleBackColor = true;
            this.btnSpeedTest.Click += new System.EventHandler(this.OnSpeedTestClick);
            // 
            // txtSizeMB
            // 
            this.txtSizeMB.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSizeMB.Location = new System.Drawing.Point(103, 204);
            this.txtSizeMB.MaxLength = 3;
            this.txtSizeMB.Name = "txtSizeMB";
            this.txtSizeMB.Size = new System.Drawing.Size(32, 22);
            this.txtSizeMB.TabIndex = 38;
            this.txtSizeMB.Text = "1";
            this.txtSizeMB.TextChanged += new System.EventHandler(this.OnTextChanged);
            this.txtSizeMB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.OnTextBoxKeyPress);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(12, 208);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(92, 13);
            this.label15.TabIndex = 40;
            this.label15.Text = "Size (1-100) MiB:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(12, 233);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(67, 13);
            this.label13.TabIndex = 35;
            this.label13.Text = "Time (m:s): ";
            // 
            // lblEngineTime
            // 
            this.lblEngineTime.AutoSize = true;
            this.lblEngineTime.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEngineTime.Location = new System.Drawing.Point(75, 233);
            this.lblEngineTime.Name = "lblEngineTime";
            this.lblEngineTime.Size = new System.Drawing.Size(22, 13);
            this.lblEngineTime.TabIndex = 34;
            this.lblEngineTime.Text = "0.0";
            // 
            // lblTestStatus
            // 
            this.lblTestStatus.AutoSize = true;
            this.lblTestStatus.Location = new System.Drawing.Point(128, 409);
            this.lblTestStatus.Name = "lblTestStatus";
            this.lblTestStatus.Size = new System.Drawing.Size(32, 13);
            this.lblTestStatus.TabIndex = 30;
            this.lblTestStatus.Text = "Idle..";
            // 
            // pbTestStatus
            // 
            this.pbTestStatus.Location = new System.Drawing.Point(15, 407);
            this.pbTestStatus.Name = "pbTestStatus";
            this.pbTestStatus.Size = new System.Drawing.Size(108, 16);
            this.pbTestStatus.TabIndex = 29;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 404);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1061, 22);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 28;
            // 
            // grpLogging
            // 
            this.grpLogging.Controls.Add(this.pnlLog);
            this.grpLogging.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpLogging.Location = new System.Drawing.Point(718, 290);
            this.grpLogging.Name = "grpLogging";
            this.grpLogging.Size = new System.Drawing.Size(330, 105);
            this.grpLogging.TabIndex = 31;
            this.grpLogging.TabStop = false;
            this.grpLogging.Text = "Logging";
            // 
            // pnlLog
            // 
            this.pnlLog.Controls.Add(this.btnLogBrowse);
            this.pnlLog.Controls.Add(this.chkLogResults);
            this.pnlLog.Controls.Add(this.txtLogFile);
            this.pnlLog.Controls.Add(this.rdLogConsole);
            this.pnlLog.Controls.Add(this.lblOutput);
            this.pnlLog.Controls.Add(this.rdLogFile);
            this.pnlLog.Location = new System.Drawing.Point(10, 21);
            this.pnlLog.Name = "pnlLog";
            this.pnlLog.Size = new System.Drawing.Size(311, 73);
            this.pnlLog.TabIndex = 115;
            // 
            // btnLogBrowse
            // 
            this.btnLogBrowse.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogBrowse.Location = new System.Drawing.Point(273, 39);
            this.btnLogBrowse.Name = "btnLogBrowse";
            this.btnLogBrowse.Size = new System.Drawing.Size(30, 30);
            this.btnLogBrowse.TabIndex = 118;
            this.btnLogBrowse.Text = "...";
            this.btnLogBrowse.UseVisualStyleBackColor = true;
            // 
            // chkLogResults
            // 
            this.chkLogResults.AutoSize = true;
            this.chkLogResults.Checked = true;
            this.chkLogResults.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkLogResults.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkLogResults.Location = new System.Drawing.Point(158, 20);
            this.chkLogResults.Name = "chkLogResults";
            this.chkLogResults.Size = new System.Drawing.Size(85, 17);
            this.chkLogResults.TabIndex = 116;
            this.chkLogResults.Text = "Log Results";
            this.chkLogResults.UseVisualStyleBackColor = true;
            // 
            // txtLogFile
            // 
            this.txtLogFile.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLogFile.Location = new System.Drawing.Point(9, 45);
            this.txtLogFile.Name = "txtLogFile";
            this.txtLogFile.ReadOnly = true;
            this.txtLogFile.Size = new System.Drawing.Size(257, 22);
            this.txtLogFile.TabIndex = 119;
            this.txtLogFile.Text = "[Select an Output Folder]";
            // 
            // rdLogConsole
            // 
            this.rdLogConsole.AutoSize = true;
            this.rdLogConsole.Checked = true;
            this.rdLogConsole.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdLogConsole.Location = new System.Drawing.Point(9, 20);
            this.rdLogConsole.Name = "rdLogConsole";
            this.rdLogConsole.Size = new System.Drawing.Size(67, 17);
            this.rdLogConsole.TabIndex = 114;
            this.rdLogConsole.TabStop = true;
            this.rdLogConsole.Text = "Console";
            this.rdLogConsole.UseVisualStyleBackColor = true;
            this.rdLogConsole.Visible = false;
            // 
            // lblOutput
            // 
            this.lblOutput.AutoSize = true;
            this.lblOutput.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOutput.Location = new System.Drawing.Point(6, 4);
            this.lblOutput.Name = "lblOutput";
            this.lblOutput.Size = new System.Drawing.Size(45, 13);
            this.lblOutput.TabIndex = 117;
            this.lblOutput.Text = "Output:";
            this.lblOutput.Visible = false;
            // 
            // rdLogFile
            // 
            this.rdLogFile.AutoSize = true;
            this.rdLogFile.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdLogFile.Location = new System.Drawing.Point(82, 20);
            this.rdLogFile.Name = "rdLogFile";
            this.rdLogFile.Size = new System.Drawing.Size(65, 17);
            this.rdLogFile.TabIndex = 115;
            this.rdLogFile.Text = "Log File";
            this.rdLogFile.UseVisualStyleBackColor = true;
            this.rdLogFile.Visible = false;
            // 
            // FormTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1061, 426);
            this.Controls.Add(this.grpLogging);
            this.Controls.Add(this.lblTestStatus);
            this.Controls.Add(this.pbTestStatus);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.grpSpeed);
            this.Controls.Add(this.grpTests);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormTest";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RDX Tests";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.OnFormClose);
            this.Load += new System.EventHandler(this.OnFormLoad);
            this.grpTests.ResumeLayout(false);
            this.grpTests.PerformLayout();
            this.grpSpeed.ResumeLayout(false);
            this.grpSpeed.PerformLayout();
            this.grpLogging.ResumeLayout(false);
            this.pnlLog.ResumeLayout(false);
            this.pnlLog.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpTests;
        private System.Windows.Forms.Button btnAlgoTest;
        private System.Windows.Forms.ListView lvAlgorithmTest;
        private System.Windows.Forms.ColumnHeader col1;
        private System.Windows.Forms.ColumnHeader col2;
        private System.Windows.Forms.ColumnHeader col3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grpSpeed;
        private System.Windows.Forms.Button btnSpeedTest;
        private System.Windows.Forms.TextBox txtSizeMB;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblEngineTime;
        private System.Windows.Forms.Label lblTestStatus;
        private System.Windows.Forms.ProgressBar pbTestStatus;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.CheckBox ModeVectors;
        private System.Windows.Forms.CheckBox RijndaelIO;
        private System.Windows.Forms.CheckBox AesMonteCarlo;
        private System.Windows.Forms.CheckBox RijndaelVector;
        private System.Windows.Forms.CheckBox ModePSCEquality;
        private System.Windows.Forms.CheckBox AesAvs;
        private System.Windows.Forms.CheckBox ChaChaVector;
        private System.Windows.Forms.CheckBox Sha3Vector;
        private System.Windows.Forms.CheckBox SalsaVector;
        private System.Windows.Forms.CheckBox HmacVector;
        private System.Windows.Forms.CheckBox HKDFVector;
        private System.Windows.Forms.CheckBox SerpentKey;
        private System.Windows.Forms.CheckBox SerpentVector;
        private System.Windows.Forms.CheckBox Sha2Vector;
        private System.Windows.Forms.RadioButton rdDCS;
        private System.Windows.Forms.RadioButton rdChaCha20;
        private System.Windows.Forms.RadioButton rdSHX;
        private System.Windows.Forms.RadioButton rdRSX;
        private System.Windows.Forms.RadioButton rdRHX;
        private System.Windows.Forms.RadioButton rdRDX;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton rdSPX;
        private System.Windows.Forms.GroupBox grpLogging;
        private System.Windows.Forms.Panel pnlLog;
        private System.Windows.Forms.Button btnLogBrowse;
        private System.Windows.Forms.CheckBox chkLogResults;
        private System.Windows.Forms.TextBox txtLogFile;
        private System.Windows.Forms.RadioButton rdLogConsole;
        private System.Windows.Forms.Label lblOutput;
        private System.Windows.Forms.RadioButton rdLogFile;
        private System.Windows.Forms.Label lblCompileWarning;
        private System.Windows.Forms.RadioButton rdSalsa20;
    }
}