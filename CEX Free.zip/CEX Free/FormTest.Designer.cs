﻿namespace VTDev.Projects.CEX
{
    partial class FormTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpTests = new System.Windows.Forms.GroupBox();
            this.AesAvsKey = new System.Windows.Forms.CheckBox();
            this.AesAvsText = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ModeEquality = new System.Windows.Forms.CheckBox();
            this.IOTest = new System.Windows.Forms.CheckBox();
            this.AesVector = new System.Windows.Forms.CheckBox();
            this.MonteCarlo = new System.Windows.Forms.CheckBox();
            this.RijndaelVector = new System.Windows.Forms.CheckBox();
            this.BlockEquality = new System.Windows.Forms.CheckBox();
            this.SICVector = new System.Windows.Forms.CheckBox();
            this.PSCEquality = new System.Windows.Forms.CheckBox();
            this.btnAlgoTest = new System.Windows.Forms.Button();
            this.lvAlgorithmTest = new System.Windows.Forms.ListView();
            this.col1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnLogBrowse = new System.Windows.Forms.Button();
            this.txtLogFile = new System.Windows.Forms.TextBox();
            this.lblOutput = new System.Windows.Forms.Label();
            this.chkLogResults = new System.Windows.Forms.CheckBox();
            this.rdLogFile = new System.Windows.Forms.RadioButton();
            this.rdLogConsole = new System.Windows.Forms.RadioButton();
            this.grpLogging = new System.Windows.Forms.GroupBox();
            this.grpSpeed = new System.Windows.Forms.GroupBox();
            this.btnSpeedTest = new System.Windows.Forms.Button();
            this.lblCompileWarning = new System.Windows.Forms.Label();
            this.lblSpeedHeader = new System.Windows.Forms.Label();
            this.txtSpeedIterations = new System.Windows.Forms.TextBox();
            this.txtSpeedBlocks = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblManagedTime = new System.Windows.Forms.Label();
            this.lblSpeedInfo = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lblRdxTime = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lblTestStatus = new System.Windows.Forms.Label();
            this.pbTestStatus = new System.Windows.Forms.ProgressBar();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.lblCompare = new System.Windows.Forms.Label();
            this.grpTests.SuspendLayout();
            this.grpLogging.SuspendLayout();
            this.grpSpeed.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpTests
            // 
            this.grpTests.Controls.Add(this.AesAvsKey);
            this.grpTests.Controls.Add(this.AesAvsText);
            this.grpTests.Controls.Add(this.label2);
            this.grpTests.Controls.Add(this.label1);
            this.grpTests.Controls.Add(this.ModeEquality);
            this.grpTests.Controls.Add(this.IOTest);
            this.grpTests.Controls.Add(this.AesVector);
            this.grpTests.Controls.Add(this.MonteCarlo);
            this.grpTests.Controls.Add(this.RijndaelVector);
            this.grpTests.Controls.Add(this.BlockEquality);
            this.grpTests.Controls.Add(this.SICVector);
            this.grpTests.Controls.Add(this.PSCEquality);
            this.grpTests.Controls.Add(this.btnAlgoTest);
            this.grpTests.Controls.Add(this.lvAlgorithmTest);
            this.grpTests.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpTests.Location = new System.Drawing.Point(12, 12);
            this.grpTests.Name = "grpTests";
            this.grpTests.Size = new System.Drawing.Size(700, 299);
            this.grpTests.TabIndex = 25;
            this.grpTests.TabStop = false;
            this.grpTests.Text = "RDX Algorithm Tests";
            // 
            // AesAvsKey
            // 
            this.AesAvsKey.AutoSize = true;
            this.AesAvsKey.Checked = true;
            this.AesAvsKey.CheckState = System.Windows.Forms.CheckState.Checked;
            this.AesAvsKey.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AesAvsKey.Location = new System.Drawing.Point(469, 36);
            this.AesAvsKey.Name = "AesAvsKey";
            this.AesAvsKey.Size = new System.Drawing.Size(151, 17);
            this.AesAvsKey.TabIndex = 98;
            this.AesAvsKey.Text = "NIST AESAVS Key Vectors";
            this.AesAvsKey.UseVisualStyleBackColor = true;
            // 
            // AesAvsText
            // 
            this.AesAvsText.AutoSize = true;
            this.AesAvsText.Checked = true;
            this.AesAvsText.CheckState = System.Windows.Forms.CheckState.Checked;
            this.AesAvsText.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AesAvsText.Location = new System.Drawing.Point(469, 57);
            this.AesAvsText.Name = "AesAvsText";
            this.AesAvsText.Size = new System.Drawing.Size(154, 17);
            this.AesAvsText.TabIndex = 97;
            this.AesAvsText.Text = "NIST AESAVS Text Vectors";
            this.AesAvsText.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(8, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 96;
            this.label2.Text = "Results:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(466, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 95;
            this.label1.Text = "Test Vectors:";
            // 
            // ModeEquality
            // 
            this.ModeEquality.AutoSize = true;
            this.ModeEquality.Checked = true;
            this.ModeEquality.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ModeEquality.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ModeEquality.Location = new System.Drawing.Point(469, 141);
            this.ModeEquality.Name = "ModeEquality";
            this.ModeEquality.Size = new System.Drawing.Size(110, 17);
            this.ModeEquality.TabIndex = 85;
            this.ModeEquality.Text = "CBC Equivalency";
            this.ModeEquality.UseVisualStyleBackColor = true;
            // 
            // IOTest
            // 
            this.IOTest.AutoSize = true;
            this.IOTest.Checked = true;
            this.IOTest.CheckState = System.Windows.Forms.CheckState.Checked;
            this.IOTest.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IOTest.Location = new System.Drawing.Point(469, 162);
            this.IOTest.Name = "IOTest";
            this.IOTest.Size = new System.Drawing.Size(70, 17);
            this.IOTest.TabIndex = 93;
            this.IOTest.Text = "I/O Tests";
            this.IOTest.UseVisualStyleBackColor = true;
            // 
            // AesVector
            // 
            this.AesVector.AutoSize = true;
            this.AesVector.Checked = true;
            this.AesVector.CheckState = System.Windows.Forms.CheckState.Checked;
            this.AesVector.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AesVector.Location = new System.Drawing.Point(469, 78);
            this.AesVector.Name = "AesVector";
            this.AesVector.Size = new System.Drawing.Size(165, 17);
            this.AesVector.TabIndex = 92;
            this.AesVector.Text = "AES Specification (FIPS 197)";
            this.AesVector.UseVisualStyleBackColor = true;
            // 
            // MonteCarlo
            // 
            this.MonteCarlo.AutoSize = true;
            this.MonteCarlo.Checked = true;
            this.MonteCarlo.CheckState = System.Windows.Forms.CheckState.Checked;
            this.MonteCarlo.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MonteCarlo.Location = new System.Drawing.Point(469, 99);
            this.MonteCarlo.Name = "MonteCarlo";
            this.MonteCarlo.Size = new System.Drawing.Size(167, 17);
            this.MonteCarlo.TabIndex = 91;
            this.MonteCarlo.Text = "AES Monte Carlo (Gladman)";
            this.MonteCarlo.UseVisualStyleBackColor = true;
            // 
            // RijndaelVector
            // 
            this.RijndaelVector.AutoSize = true;
            this.RijndaelVector.Checked = true;
            this.RijndaelVector.CheckState = System.Windows.Forms.CheckState.Checked;
            this.RijndaelVector.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RijndaelVector.Location = new System.Drawing.Point(469, 204);
            this.RijndaelVector.Name = "RijndaelVector";
            this.RijndaelVector.Size = new System.Drawing.Size(132, 17);
            this.RijndaelVector.TabIndex = 89;
            this.RijndaelVector.Text = "Rijndael Vector Tests";
            this.RijndaelVector.UseVisualStyleBackColor = true;
            // 
            // BlockEquality
            // 
            this.BlockEquality.AutoSize = true;
            this.BlockEquality.Checked = true;
            this.BlockEquality.CheckState = System.Windows.Forms.CheckState.Checked;
            this.BlockEquality.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BlockEquality.Location = new System.Drawing.Point(469, 120);
            this.BlockEquality.Name = "BlockEquality";
            this.BlockEquality.Size = new System.Drawing.Size(117, 17);
            this.BlockEquality.TabIndex = 88;
            this.BlockEquality.Text = "Block Equivalency";
            this.BlockEquality.UseVisualStyleBackColor = true;
            // 
            // SICVector
            // 
            this.SICVector.AutoSize = true;
            this.SICVector.Checked = true;
            this.SICVector.CheckState = System.Windows.Forms.CheckState.Checked;
            this.SICVector.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SICVector.Location = new System.Drawing.Point(469, 225);
            this.SICVector.Name = "SICVector";
            this.SICVector.Size = new System.Drawing.Size(162, 17);
            this.SICVector.TabIndex = 87;
            this.SICVector.Text = "SIC Counter (NIST 800-38A)";
            this.SICVector.UseVisualStyleBackColor = true;
            // 
            // PSCEquality
            // 
            this.PSCEquality.AutoSize = true;
            this.PSCEquality.Checked = true;
            this.PSCEquality.CheckState = System.Windows.Forms.CheckState.Checked;
            this.PSCEquality.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PSCEquality.Location = new System.Drawing.Point(469, 183);
            this.PSCEquality.Name = "PSCEquality";
            this.PSCEquality.Size = new System.Drawing.Size(108, 17);
            this.PSCEquality.TabIndex = 86;
            this.PSCEquality.Text = "PSC Equivalency";
            this.PSCEquality.UseVisualStyleBackColor = true;
            // 
            // btnAlgoTest
            // 
            this.btnAlgoTest.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlgoTest.Location = new System.Drawing.Point(611, 250);
            this.btnAlgoTest.Name = "btnAlgoTest";
            this.btnAlgoTest.Size = new System.Drawing.Size(72, 35);
            this.btnAlgoTest.TabIndex = 27;
            this.btnAlgoTest.Text = "Test";
            this.btnAlgoTest.UseVisualStyleBackColor = true;
            this.btnAlgoTest.Click += new System.EventHandler(this.OnAlgoTestClick);
            // 
            // lvAlgorithmTest
            // 
            this.lvAlgorithmTest.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.col1,
            this.col2,
            this.col3});
            this.lvAlgorithmTest.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvAlgorithmTest.FullRowSelect = true;
            this.lvAlgorithmTest.GridLines = true;
            this.lvAlgorithmTest.Location = new System.Drawing.Point(11, 38);
            this.lvAlgorithmTest.Name = "lvAlgorithmTest";
            this.lvAlgorithmTest.Size = new System.Drawing.Size(439, 200);
            this.lvAlgorithmTest.TabIndex = 1;
            this.lvAlgorithmTest.UseCompatibleStateImageBehavior = false;
            this.lvAlgorithmTest.View = System.Windows.Forms.View.Details;
            // 
            // col1
            // 
            this.col1.Text = "Test Name";
            this.col1.Width = 84;
            // 
            // col2
            // 
            this.col2.Text = "Description";
            this.col2.Width = 310;
            // 
            // col3
            // 
            this.col3.Text = "State";
            this.col3.Width = 41;
            // 
            // btnLogBrowse
            // 
            this.btnLogBrowse.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogBrowse.Location = new System.Drawing.Point(266, 76);
            this.btnLogBrowse.Name = "btnLogBrowse";
            this.btnLogBrowse.Size = new System.Drawing.Size(30, 30);
            this.btnLogBrowse.TabIndex = 100;
            this.btnLogBrowse.Text = "...";
            this.btnLogBrowse.UseVisualStyleBackColor = true;
            this.btnLogBrowse.Click += new System.EventHandler(this.OnLogBrowse);
            // 
            // txtLogFile
            // 
            this.txtLogFile.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLogFile.Location = new System.Drawing.Point(10, 82);
            this.txtLogFile.Name = "txtLogFile";
            this.txtLogFile.ReadOnly = true;
            this.txtLogFile.Size = new System.Drawing.Size(250, 22);
            this.txtLogFile.TabIndex = 101;
            this.txtLogFile.Text = "[Select an Output Folder]";
            // 
            // lblOutput
            // 
            this.lblOutput.AutoSize = true;
            this.lblOutput.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOutput.Location = new System.Drawing.Point(7, 41);
            this.lblOutput.Name = "lblOutput";
            this.lblOutput.Size = new System.Drawing.Size(45, 13);
            this.lblOutput.TabIndex = 99;
            this.lblOutput.Text = "Output:";
            this.lblOutput.Visible = false;
            // 
            // chkLogResults
            // 
            this.chkLogResults.AutoSize = true;
            this.chkLogResults.Checked = true;
            this.chkLogResults.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkLogResults.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkLogResults.Location = new System.Drawing.Point(10, 19);
            this.chkLogResults.Name = "chkLogResults";
            this.chkLogResults.Size = new System.Drawing.Size(85, 17);
            this.chkLogResults.TabIndex = 97;
            this.chkLogResults.Text = "Log Results";
            this.chkLogResults.UseVisualStyleBackColor = true;
            // 
            // rdLogFile
            // 
            this.rdLogFile.AutoSize = true;
            this.rdLogFile.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdLogFile.Location = new System.Drawing.Point(83, 57);
            this.rdLogFile.Name = "rdLogFile";
            this.rdLogFile.Size = new System.Drawing.Size(65, 17);
            this.rdLogFile.TabIndex = 96;
            this.rdLogFile.Text = "Log File";
            this.rdLogFile.UseVisualStyleBackColor = true;
            this.rdLogFile.Visible = false;
            this.rdLogFile.CheckedChanged += new System.EventHandler(this.OnLogTypeCheck);
            // 
            // rdLogConsole
            // 
            this.rdLogConsole.AutoSize = true;
            this.rdLogConsole.Checked = true;
            this.rdLogConsole.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdLogConsole.Location = new System.Drawing.Point(10, 57);
            this.rdLogConsole.Name = "rdLogConsole";
            this.rdLogConsole.Size = new System.Drawing.Size(67, 17);
            this.rdLogConsole.TabIndex = 95;
            this.rdLogConsole.TabStop = true;
            this.rdLogConsole.Text = "Console";
            this.rdLogConsole.UseVisualStyleBackColor = true;
            this.rdLogConsole.Visible = false;
            this.rdLogConsole.CheckedChanged += new System.EventHandler(this.OnLogTypeCheck);
            // 
            // grpLogging
            // 
            this.grpLogging.Controls.Add(this.btnLogBrowse);
            this.grpLogging.Controls.Add(this.chkLogResults);
            this.grpLogging.Controls.Add(this.txtLogFile);
            this.grpLogging.Controls.Add(this.rdLogConsole);
            this.grpLogging.Controls.Add(this.lblOutput);
            this.grpLogging.Controls.Add(this.rdLogFile);
            this.grpLogging.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpLogging.Location = new System.Drawing.Point(12, 317);
            this.grpLogging.Name = "grpLogging";
            this.grpLogging.Size = new System.Drawing.Size(309, 119);
            this.grpLogging.TabIndex = 26;
            this.grpLogging.TabStop = false;
            this.grpLogging.Text = "Logging";
            // 
            // grpSpeed
            // 
            this.grpSpeed.Controls.Add(this.btnSpeedTest);
            this.grpSpeed.Controls.Add(this.lblCompileWarning);
            this.grpSpeed.Controls.Add(this.lblSpeedHeader);
            this.grpSpeed.Controls.Add(this.txtSpeedIterations);
            this.grpSpeed.Controls.Add(this.txtSpeedBlocks);
            this.grpSpeed.Controls.Add(this.label15);
            this.grpSpeed.Controls.Add(this.label8);
            this.grpSpeed.Controls.Add(this.lblManagedTime);
            this.grpSpeed.Controls.Add(this.lblSpeedInfo);
            this.grpSpeed.Controls.Add(this.label13);
            this.grpSpeed.Controls.Add(this.lblRdxTime);
            this.grpSpeed.Controls.Add(this.label17);
            this.grpSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpSpeed.Location = new System.Drawing.Point(327, 317);
            this.grpSpeed.Name = "grpSpeed";
            this.grpSpeed.Size = new System.Drawing.Size(384, 119);
            this.grpSpeed.TabIndex = 27;
            this.grpSpeed.TabStop = false;
            this.grpSpeed.Text = "Speed Test";
            // 
            // btnSpeedTest
            // 
            this.btnSpeedTest.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSpeedTest.Location = new System.Drawing.Point(296, 71);
            this.btnSpeedTest.Name = "btnSpeedTest";
            this.btnSpeedTest.Size = new System.Drawing.Size(72, 35);
            this.btnSpeedTest.TabIndex = 43;
            this.btnSpeedTest.Text = "Test";
            this.btnSpeedTest.UseVisualStyleBackColor = true;
            this.btnSpeedTest.Click += new System.EventHandler(this.OnSpeedTestClick);
            // 
            // lblCompileWarning
            // 
            this.lblCompileWarning.AutoSize = true;
            this.lblCompileWarning.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompileWarning.Location = new System.Drawing.Point(197, 39);
            this.lblCompileWarning.Name = "lblCompileWarning";
            this.lblCompileWarning.Size = new System.Drawing.Size(184, 13);
            this.lblCompileWarning.TabIndex = 42;
            this.lblCompileWarning.Text = "(Compile in Release mode to test!)";
            this.lblCompileWarning.Visible = false;
            // 
            // lblSpeedHeader
            // 
            this.lblSpeedHeader.AutoSize = true;
            this.lblSpeedHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSpeedHeader.Location = new System.Drawing.Point(7, 16);
            this.lblSpeedHeader.Name = "lblSpeedHeader";
            this.lblSpeedHeader.Size = new System.Drawing.Size(120, 13);
            this.lblSpeedHeader.TabIndex = 41;
            this.lblSpeedHeader.Text = "Test 100 * 1000 Blocks";
            // 
            // txtSpeedIterations
            // 
            this.txtSpeedIterations.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSpeedIterations.Location = new System.Drawing.Point(64, 36);
            this.txtSpeedIterations.Name = "txtSpeedIterations";
            this.txtSpeedIterations.Size = new System.Drawing.Size(42, 22);
            this.txtSpeedIterations.TabIndex = 38;
            this.txtSpeedIterations.Text = "100";
            this.txtSpeedIterations.TextChanged += new System.EventHandler(this.OnTextBoxTextChanged);
            this.txtSpeedIterations.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.OnTextBoxKeyPress);
            // 
            // txtSpeedBlocks
            // 
            this.txtSpeedBlocks.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSpeedBlocks.Location = new System.Drawing.Point(154, 36);
            this.txtSpeedBlocks.Name = "txtSpeedBlocks";
            this.txtSpeedBlocks.Size = new System.Drawing.Size(42, 22);
            this.txtSpeedBlocks.TabIndex = 37;
            this.txtSpeedBlocks.Text = "1000";
            this.txtSpeedBlocks.TextChanged += new System.EventHandler(this.OnTextBoxTextChanged);
            this.txtSpeedBlocks.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.OnTextBoxKeyPress);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(7, 39);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(58, 13);
            this.label15.TabIndex = 40;
            this.label15.Text = "Iterations:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(113, 39);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 13);
            this.label8.TabIndex = 39;
            this.label8.Text = "Blocks:";
            // 
            // lblManagedTime
            // 
            this.lblManagedTime.AutoSize = true;
            this.lblManagedTime.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblManagedTime.Location = new System.Drawing.Point(102, 99);
            this.lblManagedTime.Name = "lblManagedTime";
            this.lblManagedTime.Size = new System.Drawing.Size(22, 13);
            this.lblManagedTime.TabIndex = 36;
            this.lblManagedTime.Text = "0.0";
            // 
            // lblSpeedInfo
            // 
            this.lblSpeedInfo.AutoSize = true;
            this.lblSpeedInfo.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSpeedInfo.Location = new System.Drawing.Point(7, 64);
            this.lblSpeedInfo.Name = "lblSpeedInfo";
            this.lblSpeedInfo.Size = new System.Drawing.Size(186, 13);
            this.lblSpeedInfo.TabIndex = 32;
            this.lblSpeedInfo.Text = "Encrypt/Decrypt: 100 * 16000 bytes";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(7, 99);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(63, 13);
            this.label13.TabIndex = 35;
            this.label13.Text = "Managed: ";
            // 
            // lblRdxTime
            // 
            this.lblRdxTime.AutoSize = true;
            this.lblRdxTime.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRdxTime.Location = new System.Drawing.Point(102, 81);
            this.lblRdxTime.Name = "lblRdxTime";
            this.lblRdxTime.Size = new System.Drawing.Size(22, 13);
            this.lblRdxTime.TabIndex = 34;
            this.lblRdxTime.Text = "0.0";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(7, 81);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 13);
            this.label17.TabIndex = 33;
            this.label17.Text = "RDX: ";
            // 
            // lblTestStatus
            // 
            this.lblTestStatus.AutoSize = true;
            this.lblTestStatus.Location = new System.Drawing.Point(122, 455);
            this.lblTestStatus.Name = "lblTestStatus";
            this.lblTestStatus.Size = new System.Drawing.Size(57, 13);
            this.lblTestStatus.TabIndex = 30;
            this.lblTestStatus.Text = "Waiting...";
            // 
            // pbTestStatus
            // 
            this.pbTestStatus.Location = new System.Drawing.Point(9, 453);
            this.pbTestStatus.Name = "pbTestStatus";
            this.pbTestStatus.Size = new System.Drawing.Size(108, 16);
            this.pbTestStatus.TabIndex = 29;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 450);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(724, 22);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 28;
            // 
            // lblCompare
            // 
            this.lblCompare.AutoSize = true;
            this.lblCompare.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompare.Location = new System.Drawing.Point(328, 455);
            this.lblCompare.Name = "lblCompare";
            this.lblCompare.Size = new System.Drawing.Size(16, 13);
            this.lblCompare.TabIndex = 44;
            this.lblCompare.Text = "...";
            // 
            // FormTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(724, 472);
            this.Controls.Add(this.lblCompare);
            this.Controls.Add(this.lblTestStatus);
            this.Controls.Add(this.pbTestStatus);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.grpSpeed);
            this.Controls.Add(this.grpLogging);
            this.Controls.Add(this.grpTests);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(740, 519);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(740, 519);
            this.Name = "FormTest";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RDX Tests";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.OnFormClose);
            this.Load += new System.EventHandler(this.OnFormLoad);
            this.grpTests.ResumeLayout(false);
            this.grpTests.PerformLayout();
            this.grpLogging.ResumeLayout(false);
            this.grpLogging.PerformLayout();
            this.grpSpeed.ResumeLayout(false);
            this.grpSpeed.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpTests;
        private System.Windows.Forms.Button btnLogBrowse;
        private System.Windows.Forms.TextBox txtLogFile;
        private System.Windows.Forms.Label lblOutput;
        private System.Windows.Forms.CheckBox chkLogResults;
        private System.Windows.Forms.RadioButton rdLogFile;
        private System.Windows.Forms.RadioButton rdLogConsole;
        private System.Windows.Forms.Button btnAlgoTest;
        private System.Windows.Forms.ListView lvAlgorithmTest;
        private System.Windows.Forms.ColumnHeader col1;
        private System.Windows.Forms.ColumnHeader col2;
        private System.Windows.Forms.ColumnHeader col3;
        private System.Windows.Forms.GroupBox grpLogging;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grpSpeed;
        private System.Windows.Forms.Button btnSpeedTest;
        private System.Windows.Forms.Label lblCompileWarning;
        private System.Windows.Forms.Label lblSpeedHeader;
        private System.Windows.Forms.TextBox txtSpeedIterations;
        private System.Windows.Forms.TextBox txtSpeedBlocks;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblManagedTime;
        private System.Windows.Forms.Label lblSpeedInfo;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblRdxTime;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblTestStatus;
        private System.Windows.Forms.ProgressBar pbTestStatus;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.CheckBox ModeEquality;
        private System.Windows.Forms.CheckBox IOTest;
        private System.Windows.Forms.CheckBox AesVector;
        private System.Windows.Forms.CheckBox MonteCarlo;
        private System.Windows.Forms.CheckBox RijndaelVector;
        private System.Windows.Forms.CheckBox BlockEquality;
        private System.Windows.Forms.CheckBox SICVector;
        private System.Windows.Forms.CheckBox PSCEquality;
        private System.Windows.Forms.Label lblCompare;
        private System.Windows.Forms.CheckBox AesAvsKey;
        private System.Windows.Forms.CheckBox AesAvsText;
    }
}