﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Windows.Forms;
using VTDev.Projects.CEX.Helpers;
using VTDev.Projects.CEX.Tests;

namespace VTDev.Projects.CEX
{
    public partial class FormTest : Form
    {
        #region Constants
        private const string LOG_DEF = "[Select an Output Folder]";
        private const string LOG_DES = "Select an Output Folder";
        #endregion

        #region Properties
        private string OutputDirectory { get; set; }
        private int TestCount { get; set; }
        #endregion

        #region Fields
        private BackgroundWorker _analysisWorker = new BackgroundWorker();
        private BackgroundWorker _speedWorker = new BackgroundWorker();
        private Dictionary<string, string> _testResults = new Dictionary<string, string>();
        private static string _rdxTime = "";
        private static string _mngTime = "";
        private static string _engCompare = "";
        private static int _speedBlocks = 1000;
        private static int _speedIterations = 100;
        private const int TEST_BLOCKS = 1000000;
        #endregion

        #region Constructor
        public FormTest()
        {
            InitializeComponent();
        }
        #endregion

        #region Helpers
        private void AnalysisToLog()
        {
            if (_testResults.Count > 0)
                Logger.LogSession();

            // put the values to list
            foreach (var val in _testResults)
            {
                string[] sub = val.Value.Split(',');

                if (sub.Length > 1)
                    Logger.LogResult(val.Key, sub[0], sub[1]);
            }
        }

        private void EnabledState(bool State)
        {
            grpTests.Enabled = State;
            grpLogging.Enabled = State;
            grpSpeed.Enabled = State;
        }

        private string GetFolderPath(string Description)
        {
            using (FolderBrowserDialog folderDialog = new FolderBrowserDialog())
            {
                folderDialog.Description = Description;
                folderDialog.ShowNewFolderButton = true;
                folderDialog.SelectedPath = this.OutputDirectory;

                if (folderDialog.ShowDialog() == DialogResult.OK)
                {
                    string path = folderDialog.SelectedPath;

                    if (Utilities.DirectoryHasPermission(path, System.Security.AccessControl.FileSystemRights.CreateFiles))
                        return path;
                }
            }

            return string.Empty;
        }

        private int GetTestCount()
        {
            int count = 0;

            foreach (object obj in ((Control)grpTests).Controls)
            {
                if (obj.GetType().Equals(typeof(CheckBox)))
                {
                    CheckBox chk = obj as CheckBox;

                    if (chk.Checked && chk.Enabled)
                        count++;
                }
            }

            return count;
        }

        private void SetTestParams()
        {
            this.TestCount = 0;

            foreach (object obj in ((Control)grpTests).Controls)
            {
                if (obj.GetType().Equals(typeof(CheckBox)))
                {
                    CheckBox chk = obj as CheckBox;

                    if (chk.Checked && chk.Enabled)
                        this.TestCount++;

                    // checkbox name is a member name
                    Test.Tests test = (Test.Tests)Enum.Parse(typeof(Test.Tests), chk.Name);
                    Test.ParametersKey[test] = chk.Checked && chk.Enabled;
                }
            }
        }
        #endregion

        #region Event Handlers
        private void OnAlgoTestClick(object sender, EventArgs e)
        {
            RunSpecTests();
        }

        private void OnFormClose(object sender, FormClosedEventArgs e)
        {
            _analysisWorker.Dispose();
            _speedWorker.Dispose();
        }

        private void OnFormLoad(object sender, EventArgs e)
        {
            // compile it in release mode or test is useless (.Net crypto is already compiled)!
            if (System.Diagnostics.Debugger.IsAttached)
            {
                btnSpeedTest.Enabled = false;
                lblCompileWarning.Visible = true;
                rdLogFile.Checked = true;
                rdLogConsole.Visible = true;
                rdLogFile.Visible = true;
                lblOutput.Visible = true;
            }

            txtLogFile.Text = Logger.LogPath;
            txtSpeedIterations.LostFocus += new EventHandler(OnTextBoxLostFocus);
            txtSpeedBlocks.LostFocus += new EventHandler(OnTextBoxLostFocus);

            // init the background threads
            _analysisWorker.DoWork += OnAnalysisDoWork;
            _analysisWorker.RunWorkerCompleted += OnAnalysisWorkCompleted;
            _speedWorker.DoWork += OnSpeedDoWork;
            _speedWorker.RunWorkerCompleted += OnSpeedWorkCompleted;
        }

        private void OnLogBrowse(object sender, EventArgs e)
        {
            string path = GetFolderPath(LOG_DES);

            if (!string.IsNullOrEmpty(path) && !path.Equals(LOG_DEF))
            {
                this.OutputDirectory = Path.Combine(path, Logger.LogName);
                Logger.LogPath = this.OutputDirectory;
                txtLogFile.Text = this.OutputDirectory;
            }
        }

        private void OnLogTypeCheck(object sender, EventArgs e)
        {
            RadioButton rd = sender as RadioButton;
            if (rd.Checked == false) return;

            if (rd.Name == "rdLogConsole")
                Logger.LogOutput = Logger.LogTypes.Console;
            else
                Logger.LogOutput = Logger.LogTypes.LogFile;
        }

        private void OnProgressChanged(int count, string message)
        {
            if (this.IsHandleCreated)
            {
                pbTestStatus.Invoke(new MethodInvoker(delegate { pbTestStatus.Value = (pbTestStatus.Value == pbTestStatus.Maximum) ? 0 : pbTestStatus.Value + 1; }));
                lblTestStatus.Invoke(new MethodInvoker(delegate { lblTestStatus.Text = message; }));
            }
        }

        private void OnSpeedTestClick(object sender, EventArgs e)
        {
            // run
            RunSpeedTests();
        }

        private void OnTextBoxKeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar) || e.KeyChar == '\b')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void OnTextBoxLostFocus(object sender, EventArgs e)
        {
            TextBox tb = sender as TextBox;

            if (tb.Name == "txtSpeedIterations")
            {
                if (string.IsNullOrEmpty(tb.Text))
                {
                    tb.Text = "10";
                }
                else
                {
                    int size = 10;
                    int.TryParse(tb.Text, out size);

                    if (size == 0)
                    {
                        tb.Text = "10";
                    }
                }
            }
            else
            {
                if (string.IsNullOrEmpty(tb.Text))
                {
                    tb.Text = "1000";
                }
                else
                {
                    int size = 1000;
                    int.TryParse(tb.Text, out size);

                    if (size == 0)
                    {
                        tb.Text = "1000";
                    }
                }
            }
        }

        private void OnTextBoxTextChanged(object sender, EventArgs e)
        {
            TextBox tb = sender as TextBox;

            if (tb.Name == "txtSpeedIterations")
            {
                if (tb.Text.Length > 4)
                    tb.Text = "1000";
            }
            else
            {
                if (tb.Text.Length > 6)
                    tb.Text = "100000";
            }
            int size = 100;
            int.TryParse(tb.Text, out size);
            if (size == 0)
                size = 100;

            lblSpeedHeader.Text = "Test " + txtSpeedIterations.Text + " * " + txtSpeedBlocks.Text + " Blocks (Compile as Release for actual time)";
            lblSpeedInfo.Text = "Encrypt/Decrypt: " + txtSpeedIterations.Text + " * " + (size * 16).ToString() + " bytes";
        }
        #endregion

        #region Threaded Response
        private void OnAnalysisDoWork(object sender, DoWorkEventArgs e)
        {
            // run
            _testResults = Test.Run();
        }

        private void OnAnalysisWorkCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // return ui
            EnabledState(true);
            pbTestStatus.Value = pbTestStatus.Maximum;

            // whoops
            if (_testResults.Count < 1)
            {
                lblTestStatus.Text = "The test Failed!";
                return;
            }

            // put the values to list
            foreach (var val in _testResults)
            {
                ListViewItem item = new ListViewItem(val.Key);
                string[] sub = val.Value.Split(',');

                if (sub.Length > 1)
                {
                    item.SubItems.Add(sub[0]);
                    item.SubItems.Add(sub[1]);
                    lvAlgorithmTest.Items.Add(item);
                }
            }

            // yay!
            lblTestStatus.Text = "Test Complete!";

            if (chkLogResults.Checked)
                AnalysisToLog();
        }

        private void OnSpeedDoWork(object sender, DoWorkEventArgs e)
        {
            _rdxTime = Tests.Test.SpeedTest(Tests.AesImplementations.RDX, _speedBlocks, _speedIterations);
            _mngTime = Tests.Test.SpeedTest(Tests.AesImplementations.Managed, _speedBlocks, _speedIterations);

            // Compares RDX, Mono, and Bouncy Castle's AESFastEngine
            _engCompare = "Bouncy: " + Tests.Test.EngineTest(AesEngines.Bouncy, TEST_BLOCKS) +
                " Mono: " + Tests.Test.EngineTest(AesEngines.Mono, TEST_BLOCKS) +
                " RDX: " + Tests.Test.EngineTest(AesEngines.RDXB, TEST_BLOCKS);

            // compares 4 different RDX engine variations
            /*_engCompare = "A: " + Tests.Test.EngineTest(AesEngines.RDXA, TEST_BLOCKS) +
                " B: " + Tests.Test.EngineTest(AesEngines.RDXB, TEST_BLOCKS) +
                " C: " + Tests.Test.EngineTest(AesEngines.RDXC, TEST_BLOCKS) +
                " D: " + Tests.Test.EngineTest(AesEngines.RDXD, TEST_BLOCKS);*/
        }

        private void OnSpeedWorkCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            EnabledState(true);
            lblRdxTime.Text = _rdxTime;
            lblManagedTime.Text = _mngTime;
            lblCompare.Text = _engCompare;
        }
        #endregion

        #region Tests
        private void RunSpecTests()
        {
            this.TestCount = GetTestCount();

            if (this.TestCount == 0)
            {
                MessageBox.Show("There are no tests selected!");
                return;
            }

            // get the tests
            SetTestParams();
            // clear old data
            _testResults.Clear();
            // clear lv
            lvAlgorithmTest.Items.Clear();
            // setup progress
            Test.ProgressChanged -= OnProgressChanged;
            Test.ProgressChanged += new Action<int, string>(OnProgressChanged);
            this.TestCount = GetTestCount();
            pbTestStatus.Maximum = this.TestCount;
            // disable ui
            EnabledState(false);
            // run
            _analysisWorker.RunWorkerAsync();
        }

        private void RunSpeedTests()
        {
            // disable ui
            EnabledState(false);

            int.TryParse(txtSpeedBlocks.Text, out _speedBlocks);
            if (_speedBlocks == 0)
            {
                MessageBox.Show("Number of Blocks can not be 0!");
                return;
            }

            int.TryParse(txtSpeedIterations.Text, out _speedIterations);
            if (_speedIterations == 0)
            {
                MessageBox.Show("Number of Iterations can not be 0!");
                return;
            }

            // run
            _speedWorker.RunWorkerAsync();
        }
        #endregion
    }
}
