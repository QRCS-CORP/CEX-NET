﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Windows.Forms;
using VTDev.Projects.CEX.Helpers;
using VTDev.Projects.CEX.Tests;

namespace VTDev.Projects.CEX
{
    public partial class FormTest : Form
    {
        #region Constants
        private const string LOG_DEF = "[Select an Output Folder]";
        private const string LOG_DES = "Select an Output Folder";
        #endregion

        #region Properties
        private Engines Engine { get; set; }
        private string OutputDirectory { get; set; }
        private int TestCount { get; set; }
        #endregion

        #region Fields
        private BackgroundWorker _analysisWorker = new BackgroundWorker();
        private BackgroundWorker _speedWorker = new BackgroundWorker();
        private Dictionary<string, string> _testResults = new Dictionary<string, string>();
        private static string _engTime = "";
        private static int _sizeMB = 1;
        #endregion

        #region Constructor
        public FormTest()
        {
            InitializeComponent();
        }
        #endregion

        #region Helpers
        private void AnalysisToLog()
        {
            if (_testResults.Count > 0)
                Logger.LogSession();

            // put the values to list
            foreach (var val in _testResults)
            {
                string[] sub = val.Value.Split(',');

                if (sub.Length > 1)
                    Logger.LogResult(val.Key, sub[0], sub[1]);
            }
        }

        private void EnabledState(bool State)
        {
            grpTests.Enabled = State;
            grpSpeed.Enabled = State;
            grpLogging.Enabled = State;
        }

        private string GetFolderPath(string Description)
        {
            using (FolderBrowserDialog folderDialog = new FolderBrowserDialog())
            {
                folderDialog.Description = Description;
                folderDialog.ShowNewFolderButton = true;
                folderDialog.SelectedPath = this.OutputDirectory;

                if (folderDialog.ShowDialog() == DialogResult.OK)
                {
                    string path = folderDialog.SelectedPath;

                    if (Utilities.DirectoryHasPermission(path, System.Security.AccessControl.FileSystemRights.CreateFiles))
                        return path;
                }
            }

            return string.Empty;
        }

        private int GetTestCount()
        {
            int count = 0;

            foreach (object obj in ((Control)grpTests).Controls)
            {
                if (obj.GetType().Equals(typeof(CheckBox)))
                {
                    CheckBox chk = obj as CheckBox;

                    if (chk.Checked && chk.Enabled)
                        count++;
                }
            }

            return count;
        }

        private void SetTestParams()
        {
            this.TestCount = 0;

            foreach (object obj in ((Control)grpTests).Controls)
            {
                if (obj.GetType().Equals(typeof(CheckBox)))
                {
                    CheckBox chk = obj as CheckBox;

                    if (chk.Checked && chk.Enabled)
                        this.TestCount++;

                    // checkbox name is a member name
                    Test.Tests test = (Test.Tests)Enum.Parse(typeof(Test.Tests), chk.Name);
                    Test.ParametersKey[test] = chk.Checked && chk.Enabled;
                }
            }
        }
        #endregion

        #region Event Handlers
        private void OnAlgoTestClick(object sender, EventArgs e)
        {
            RunSpecTests();
        }

        private void OnEngineCheckChanged(object sender, EventArgs e)
        {
            RadioButton rd = sender as RadioButton;

            if (rd.Checked == false) return;

            if (rd.Name == "rdChaCha20")
                Engine = Engines.ChaCha;
            else if (rd.Name == "rdDCS")
                Engine = Engines.DCS;
            else if (rd.Name == "rdRDX")
                Engine = Engines.RDX;
            else if (rd.Name == "rdRHX")
                Engine = Engines.RHX;
            else if (rd.Name == "rdRSX")
                Engine = Engines.RSX;
            else if (rd.Name == "rdSalsa20")
                Engine = Engines.Salsa;
            else if (rd.Name == "rdSHX")
                Engine = Engines.SHX;
            else if (rd.Name == "rdSPX")
                Engine = Engines.SPX;
        }
        
        private void OnFormClose(object sender, FormClosedEventArgs e)
        {
            _analysisWorker.Dispose();
            _speedWorker.Dispose();
        }

        private void OnFormLoad(object sender, EventArgs e)
        {
            // compile it in release mode or test is pointless..
            if (System.Diagnostics.Debugger.IsAttached)
            {
               // btnSpeedTest.Enabled = false;
                lblCompileWarning.Visible = true;
                rdLogFile.Checked = true;
                rdLogConsole.Visible = true;
                rdLogFile.Visible = true;
                lblOutput.Visible = true;
            }

            txtLogFile.Text = Logger.LogPath;
            txtSizeMB.LostFocus += new EventHandler(OnTextBoxLostFocus);

            // init the background threads
            _analysisWorker.DoWork += OnAnalysisDoWork;
            _analysisWorker.RunWorkerCompleted += OnAnalysisWorkCompleted;
            _speedWorker.DoWork += OnSpeedDoWork;
            _speedWorker.RunWorkerCompleted += OnSpeedWorkCompleted;
        }

        private void OnLogBrowse(object sender, EventArgs e)
        {
            string path = GetFolderPath(LOG_DES);

            if (!string.IsNullOrEmpty(path) && !path.Equals(LOG_DEF))
            {
                this.OutputDirectory = Path.Combine(path, Logger.LogName);
                Logger.LogPath = this.OutputDirectory;
                txtLogFile.Text = this.OutputDirectory;
            }
        }

        private void OnLogTypeCheck(object sender, EventArgs e)
        {
            RadioButton rd = sender as RadioButton;
            if (rd.Checked == false) return;

            if (rd.Name == "rdLogConsole")
                Logger.LogOutput = Logger.LogTypes.Console;
            else
                Logger.LogOutput = Logger.LogTypes.LogFile;
        }

        private void OnProgressChanged(int count, string message)
        {
            if (this.IsHandleCreated)
            {
                pbTestStatus.Invoke(new MethodInvoker(delegate { pbTestStatus.Value = (pbTestStatus.Value == pbTestStatus.Maximum) ? 0 : pbTestStatus.Value + 1; }));
                lblTestStatus.Invoke(new MethodInvoker(delegate { lblTestStatus.Text = message; }));
            }
        }

        private void OnSpeedTestClick(object sender, EventArgs e)
        {
            // run
            RunSpeedTest();
        }

        private void OnTextChanged(object sender, EventArgs e)
        {
            TextBox tb = sender as TextBox;
            int size = 10;
            int.TryParse(tb.Text, out size);

            if (size > 100)
                tb.Text = "100";
        }

        private void OnTextBoxKeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox tb = sender as TextBox;

            if (Char.IsDigit(e.KeyChar) || e.KeyChar == '\b')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void OnTextBoxLostFocus(object sender, EventArgs e)
        {
            TextBox tb = sender as TextBox;

            if (tb.Name == "txtSizeMB")
            {
                if (string.IsNullOrEmpty(tb.Text))
                {
                    tb.Text = "1";
                }
                else
                {
                    int size = 10;
                    int.TryParse(tb.Text, out size);

                    if (size == 0)
                        tb.Text = "1";
                    else if (size > 100)
                        tb.Text = "100";
                }
            }
        }
        #endregion

        #region Threaded Response
        private void OnAnalysisDoWork(object sender, DoWorkEventArgs e)
        {
            // run
            _testResults = Test.Run();
        }

        private void OnAnalysisWorkCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // return ui
            EnabledState(true);
            pbTestStatus.Value = pbTestStatus.Maximum;

            // whoops
            if (_testResults.Count < 1)
            {
                lblTestStatus.Text = "The test Failed!";
                return;
            }

            // put the values to list
            foreach (var val in _testResults)
            {
                ListViewItem item = new ListViewItem(val.Key);
                string[] sub = val.Value.Split(',');

                if (sub.Length > 1)
                {
                    item.SubItems.Add(sub[0]);
                    item.SubItems.Add(sub[1]);
                    lvAlgorithmTest.Items.Add(item);
                }
            }

            // yay!
            lblTestStatus.Text = "Test Complete!";

            if (chkLogResults.Checked)
                AnalysisToLog();
        }

        private void OnSpeedDoWork(object sender, DoWorkEventArgs e)
        {
            _engTime = Tests.Test.SpeedTest(this.Engine, _sizeMB);
        }

        private void OnSpeedWorkCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            EnabledState(true);
            lblEngineTime.Text = _engTime;
        }
        #endregion

        #region Tests
        private void RunSpecTests()
        {
            this.TestCount = GetTestCount();

            if (this.TestCount == 0)
            {
                MessageBox.Show("There are no tests selected!");
                return;
            }

            // get the tests
            SetTestParams();
            // clear old data
            _testResults.Clear();
            // clear lv
            lvAlgorithmTest.Items.Clear();
            // setup progress
            Test.ProgressChanged -= OnProgressChanged;
            Test.ProgressChanged += new Action<int, string>(OnProgressChanged);
            this.TestCount = GetTestCount();
            pbTestStatus.Maximum = this.TestCount;
            // disable ui
            EnabledState(false);
            // run
            _analysisWorker.RunWorkerAsync();
        }

        private void RunSpeedTest()
        {
            const int MIB = 1024000;

            // disable ui
            EnabledState(false);

            int.TryParse(txtSizeMB.Text, out _sizeMB);
            if (_sizeMB == 0)
            {
                MessageBox.Show("Size can not be 0!");
                return;
            }
            _sizeMB = _sizeMB * MIB;

            // run
            _speedWorker.RunWorkerAsync();
        }
        #endregion
    }
}
