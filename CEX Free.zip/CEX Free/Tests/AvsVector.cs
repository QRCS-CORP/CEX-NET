﻿using System;
using VTDev.Projects.CEX.CryptoGraphic;
using VTDev.Projects.CEX.CryptoGraphic.Helpers;
using VTDev.Projects.CEX.Helpers;

namespace VTDev.Projects.CEX.Tests
{
    /// <summary>
    /// NIST AESAVS Vectors, 960 total
    /// </summary>
    class AvsVector
    {
        #region Public
        /// <summary>
        /// NIST AESAVS Vectors, 960 tests total
        /// </summary>
        /// <param name="VectorSize">Vector size</param>
        /// <param name="TestType">Test type</param>
        /// <returns>Success [bool]</returns>
        internal bool Test(AvsVectors VectorSize, AvsTests TestType)
        {
            byte[] plainText = Hex.Decode("00000000000000000000000000000000");
            byte[] key;
            byte[] cipherText;

            try
            {
                if (TestType == AvsTests.Key)
                {
                    if (VectorSize == AvsVectors.V128)
                    {
                        string data = VTDev.Projects.CEX.Properties.Resources.keyvect128;
                        
                        for (int i = 0, j = 32; i < data.Length; i += 64, j += 64)
                        {
                            key = Hex.Decode(data.Substring(i, 32));
                            cipherText = Hex.Decode(data.Substring(j, 32));

                            PerformTest(key, plainText, cipherText);
                        }
                    }
                    else if (VectorSize == AvsVectors.V192)
                    {
                        string data = VTDev.Projects.CEX.Properties.Resources.keyvect192;

                        for (int i = 0, j = 48; i < data.Length; i += 80, j += 80)
                        {
                            key = Hex.Decode(data.Substring(i, 48));
                            cipherText = Hex.Decode(data.Substring(j, 32));

                            PerformTest(key, plainText, cipherText);
                        }
                    }
                    else
                    {
                        string data = VTDev.Projects.CEX.Properties.Resources.keyvect256;

                        for (int i = 0, j = 64; i < data.Length; i += 96, j += 96)
                        {
                            key = Hex.Decode(data.Substring(i, 64));
                            cipherText = Hex.Decode(data.Substring(j, 32));

                            PerformTest(key, plainText, cipherText);
                        }
                    }
                }
                else
                {
                    if (VectorSize == AvsVectors.V128)
                    {
                        key = Hex.Decode("00000000000000000000000000000000");
                        string data = VTDev.Projects.CEX.Properties.Resources.plainvect128;

                        for (int i = 0, j = 32; i < data.Length; i += 64, j += 64)
                        {
                            plainText = Hex.Decode(data.Substring(i, 32));
                            cipherText = Hex.Decode(data.Substring(j, 32));

                            PerformTest(key, plainText, cipherText);
                        }
                    }
                    else if (VectorSize == AvsVectors.V192)
                    {
                        key = Hex.Decode("000000000000000000000000000000000000000000000000");
                        string data = VTDev.Projects.CEX.Properties.Resources.plainvect192;

                        for (int i = 0, j = 32; i < data.Length; i += 64, j += 64)
                        {
                            plainText = Hex.Decode(data.Substring(i, 32));
                            cipherText = Hex.Decode(data.Substring(j, 32));

                            PerformTest(key, plainText, cipherText);
                        }
                    }
                    else
                    {
                        key = Hex.Decode("0000000000000000000000000000000000000000000000000000000000000000");
                        string data = VTDev.Projects.CEX.Properties.Resources.plainvect256;

                        for (int i = 0, j = 32; i < data.Length; i += 64, j += 64)
                        {
                            plainText = Hex.Decode(data.Substring(i, 32));
                            cipherText = Hex.Decode(data.Substring(j, 32));

                            PerformTest(key, plainText, cipherText);
                        }
                    }
                }

               // PerformTest();
                return true;
            }
            catch (Exception Ex)
            {
                string message = Ex.Message == null ? "" : Ex.Message;
                Logger.LogError("AvsKey", message, Ex);
                return false;
            }
        }
        #endregion

        #region Helpers
        private void PerformTest(byte[] Key, byte[] Input, byte[] Output)
        {
            using (RDX engine = new RDX())
            {
                byte[] outBytes = new byte[Input.Length];
                engine.Init(true, Key);
                engine.Transform(Input, outBytes);

                if (Compare.AreEqual(outBytes, Output) == false)
                    throw new Exception("AVSVector: Encrypted arrays are not equal!");
            }
        }
        #endregion
    }
}
