﻿using System;
using System.Diagnostics;
using System.IO;
using VTDev.Projects.CEX.Crypto;
using VTDev.Projects.CEX.Crypto.Ciphers;
using VTDev.Projects.CEX.Crypto.Helpers;
using VTDev.Projects.CEX.Crypto.Modes;

namespace VTDev.Projects.CEX.Tests
{
    public class EngineSpeed : ISpeedTest
    {
        #region Properties
        /// <summary>
        /// Implemntation engine
        /// </summary>
        public Engines Engine { get; set; }
        /// <summary>
        /// Sample file size
        /// </summary>
        public int FileSize { get; set; }
        #endregion

        #region Constructor
        public EngineSpeed(Engines Engine, int FileSize)
        {
            this.Engine = Engine;
            this.FileSize = FileSize;
        }
        #endregion

        #region Public
        /// <summary>
        /// Get time elapsed to encrypt a file
        /// </summary>
        /// <returns>Elapsed milliseconds [string]</returns>
        public string Test()
        {
            string ft = @"m\:ss\.ff";
            string inputPath = FileGetTemp();
            string outputPath = FileGetTemp();
            Stopwatch runTimer = new Stopwatch();

            CreateFile(inputPath);

            if (!File.Exists(inputPath))
                return "File could not be created!";

            KeyParams keyparam = GetParams();

            runTimer.Start();

            PerformTest(keyparam, inputPath, outputPath);

            runTimer.Stop();
            TimeSpan t1 = TimeSpan.FromMilliseconds(runTimer.Elapsed.TotalMilliseconds);

            DestroyFile(inputPath);
            DestroyFile(outputPath);

            return t1.ToString(ft);
        }
        #endregion

        #region Tests
        private void PerformTest(KeyParams KeyParam, string InputPath, string OututPath)
        {
            if (this.Engine == Engines.ChaCha)
                ChaChaTest(KeyParam, InputPath, OututPath);
            else if (this.Engine == Engines.DCS)
                DCSTest(KeyParam, InputPath, OututPath);
            else if (this.Engine == Engines.RDX)
                RDXTest(KeyParam, InputPath, OututPath);
            else if (this.Engine == Engines.RHX)
                RHXTest(KeyParam, InputPath, OututPath);
            else if (this.Engine == Engines.RSX)
                RSXTest(KeyParam, InputPath, OututPath);
            else if (this.Engine == Engines.Salsa)
                SalsaTest(KeyParam, InputPath, OututPath);
            else if (this.Engine == Engines.SHX)
                SHXTest(KeyParam, InputPath, OututPath);
            else if (this.Engine == Engines.SPX)
                SPXTest(KeyParam, InputPath, OututPath);
        }

        private void ChaChaTest(KeyParams KeyParam, string InputPath, string OutputPath)
        {
            using (BinaryReader inputReader = new BinaryReader(new FileStream(InputPath, FileMode.Open, FileAccess.Read, FileShare.None)))
            {
                byte[] inputBuffer = new byte[64];
                byte[] outputBuffer = new byte[64];
                long bytesRead = 0;

                using (BinaryWriter outputWriter = new BinaryWriter(new FileStream(OutputPath, FileMode.Create, FileAccess.Write, FileShare.None)))
                {
                    using (ChaCha enc = new ChaCha())
                    {
                        enc.Init(KeyParam);
                        while ((bytesRead = inputReader.Read(inputBuffer, 0, 64)) > 0)
                        {
                            enc.Transform(inputBuffer, outputBuffer);
                            outputWriter.Write(outputBuffer);
                        }
                    }
                }
            }
        }

        private void DCSTest(KeyParams KeyParam, string InputPath, string OutputPath)
        {
            using (BinaryReader inputReader = new BinaryReader(new FileStream(InputPath, FileMode.Open, FileAccess.Read, FileShare.None)))
            {
                byte[] inputBuffer = new byte[16];
                byte[] outputBuffer = new byte[16];
                long bytesRead = 0;

                using (BinaryWriter outputWriter = new BinaryWriter(new FileStream(OutputPath, FileMode.Create, FileAccess.Write, FileShare.None)))
                {
                    using (DCS enc = new DCS())
                    {
                        enc.Init(KeyParam);
                        while ((bytesRead = inputReader.Read(inputBuffer, 0, 16)) > 0)
                        {
                            enc.Transform(inputBuffer, outputBuffer);
                            outputWriter.Write(outputBuffer);
                        }
                    }
                }
            }
        }

        private void RDXTest(KeyParams KeyParam, string InputPath, string OutputPath)
        {
            using (BinaryReader inputReader = new BinaryReader(new FileStream(InputPath, FileMode.Open, FileAccess.Read, FileShare.None)))
            {
                byte[] inputBuffer = new byte[16];
                byte[] outputBuffer = new byte[16];
                long bytesRead = 0;

                using (BinaryWriter outputWriter = new BinaryWriter(new FileStream(OutputPath, FileMode.Create, FileAccess.Write, FileShare.None)))
                {
                    using (CTR enc = new CTR(new RDX()))
                    {
                        enc.Init(true, KeyParam);
                        while ((bytesRead = inputReader.Read(inputBuffer, 0, 16)) > 0)
                        {
                            enc.Transform(inputBuffer, outputBuffer);
                            outputWriter.Write(outputBuffer);
                        }
                    }
                }
            }
        }

        private void RHXTest(KeyParams KeyParam, string InputPath, string OutputPath)
        {
            using (BinaryReader inputReader = new BinaryReader(new FileStream(InputPath, FileMode.Open, FileAccess.Read, FileShare.None)))
            {
                byte[] inputBuffer = new byte[16];
                byte[] outputBuffer = new byte[16];
                long bytesRead = 0;

                using (BinaryWriter outputWriter = new BinaryWriter(new FileStream(OutputPath, FileMode.Create, FileAccess.Write, FileShare.None)))
                {
                    using (CTR enc = new CTR(new RHX()))
                    {
                        enc.Init(true, KeyParam);
                        while ((bytesRead = inputReader.Read(inputBuffer, 0, 16)) > 0)
                        {
                            enc.Transform(inputBuffer, outputBuffer);
                            outputWriter.Write(outputBuffer);
                        }
                    }
                }
            }
        }

        private void RSXTest(KeyParams KeyParam, string InputPath, string OutputPath)
        {
            using (BinaryReader inputReader = new BinaryReader(new FileStream(InputPath, FileMode.Open, FileAccess.Read, FileShare.None)))
            {
                byte[] inputBuffer = new byte[16];
                byte[] outputBuffer = new byte[16];
                long bytesRead = 0;

                using (BinaryWriter outputWriter = new BinaryWriter(new FileStream(OutputPath, FileMode.Create, FileAccess.Write, FileShare.None)))
                {
                    using (CTR enc = new CTR(new RSX()))
                    {
                        enc.Init(true, KeyParam);
                        while ((bytesRead = inputReader.Read(inputBuffer, 0, 16)) > 0)
                        {
                            enc.Transform(inputBuffer, outputBuffer);
                            outputWriter.Write(outputBuffer);
                        }
                    }
                }
            }
        }

        private void SalsaTest(KeyParams KeyParam, string InputPath, string OutputPath)
        {
            using (BinaryReader inputReader = new BinaryReader(new FileStream(InputPath, FileMode.Open, FileAccess.Read, FileShare.None)))
            {
                byte[] inputBuffer = new byte[64];
                byte[] outputBuffer = new byte[64];
                long bytesRead = 0;

                using (BinaryWriter outputWriter = new BinaryWriter(new FileStream(OutputPath, FileMode.Create, FileAccess.Write, FileShare.None)))
                {
                    using (Salsa20 enc = new Salsa20())
                    {
                        enc.Init(KeyParam);
                        while ((bytesRead = inputReader.Read(inputBuffer, 0, 64)) > 0)
                        {
                            enc.Transform(inputBuffer, outputBuffer);
                            outputWriter.Write(outputBuffer);
                        }
                    }
                }
            }
        }

        private void SHXTest(KeyParams KeyParam, string InputPath, string OutputPath)
        {
            using (BinaryReader inputReader = new BinaryReader(new FileStream(InputPath, FileMode.Open, FileAccess.Read, FileShare.None)))
            {
                byte[] inputBuffer = new byte[16];
                byte[] outputBuffer = new byte[16];
                long bytesRead = 0;

                using (BinaryWriter outputWriter = new BinaryWriter(new FileStream(OutputPath, FileMode.Create, FileAccess.Write, FileShare.None)))
                {
                    using (CTR enc = new CTR(new SHX()))
                    {
                        enc.Init(true, KeyParam);
                        while ((bytesRead = inputReader.Read(inputBuffer, 0, 16)) > 0)
                        {
                            enc.Transform(inputBuffer, outputBuffer);
                            outputWriter.Write(outputBuffer);
                        }
                    }
                }
            }
        }

        private void SPXTest(KeyParams KeyParam, string InputPath, string OutputPath)
        {
            using (BinaryReader inputReader = new BinaryReader(new FileStream(InputPath, FileMode.Open, FileAccess.Read, FileShare.None)))
            {
                byte[] inputBuffer = new byte[16];
                byte[] outputBuffer = new byte[16];
                long bytesRead = 0;

                using (BinaryWriter outputWriter = new BinaryWriter(new FileStream(OutputPath, FileMode.Create, FileAccess.Write, FileShare.None)))
                {
                    using (CTR enc = new CTR(new SPX()))
                    {
                        enc.Init(true, KeyParam);
                        while ((bytesRead = inputReader.Read(inputBuffer, 0, 16)) > 0)
                        {
                            enc.Transform(inputBuffer, outputBuffer);
                            outputWriter.Write(outputBuffer);
                        }
                    }
                }
            }
        }
        #endregion

        #region Helpers
        private void CreateFile(string FilePath)
        {
            byte[] data = new byte[1024];
            int ct = 0;

            for (int i = 0; i < 1024; i++)
            {
                data[i] = (byte)ct;
                if (i % 255 == 0)
                    ct = 0;

                ct++;
            }

            ct = 0;
            using (FileStream fs = new FileStream(FilePath, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                while (ct < this.FileSize)
                {
                    fs.Write(data, 0, data.Length);
                    ct += data.Length;
                }
            }
        }

        private void DestroyFile(string FilePath)
        {
            if (File.Exists(FilePath))
                File.Delete(FilePath);
        }

        private string FileGetTemp()
        {
            return Path.GetTempFileName();
        }

        private KeyParams GetParams()
        {
            if (this.Engine == Engines.ChaCha)
                return new KeyParams(KeyGenerator.Generate(48), KeyGenerator.Generate(8));
            else if (this.Engine == Engines.DCS)
                return new KeyParams(KeyGenerator.Generate(96));
            else if (this.Engine == Engines.RDX)
                return new KeyParams(KeyGenerator.Generate(32), KeyGenerator.Generate(16));
            else if (this.Engine == Engines.RHX)
                return new KeyParams(KeyGenerator.Generate(192), KeyGenerator.Generate(16));
            else if (this.Engine == Engines.RSX)
                return new KeyParams(KeyGenerator.Generate(64), KeyGenerator.Generate(16));
            else if (this.Engine == Engines.Salsa)
                return new KeyParams(KeyGenerator.Generate(48), KeyGenerator.Generate(8));
            else if (this.Engine == Engines.SHX)
                return new KeyParams(KeyGenerator.Generate(192), KeyGenerator.Generate(16));
            else if (this.Engine == Engines.SPX)
                return new KeyParams(KeyGenerator.Generate(32), KeyGenerator.Generate(16));
            else
                return null;
        }
        #endregion
    }
}
