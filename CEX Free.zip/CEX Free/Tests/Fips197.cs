﻿using System;
using VTDev.Projects.CEX.CryptoGraphic;
using VTDev.Projects.CEX.CryptoGraphic.Helpers;
using VTDev.Projects.CEX.Helpers;

namespace VTDev.Projects.CEX.Tests
{
    /// <summary>
    /// Test vectors from the NIST standard tests contained in the AES specification document FIPS 197:
    /// <a href="http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf"></a>
    /// </summary>
    class Fips197
    {
        #region Vectors
        private static readonly byte[][] _keys =
		{
			Hex.Decode("80000000000000000000000000000000"),
			Hex.Decode("00000000000000000000000000000080"),
			Hex.Decode("000000000000000000000000000000000000000000000000"),
            Hex.Decode("0000000000000000000000000000000000000000000000000000000000000000"),
			Hex.Decode("80000000000000000000000000000000"),
			Hex.Decode("00000000000000000000000000000080"),
            Hex.Decode("000000000000000000000000000000000000000000000000"),
			Hex.Decode("0000000000000000000000000000000000000000000000000000000000000000"),
			Hex.Decode("80000000000000000000000000000000"),
            Hex.Decode("00000000000000000000000000000080"),
			Hex.Decode("000000000000000000000000000000000000000000000000"),
			Hex.Decode("0000000000000000000000000000000000000000000000000000000000000000")
		};

        private static readonly byte[][] _plainText =
		{
			Hex.Decode("00000000000000000000000000000000"),
			Hex.Decode("00000000000000000000000000000000"),
			Hex.Decode("80000000000000000000000000000000"),
            Hex.Decode("80000000000000000000000000000000"),
			Hex.Decode("00000000000000000000000000000000"),
			Hex.Decode("00000000000000000000000000000000"),
            Hex.Decode("80000000000000000000000000000000"),
			Hex.Decode("80000000000000000000000000000000"),
			Hex.Decode("00000000000000000000000000000000"),
            Hex.Decode("00000000000000000000000000000000"),
			Hex.Decode("80000000000000000000000000000000"),
			Hex.Decode("80000000000000000000000000000000")
		};

        private static readonly byte[][] _cipherText =
		{
			Hex.Decode("0EDD33D3C621E546455BD8BA1418BEC8"),
			Hex.Decode("172AEAB3D507678ECAF455C12587ADB7"),
			Hex.Decode("6CD02513E8D4DC986B4AFE087A60BD0C"),
            Hex.Decode("DDC6BF790C15760D8D9AEB6F9A75FD4E"),
			Hex.Decode("0EDD33D3C621E546455BD8BA1418BEC8"),
			Hex.Decode("172AEAB3D507678ECAF455C12587ADB7"),
            Hex.Decode("6CD02513E8D4DC986B4AFE087A60BD0C"),
			Hex.Decode("DDC6BF790C15760D8D9AEB6F9A75FD4E"),
			Hex.Decode("0EDD33D3C621E546455BD8BA1418BEC8"),
            Hex.Decode("172AEAB3D507678ECAF455C12587ADB7"),
			Hex.Decode("6CD02513E8D4DC986B4AFE087A60BD0C"),
			Hex.Decode("DDC6BF790C15760D8D9AEB6F9A75FD4E")
		};
        #endregion

        #region Public
        /// <summary>
        /// Test vectors from NIST tests in AES specification FIPS 197
        /// </summary>
        /// <returns>Success [bool]</returns>
        internal bool Test()
        {
            try
            {
                for (int i = 0; i < _plainText.Length; i++)
                    PerformTest(_keys[i], _plainText[i], _cipherText[i]);

                return true;
            }
            catch(Exception Ex)
            {
                string message = Ex.Message == null ? "" : Ex.Message;
                Logger.LogError("AESVector", message, Ex);
                return false;
            }
        }
        #endregion

        #region Private
        private void PerformTest(byte[] Key, byte[] Input, byte[] Output)
        {
            byte[] outBytes = new byte[Input.Length];
            byte[] outBytes2 = new byte[Input.Length];

            using (RDX engine = new RDX())
            {
                engine.Init(true, Key);
                engine.Transform(Input, outBytes);

                if (Compare.AreEqual(outBytes, Output) == false)
                    throw new Exception("AESVector: Encrypted arrays are not equal!");

                engine.Init(false, Key);
                engine.Transform(Output, outBytes);

                if (Compare.AreEqual(outBytes, Input) == false)
                    throw new Exception("AESVector: Decrypted arrays are not equal!");
            }
        }
        #endregion
    }
}
