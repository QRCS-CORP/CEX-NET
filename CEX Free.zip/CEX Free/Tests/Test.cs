﻿using System;
using System.Collections.Generic;

namespace VTDev.Projects.CEX.Tests
{
    #region Public Enums
    internal enum AvsTests
    {
        Key,
        Text,
    }

    internal enum AvsVectors
    {
        V128, 
        V192, 
        V256,
    }
    #endregion

    /// <summary>
    /// Wrapper class for various vector, equality, and IO tests
    /// </summary>
    static class Test
    {
        #region Enums
        /// <summary>
        /// The available range of Test types.
        /// Used to set the Test 'ParametersKey' property.
        /// </summary>
        internal enum Tests
        {
            /// <summary>
            /// AES specification tests: ascending key
            /// </summary>
            AesAvsKey,
            /// <summary>
            /// AES specification tests: ascending text
            /// </summary>
            AesAvsText,
            /// <summary>
            /// FIPS 197 AES specification tests
            /// </summary>
            AesVector,
            /// <summary>
            /// Compares blocks of RDX output to RijndaelManaged
            /// </summary>
            BlockEquality,
            /// <summary>
            /// Tests transform output vectors, and basic I/O operations
            /// </summary>
            IOTest,
            /// <summary>
            /// Compares a block of RDX output to RijndaelManaged in CBC mode
            /// </summary>
            ModeEquality,
            /// <summary>
            /// AES Monte Carlo tests used in Brian Gladman's vector set
            /// </summary>
            MonteCarlo,
            /// <summary>
            /// Compares PSC mode transform input/output vectors against CTR output
            /// </summary>
            PSCEquality,
            /// <summary>
            /// Tests Rijndael input/output vectors
            /// </summary>
            RijndaelVector,
            /// <summary>
            /// Tests SIC mode transform input/output vectors
            /// </summary>
            SICVector,
        }
        #endregion

        #region Constructor
        static Test()
        {
            // set default tests (all)
            ParametersKey = TestParams;
        }
        #endregion

        #region Fields
        /// <summary>
        /// List of available test names
        /// </summary>
        public readonly static string[] TestNames = new string[] { 
            "AesAvsKey", 
            "AesAvsText", 
            "AesVector", 
            "BlockEquality", 
            "IOTest", 
            "ModeEquality", 
            "MonteCarlo", 
            "PSCEquality", 
            "RijndaelVector", 
            "SICVector", 
            };

        /// <summary>
        /// Default state for the Run() method. Use the Parameters property to add or remove tests
        /// </summary>
        private static readonly Dictionary<Tests, bool> TestParams = new Dictionary<Tests, bool>() {  
            {Tests.AesAvsKey, true},
            {Tests.AesAvsText, true},
            {Tests.AesVector, true},
            {Tests.BlockEquality, true},
            {Tests.IOTest, true},
            {Tests.ModeEquality, true},
            {Tests.MonteCarlo, true},
            {Tests.PSCEquality, true},
            {Tests.RijndaelVector, true},
            {Tests.SICVector, true},
        };

        /// <summary>
        /// Test descriptions
        /// </summary>
        private static readonly Dictionary<Tests, string> TestDescription = new Dictionary<Tests, string>() {  
            {Tests.AesAvsKey, "NIST AESAVS incrementing key 128/192/256 (576 vectors)"},
            {Tests.AesAvsText, "NIST AESAVS incrementing plaintext (384 vectors)"},
            {Tests.AesVector, "AES specification tests: FIPS 197"},
            {Tests.BlockEquality, "Compares RDX CBC to RijndaelManaged"},
            {Tests.IOTest, "Test output vectors and I/O operations"},
            {Tests.ModeEquality, "Compares RDX Padding modes to RijndaelManaged"},
            {Tests.MonteCarlo, "AES Monte Carlo tests"},
            {Tests.PSCEquality, "PSC mode output compared to SIC"},
            {Tests.RijndaelVector, "Tests Rijndael input/output vectors"},
            {Tests.SICVector, "SIC mode transform output vectors"},
        };
        #endregion

        #region Properties
        /// <summary>
        /// Select or deselect a test with this property: true/false. The key value is a member of 'Tests'.
        /// Usage: ParametersKey[Tests.ApproximateEntropy] = false;
        /// </summary>
        public static Dictionary<Tests, bool> ParametersKey { get; set; }
        #endregion

        #region Progress
        public static event Action<int, string> ProgressChanged;
        private static void OnProgressChanged(int value, string message)
        {
            var progress = ProgressChanged;
            if (progress != null)
                progress(value, message);
        }

        internal static int ProgressMax()
        {
            // get the number of tests
            int testCount = 0;

            foreach (var test in TestParams)
                testCount += test.Value == true ? 1 : 0;

            return testCount;
        }
        #endregion

        #region Public
        /// <summary>
        /// Get test results from a Nist STS run
        /// </summary>
        /// <returns>Results dictionary [key: Tests.(testname) - value: p-value,score]</returns>
        internal static Dictionary<string, string> Run()
        {
            bool state = false;

            // create the results dictionary
            Dictionary<string, string> testResults = new Dictionary<string, string>();

            // run the tests..
            if (ParametersKey[Tests.AesAvsKey])
            {
                state = AvsKey();
                testResults.Add("AvsKey", TestDescription[Tests.AesAvsKey] + "," + State(state));
                OnProgressChanged(1, "AvsKey Completed..");
            }
            if (ParametersKey[Tests.AesAvsText])
            {
                state = AvsText();
                testResults.Add("AvsText", TestDescription[Tests.AesAvsText] + "," + State(state));
                OnProgressChanged(1, "AvsText Completed..");
            }
            if (ParametersKey[Tests.AesVector])
            {
                state = AesVector();
                testResults.Add("AesVector", TestDescription[Tests.AesVector] + "," + State(state));
                OnProgressChanged(1, "AesVector Completed..");
            }
            if (ParametersKey[Tests.BlockEquality])
            {
                state = BlockTest();
                testResults.Add("BlockEquality", TestDescription[Tests.BlockEquality] + "," + State(state));
                OnProgressChanged(1, "BlockEquality Completed..");
            }
            if (ParametersKey[Tests.IOTest])
            {
                state = IOTest();
                testResults.Add("IOTest", TestDescription[Tests.IOTest] + "," + State(state));
                OnProgressChanged(1, "IOTest Completed..");
            }
            if (ParametersKey[Tests.ModeEquality])
            {
                state = ModeEqualTest();
                testResults.Add("ModeEquality", TestDescription[Tests.ModeEquality] + "," + State(state));
                OnProgressChanged(1, "ModeEquality Completed..");
            }
            if (ParametersKey[Tests.MonteCarlo])
            {
                state = MonteCarlo();
                testResults.Add("MonteCarlo", TestDescription[Tests.MonteCarlo] + "," + State(state));
                OnProgressChanged(1, "MonteCarlo Completed..");
            }
            if (ParametersKey[Tests.PSCEquality])
            {
                state = PSCTest();
                testResults.Add("PSCEquality", TestDescription[Tests.PSCEquality] + "," + State(state));
                OnProgressChanged(1, "PSCEquality Completed..");
            }
            if (ParametersKey[Tests.RijndaelVector])
            {
                state = RijndaelTest();
                testResults.Add("RijndaelVector", TestDescription[Tests.RijndaelVector] + "," + State(state));
                OnProgressChanged(1, "RijndaelVector Completed..");
            }
            if (ParametersKey[Tests.SICVector])
            {
                state = SICTest();
                testResults.Add("SICVector", TestDescription[Tests.SICVector] + "," + State(state));
                OnProgressChanged(1, "SICVector Completed..");
            }

            return testResults;
        }

        /// <summary>
        /// Tests speed of Mono, Bouncy Castle, and RDX Diffusion algorithms
        /// </summary>
        /// <returns>Elapsed milliseconds [string]</returns>
        internal static string EngineTest(AesEngines Engine, int Iterations)
        {
            return new CompareEngine(Engine).Test(Iterations);
        }

        /// <summary>
        /// Compares speeds of RDX, FastAes, or AesManaged in CBC mode
        /// </summary>
        /// <param name="Implementation">Implementation to test</param>
        /// <param name="BlockCount">Number of blocks to test</param>
        /// <param name="Iterations">Number of times to run this test</param>
        /// <returns>Time elapsed as string value</returns>
        internal static string SpeedTest(AesImplementations Implementation, int BlockCount = 1000, int Iterations = 10)
        {
            return new SpeedTest(Implementation).Test(Iterations, BlockCount);
        }
        #endregion

        #region Private
        /// <summary>
        /// The AES specification tests: FIPS 197
        /// </summary>
        /// <returns>Number of Tests passed (12 total)</returns>
        private static bool AvsKey()
        {
            return (new AvsVector().Test(AvsVectors.V128, AvsTests.Key) &&
                new AvsVector().Test(AvsVectors.V192, AvsTests.Key) &&
                new AvsVector().Test(AvsVectors.V256, AvsTests.Key));
        }

        /// <summary>
        /// The AES specification tests: FIPS 197
        /// </summary>
        /// <returns>Number of Tests passed (12 total)</returns>
        private static bool AvsText()
        {
            return (new AvsVector().Test(AvsVectors.V128, AvsTests.Text) &&
                new AvsVector().Test(AvsVectors.V192, AvsTests.Text) &&
                new AvsVector().Test(AvsVectors.V256, AvsTests.Text));
        }

        /// <summary>
        /// The AES specification tests: FIPS 197
        /// </summary>
        /// <returns>Number of Tests passed (12 total)</returns>
        private static bool AesVector()
        {
            return new Fips197().Test();
        }

        /// <summary>
        /// Equality Comparison: compares blocks of RDX output to RijndaelManaged
        /// </summary>
        /// <param name="BlockSize">Size of block</param>
        /// <returns>Success [bool]</returns>
        private static bool BlockTest()
        {
            return new BlockEquality().Test();
        }

        /// <summary>
        /// Tests transform output vectors, and basic I/O operations
        /// </summary>
        /// <returns>Success [bool]</returns>
        private static bool IOTest()
        {
            return new IOTest().Test();
        }

        /// <summary>
        /// Equality Comparison: compares a block of RDX output to RijndaelManaged in CBC mode
        /// </summary>
        /// <returns>Success [bool]</returns>
        private static bool ModeEqualTest()
        {
            return new ModeEquality().Test();
        }

        /// <summary>
        /// The AES Monte Carlo tests used in Brian Gladman's vector set
        /// </summary>
        /// <returns>Number of Tests passed (12 total)</returns>
        private static bool MonteCarlo()
        {
            return new MonteCarlo().Test();
        }

        /// <summary>
        /// Compares PSC mode transform input/output vectors against CTR output
        /// </summary>
        /// <returns>Success [bool]</returns>
        private static bool PSCTest()
        {
            return new PSCEquality().Test();
        }

        /// <summary>
        /// Tests Rijndael input/output vectors
        /// </summary>
        /// <returns>Success [bool]</returns>
        private static bool RijndaelTest()
        {
            return new RijndaelVector().Test();
        }

        /// <summary>
        /// Tests SIC mode transform input/output vectors
        /// </summary>
        /// <returns>Success [bool]</returns>
        private static bool SICTest()
        {
            return new SICVector().Test();
        }
        #endregion

        #region Helpers
        private static string State(bool Value)
        {
            return Value == true ? "PASS" : "FAIL";
        }
        #endregion
    }
}