﻿using System.ComponentModel;
using System.IO;
using VTDev.Projects.CEX.CryptoGraphic;
using VTDev.Projects.CEX.CryptoGraphic.Helpers;

namespace VTDev.Projects.CEX
{
    /// <summary>
    /// Encryption/Decryption wrapper
    /// </summary>
    internal class Transform
    {
        #region Constants
        private const int DCS_BLOCK = 10240;
        private const int PRG_INTV = 4096;
        #endregion

        #region Events
        internal delegate void ProgressCounterDelegate(int count);
        [Description("Progress Counter")]
        internal event ProgressCounterDelegate ProgressCounter;
        #endregion

        #region Properties
        private Algorithms Algorithm { get; set; }
        public int BlockSize { get; set; }
        private CipherModes CipherMode { get; set; }
        private long FileSize { get; set; }
        private byte[] IV { get; set; }
        private byte[] Key { get; set; }
        private string KeyPath { get; set; }
        private KeySizes KeySize { get; set; }
        private PaddingModes PaddingMode { get; set; }
        private long ProgressInterval { get; set; }
        #endregion

        #region Fields
        private IBlockCipher Engine;
        private ICipherMode Cipher;
        private IPadding Padding;
        #endregion

        #region Constructor
        internal Transform(string KeyPath)
        {
            if (!File.Exists(KeyPath)) return;
            // get key and algorithm
            this.ProgressInterval = PRG_INTV;
            this.KeyPath = KeyPath;
            this.Algorithm = KeyHeader.GetEngine(KeyPath);
            this.Key = GetKey(KeyPath);

            // dcs has fixed params
            if (this.Algorithm == Algorithms.DCS)
                return;

            // set params from key data
            this.BlockSize = KeyHeader.GetBlockSize(KeyPath) == BlockSizes.B16 ? 16 : 32;
            this.CipherMode = KeyHeader.GetCipherMode(KeyPath);
            this.PaddingMode = KeyHeader.GetPaddingMode(KeyPath);
            this.IV = GetIV(KeyPath);

            if (this.IV != null && this.IV.Length > 0)
                this.BlockSize = this.IV.Length;
            else
                this.CipherMode = CipherModes.None;

            if (this.PaddingMode == PaddingModes.PKCS7)
                Padding = new PKCS7();
            else if (this.PaddingMode == PaddingModes.X923)
                Padding = new X923();
            else if (this.PaddingMode == PaddingModes.Zeros)
                Padding = new ZeroPad();

            if (this.Algorithm == Algorithms.RDX)
                this.Engine = new RDX();
            else if (this.Algorithm == Algorithms.RSX)
                this.Engine = new RSX();

            this.Engine.BlockSize = this.BlockSize;

            if (this.CipherMode == CipherModes.CBC)
                this.Cipher = new CBC(this.Engine);
            else if (this.CipherMode == CipherModes.CTR)
                this.Cipher = new CTR(this.Engine);
            else if (this.CipherMode == CipherModes.PSC)
                this.Cipher = new PSC(this.Engine);
            else if (this.CipherMode == CipherModes.None)
                this.Cipher = new ECB(this.Engine);
        }

        ~Transform()
        {
            // destroys cipher and engine
            if (this.Cipher != null)
                this.Cipher.Dispose();
        }
        #endregion

        #region Public Methods
        internal void Decrypt(string InputPath, string OutputPath)
        {
            this.FileSize = GetFileSize(InputPath);
            CalculateInterval();

            if (this.Algorithm != Algorithms.DCS)
            {
                this.Cipher.Init(false, this.Key, this.IV);

                if (this.CipherMode == CipherModes.PSC)
                    ProcessPSC(InputPath, OutputPath);
                else
                    DecryptRX(InputPath, OutputPath);
            }
            else
            {
                ProcessDCS(InputPath, OutputPath);
            }
        }

        internal void Encrypt(string InputPath, string OutputPath)
        {
            byte[] checkSum = GetChecksum(InputPath);
            MemoryStream header = new MemoryStream(MessageHeader.Create(this.KeyPath, Path.GetExtension(InputPath), checkSum));

            this.FileSize = GetFileSize(InputPath);
            CalculateInterval();

            if (this.Algorithm != Algorithms.DCS)
            {
                this.Cipher.Init(true, this.Key, this.IV);

                if (this.CipherMode == CipherModes.PSC)
                    ProcessPSC(InputPath, OutputPath, header);
                else
                    EncryptRX(InputPath, OutputPath, header);
            }
            else
            {
                ProcessDCS(InputPath, OutputPath, header);
            }
        }
        #endregion

        #region RDX/RSX
        private void DecryptRX(string InputPath, string OutputPath)
        {
            using (BinaryReader inputReader = new BinaryReader(new FileStream(InputPath, FileMode.Open, FileAccess.Read, FileShare.None)))
            {
                byte[] inputBuffer = new byte[this.BlockSize];
                byte[] outputBuffer = new byte[this.BlockSize];
                long bytesRead = 0;
                long bytesTotal = 0;

                // move past header
                inputReader.BaseStream.Position = MessageHeader.GetHeaderSize;

                using (BinaryWriter outputWriter = new BinaryWriter(new FileStream(OutputPath, FileMode.Create, FileAccess.Write, FileShare.None)))
                {
                    int maxOut = (int)inputReader.BaseStream.Length - MessageHeader.GetHeaderSize;

                    while ((bytesRead = inputReader.Read(inputBuffer, 0, this.BlockSize)) > 0)
                    {
                        bytesTotal += bytesRead;

                        if (bytesTotal < maxOut)
                        {
                            this.Cipher.Transform(inputBuffer, outputBuffer);
                            outputWriter.Write(outputBuffer);

                            if (bytesTotal % this.ProgressInterval == 0)
                                CalculateProgress(bytesTotal);
                        }
                        else
                        {
                            this.Cipher.Transform(inputBuffer, outputBuffer);
                            int size = this.BlockSize - Padding.GetPaddingLength(outputBuffer);
                            outputWriter.Write(outputBuffer, 0, size);
                            CalculateProgress(bytesTotal + size);
                        }
                    }
                }
            }
        }

        private void EncryptRX(string InputPath, string OutputPath, MemoryStream Header)
        {
            using (BinaryReader inputReader = new BinaryReader(new FileStream(InputPath, FileMode.Open, FileAccess.Read, FileShare.None)))
            {
                byte[] inputBuffer = new byte[this.BlockSize];
                byte[] outputBuffer = new byte[this.BlockSize];
                long bytesRead = 0;
                long bytesTotal = 0;

                using (BinaryWriter outputWriter = new BinaryWriter(new FileStream(OutputPath, FileMode.Create, FileAccess.Write, FileShare.None)))
                {
                    // write message header
                    outputWriter.Write(Header.ToArray());

                    while ((bytesRead = inputReader.Read(inputBuffer, 0, this.BlockSize)) == this.BlockSize)
                    {
                        this.Cipher.Transform(inputBuffer, outputBuffer);
                        outputWriter.Write(outputBuffer);
                        bytesTotal += bytesRead;

                        if (bytesTotal % this.ProgressInterval == 0)
                            CalculateProgress(bytesTotal);
                    }

                    if (bytesRead > 0)
                    {
                        if (bytesRead < this.BlockSize)
                            Padding.AddPadding(inputBuffer, (int)bytesRead);

                        this.Cipher.Transform(inputBuffer, outputBuffer);
                        outputWriter.Write(outputBuffer);
                        CalculateProgress(bytesTotal + bytesRead);
                    }
                }
            }
        }

        private void ProcessPSC(string InputPath, string OutputPath, MemoryStream Header = null)
        {
            using (BinaryReader inputReader = new BinaryReader(new FileStream(InputPath, FileMode.Open, FileAccess.Read, FileShare.None)))
            {
                // PSC requires min. 1024 byte block to parallelize,
                // and block must be divisible of 1024
                int blockSize = PSC.MinParallelSize;
                long bytesRead = 0;
                long bytesTotal = 0;

                if (inputReader.BaseStream.Length < blockSize)
                    blockSize = (int)inputReader.BaseStream.Length;

                using (BinaryWriter outputWriter = new BinaryWriter(new FileStream(OutputPath, FileMode.Create, FileAccess.Write, FileShare.None)))
                {
                    byte[] inputBuffer = new byte[blockSize];
                    byte[] outputBuffer = new byte[blockSize];

                    if (Header != null)
                        outputWriter.Write(Header.ToArray());
                    else
                        inputReader.BaseStream.Position = MessageHeader.GetHeaderSize;

                    while ((bytesRead = inputReader.Read(inputBuffer, 0, blockSize)) == blockSize)
                    {
                        this.Cipher.Transform(inputBuffer, outputBuffer);
                        outputWriter.Write(outputBuffer);
                        bytesTotal += bytesRead;

                        if (bytesTotal % this.ProgressInterval == 0)
                            CalculateProgress(bytesTotal);
                    }

                    if (bytesRead > 0)
                    {
                        outputBuffer = new byte[blockSize];
                        this.Cipher.Transform(inputBuffer, outputBuffer);
                        outputWriter.Write(outputBuffer, 0, (int)bytesRead);
                        CalculateProgress(bytesTotal + bytesRead);
                    }
                }
            }
        }
        #endregion

        #region DCS
        private void ProcessDCS(string InputPath, string OutputPath, MemoryStream Header = null)
        {
            using (BinaryReader inputReader = new BinaryReader(new FileStream(InputPath, FileMode.Open, FileAccess.Read, FileShare.None)))
            {
                int blockSize = (DCS_BLOCK * 4);
                long bytesRead = 0;
                long bytesTotal = 0;

                if (inputReader.BaseStream.Length < blockSize)
                    blockSize = (int)inputReader.BaseStream.Length;

                using (BinaryWriter outputWriter = new BinaryWriter(new FileStream(OutputPath, FileMode.Create, FileAccess.Write, FileShare.None)))
                {
                    byte[] inputBuffer = new byte[blockSize];
                    byte[] outputBuffer = new byte[blockSize];

                    if (Header != null)
                        outputWriter.Write(Header.ToArray());
                    else
                        inputReader.BaseStream.Position = MessageHeader.GetHeaderSize;

                    using (DCS dcs = new DCS())
                    {
                        dcs.Init(this.Key);

                        while ((bytesRead = inputReader.Read(inputBuffer, 0, blockSize)) == blockSize)
                        {
                            dcs.Transform(inputBuffer, outputBuffer);
                            outputWriter.Write(outputBuffer);
                            bytesTotal += bytesRead;

                            if (bytesTotal % this.ProgressInterval == 0)
                                CalculateProgress(bytesTotal);
                        }

                        if (bytesRead > 0)
                        {
                            outputBuffer = new byte[bytesRead];
                            dcs.Transform(inputBuffer, outputBuffer);
                            outputWriter.Write(outputBuffer);
                            CalculateProgress(bytesTotal + bytesRead);
                        }
                    }
                }
            }
        }
        #endregion

        #region Helpers
        private void CalculateInterval()
        {
            if (this.Algorithm == Algorithms.DCS)
            {
                this.ProgressInterval = PRG_INTV;
            }
            else
            {
                long interval = this.FileSize / 100;

                if (interval == 0)
                    this.ProgressInterval = this.FileSize;
                else
                    this.ProgressInterval = interval - (interval % this.BlockSize);

                if (this.ProgressInterval == 0)
                    this.ProgressInterval = this.FileSize;
            }
        }

        private void CalculateProgress(long ByteCount)
        {
            if (ProgressCounter != null)
            {
                double progress = 100.0 * (double)ByteCount / FileSize;
                ProgressCounter((int)progress);
            }
        }

        private byte[] GetChecksum(string FilePath)
        {
            long fileSize = GetFileSize(FilePath);
            int bufferSize = fileSize < 4096 ? (int)fileSize : 4096;
            byte[] buffer = new byte[bufferSize];

            using (BinaryReader fileReader = new BinaryReader(new FileStream(FilePath, FileMode.Open, FileAccess.Read, FileShare.None)))
            {
                buffer = fileReader.ReadBytes(bufferSize);
                using (SHA256Digest sha = new SHA256Digest())
                    return sha.ComputeHash(buffer);
            }
        }

        private static long GetFileSize(string FilePath)
        {
            try
            {
                return File.Exists(FilePath) ? new FileInfo(FilePath).Length : 0;
            }
            catch { }
            return -1;
        }

        private byte[] GetKey(string KeyPath)
        {
            int size = GetKeySize(KeyPath);
            byte[] key = new byte[size];

            using (BinaryReader inputReader = new BinaryReader(new FileStream(KeyPath, FileMode.Open, FileAccess.Read, FileShare.None)))
            {
                inputReader.BaseStream.Position = KeyHeader.GetHeaderSize;
                key = inputReader.ReadBytes(size);
            }

            return key;
        }

        private int GetKeySize(string KeyPath)
        {
            KeySizes keySize = KeyHeader.GetKeySize(KeyPath);

            if (this.Algorithm == Algorithms.DCS)
                return 96;

            if (keySize == KeySizes.K128)
                return 16;
            else if (keySize == KeySizes.K192)
                return 24;
            else if (keySize == KeySizes.K512)
                return 64;
            else
                return 32;
        }

        private byte[] GetIV(string KeyPath)
        {
            int ivSize = GetIvSize(KeyPath);
            int keySize = GetKeySize(KeyPath);
            byte[] iv = new byte[ivSize];

            using (BinaryReader inputReader = new BinaryReader(new FileStream(KeyPath, FileMode.Open, FileAccess.Read, FileShare.None)))
            {
                int pos = KeyHeader.GetHeaderSize + keySize;
                if (pos > inputReader.BaseStream.Length)
                    return null;

                inputReader.BaseStream.Position = pos;
                iv = inputReader.ReadBytes(ivSize);
            }

            return iv;
        }

        private int GetIvSize(string KeyPath)
        {
            IVSizes ivSize = KeyHeader.GetIvSize(KeyPath);

            if (ivSize == IVSizes.V128)
                return 16;
            else
                return 32;
        }
        #endregion
    }
}
